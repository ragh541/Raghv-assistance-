# Speech-to-Text Voice Assistant — Android

A lightweight, offline-capable voice assistant app for Android that uses Android's built-in `SpeechRecognizer` API to capture voice commands and execute actions on the phone.

## Features

- **Real-time Speech Recognition** using `SpeechRecognizer` API
- **Partial Results** — live transcription as you speak
- **Voice Commands:**
  - `call <name>` — Open dialer
  - `open <app name>` — Launch installed apps (WhatsApp, YouTube, Instagram, etc.)
  - `search <query>` — Google search
  - `set alarm 7:30` — Set an alarm
  - `set timer 30 seconds` — Set a timer
  - `open youtube.com` — Open website in browser
  - `what time is it` — Get current time
  - `what date is it` — Get current date
  - `remind me <text>` — Save reminder
- **Error Handling** — human-readable error messages with auto-restart on transient failures
- **Multi-language Support** — Hindi (hi-IN), Tamil (ta-IN), English (en-US), etc.
- **Permission Flow** — proper runtime permission handling with Settings redirect

## App Size

The compiled APK comes **under 5MB** — the speech recognition runs via Android's system service, not a bundled ML model, keeping the app extremely lightweight.

## Project Structure

```
SpeechToTextApp/
├── app/
│   ├── build.gradle                          # Module build config
│   └── src/main/
│       ├── AndroidManifest.xml               # Permissions & app config
│       ├── res/layout/
│       │   └── activity_main.xml             # UI layout
│       └── java/com/aiassistant/voicest/
│           ├── MainActivity.kt               # Main activity + command processor
│           └── SpeechToTextHelper.kt          # Reusable STT wrapper class
├── build.gradle                              # (Project-level — standard template)
├── settings.gradle                           # (Standard template)
└── README.md                                  # This file
```

## Setup Instructions

### Prerequisites
- **Android Studio** (Giraffe or newer)
- **JDK 17** (bundled with recent Android Studio)
- **Android SDK 34** (Android 14)
- **Min SDK 24** (Android 7.0+)

### Steps

1. **Open Android Studio** → `File → New → New Project`

2. Choose **Empty Views Activity** (not Compose) → Click Next

3. Configure:
   - **Name:** Voice Assistant
   - **Package name:** `com.aiassistant.voicest`
   - **Language:** Kotlin
   - **Minimum SDK:** API 24 (Android 7.0)
   - Click **Finish**

4. **Copy the files** from this project into your new project:
   - Replace `app/src/main/AndroidManifest.xml` with the provided file
   - Replace `app/src/main/res/layout/activity_main.xml` with the provided file
   - Copy both `.kt` files to `app/src/main/java/com/aiassistant/voicest/`
   - Update `app/build.gradle` with the provided config

5. **Create `colors.xml`** at `app/src/main/res/values/colors.xml`:
   ```xml
   <resources>
       <color name="purple_500">#6200EE</color>
   </resources>
   ```

6. **Create `strings.xml`** at `app/src/main/res/values/strings.xml`:
   ```xml
   <resources>
       <string name="app_name">Voice Assistant</string>
   </resources>
   ```

7. **Build & Run:**
   - Click the green **Play** button in Android Studio
   - Or build APK: `Build → Build Bundle(s)/APK(s) → Build APK(s)`
   - The APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

## How It Works

```
User speaks → Android SpeechRecognizer (system service)
                         ↓
              SpeechToTextHelper.kt
              ├─ onPartialResults() → live text display
              ├─ onResults() → final recognized text
              └─ onError() → error handling + auto-restart
                         ↓
              MainActivity.processVoiceCommand()
              ├─ "call X"     → ACTION_DIAL intent
              ├─ "open X"     → PackageManager launch
              ├─ "search X"   → ACTION_WEB_SEARCH
              ├─ "set alarm"  → ACTION_SET_ALARM
              ├─ "set timer"  → ACTION_SET_TIMER
              └─ fallback     → display as text
```

## Permissions Required

| Permission | Purpose |
|---|---|
| `RECORD_AUDIO` | Capture microphone input for speech recognition |
| `INTERNET` | SpeechRecognizer may use cloud-based recognition |
| `ACCESS_NETWORK_STATE` | Check network availability |
| `BLUETOOTH` | Support for Bluetooth headsets (optional) |

> Note: `READ_CONTACTS` permission is NOT required by default. The call feature opens the dialer with the spoken name/number. To enable full contact lookup by name, add `READ_CONTACTS` permission and uncomment the contact query code in `MainActivity.kt`.

## Changing Recognition Language

In `SpeechToTextHelper.kt` or `MainActivity.kt`:

```kotlin
// For Hindi
speechHelper.setLanguage("hi-IN")

// For Tamil
speechHelper.setLanguage("ta-IN")

// For English (India)
speechHelper.setLanguage("en-IN")
```

Supported Indian languages: `hi-IN`, `ta-IN`, `te-IN`, `bn-IN`, `mr-IN`, `gu-IN`, `kn-IN`, `ml-IN`, `pa-IN`, `ur-IN`, `or-IN`.

## Extending the App

### Add Text-to-Speech (TTS) for voice responses
```kotlin
import android.speech.tts.TextToSpeech

// In MainActivity
private lateinit var tts: TextToSpeech

// Initialize in onCreate
tts = TextToSpeech(this) { status ->
    if (status == TextToSpeech.SUCCESS) {
        tts.language = Locale.getDefault()
    }
}

// Speak a response
fun speak(text: String) {
    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tts_utterance")
}
```

### Add always-listening wake word (like "Hey Siri")
Consider using:
- **PocketSphinx** (offline, lightweight) for wake word detection
- **Vosk** (offline speech recognition) as an alternative to SpeechRecognizer
- **Porcupine** (Picovoice) for wake word detection

### Connect to an LLM (Gemini/OpenAI) for intelligent responses
```kotlin
// Add Retrofit dependency in build.gradle
// implementation 'com.squareup.retrofit2:retrofit:2.9.0'
// implementation 'com.squareup.retrofit2:converter-gson:2.9.0'

// Send recognized text to Gemini API
// Process the response and speak it back with TTS
```

## Troubleshooting

| Issue | Solution |
|---|---|
| "SpeechRecognizer not available" | Ensure Google app is installed (provides recognition service) |
| Permission denied | Go to Settings → Apps → Voice Assistant → Permissions → Microphone |
| No speech detected | Speak louder / closer to mic / check if another app is using the mic |
| Network error | Some recognition modes require internet; check connection |
| App crashes on Android 11+ | Ensure `<queries>` block is in AndroidManifest.xml (already included) |

## License

This is open-source code provided for educational and personal use. Feel free to modify and distribute.

## Next Steps for a Full Assistant

1. **Add TTS** — so the assistant speaks responses back
2. **Add wake word detection** — always-listening without button press
3. **Connect to Gemini API** — for intelligent conversational responses
4. **Add notification access** — to read/respond to notifications by voice
5. **Add accessibility service** — to control UI elements by voice
6. **Add SMS/WhatsApp integration** — send messages by voice
