package com.aiassistant.voicest

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

/**
 * ThemeManager — Stores and applies the user's preferred accent color scheme.
 *
 * The app uses Material3 (Theme.Material3.Dark.NoActionBar) as the base theme.
 * This manager lets the user pick from 6 preset accent color schemes:
 *   Cyan (default), Green, Purple, Orange, Pink, Red
 *
 * HOW IT WORKS:
 * 1. User selects a scheme in ColorSchemeActivity
 * 2. The choice is saved in SharedPreferences as a scheme ID string
 * 3. On every Activity start, applyTheme() is called BEFORE setContentView()
 *    to overlay the matching theme style (e.g. ThemeOverlay.App.Cyan)
 * 4. The overlay overrides colorPrimary, colorSecondary, colorAccent, etc.
 *    so the entire app's UI (buttons, switches, text colors, FAB) updates
 *
 * USAGE:
 *   // In Activity.onCreate(), before setContentView:
 *   ThemeManager.applyTheme(this)
 *   setContentView(R.layout.activity_main)
 *
 *   // To save the user's choice:
 *   ThemeManager.setScheme(this, ThemeManager.Scheme.PURPLE)
 */
object ThemeManager {

    private const val TAG = "ThemeManager"
    private const val PREFS_NAME = "theme_prefs"
    private const val KEY_SCHEME = "accent_scheme"

    enum class Scheme(
        val id: String,
        val overlayStyleResId: Int,
        val displayName: String,
        val primaryColor: String,
        val accentColor: String
    ) {
        CYAN("cyan", R.style.ThemeOverlay_App_Cyan, "Cyan", "#00D4FF", "#00D4FF"),
        GREEN("green", R.style.ThemeOverlay_App_Green, "Green", "#3FB950", "#56D364"),
        PURPLE("purple", R.style.ThemeOverlay_App_Purple, "Purple", "#A371F7", "#BC8CFF"),
        ORANGE("orange", R.style.ThemeOverlay_App_Orange, "Orange", "#DB6D28", "#F0883E"),
        PINK("pink", R.style.ThemeOverlay_App_Pink, "Pink", "#DB61A2", "#F778BA"),
        RED("red", R.style.ThemeOverlay_App_Red, "Red", "#F85149", "#FF6B6B");

        companion object {
            fun fromId(id: String?): Scheme = entries.firstOrNull { it.id == id } ?: CYAN
        }
    }

    fun getScheme(context: Context): Scheme {
        val prefs = getPrefs(context)
        return Scheme.fromId(prefs.getString(KEY_SCHEME, null))
    }

    fun setScheme(context: Context, scheme: Scheme) {
        getPrefs(context).edit().putString(KEY_SCHEME, scheme.id).apply()
        themeChanged = true
        Log.i(TAG, "★ Color scheme set to: ${scheme.displayName}")
    }

    /** Flag set when scheme changes — checked by MainActivity.onResume to recreate() */
    @Volatile
    var themeChanged: Boolean = false

    fun applyTheme(context: Context) {
        val scheme = getScheme(context)
        try {
            context.theme.applyStyle(scheme.overlayStyleResId, true)
            Log.d(TAG, "Applied theme overlay: ${scheme.displayName}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to apply theme overlay: ${scheme.displayName}", e)
        }
    }

    fun getAllSchemes(): List<Scheme> = Scheme.entries.toList()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
}
