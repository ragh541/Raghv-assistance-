package com.aiassistant.voicest

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/**
 * WaveformView — A custom View that draws an animated audio waveform.
 *
 * Visual behaviour:
 * - When IDLE (not listening): shows a flat centered line of small bars (dimmed)
 * - When LISTENING: bars animate with a sine-wave "breathing" pattern
 * - When the user SPEAKS (RMS rises): bars react to the RMS value —
 *   taller bars, brighter colours, faster motion. Provides real-time feedback.
 * - Smooth transitions: RMS decays gradually when sound stops so bars
 *   settle back to the idle breathing animation.
 *
 * The view is self-animating using ValueAnimator at ~60fps. It does NOT
 * require the RMS callback to be called every frame — it interpolates
 * between RMS updates for smooth motion.
 *
 * Usage in XML:
 *   <com.aiassistant.voicest.WaveformView
 *       android:id="@+id/waveform"
 *       android:layout_width="match_parent"
 *       android:layout_height="80dp" />
 *
 * Usage in code:
 *   waveform.startListening()        // begin the breathing animation
 *   waveform.updateRms(rmsValue)     // feed RMS from SpeechRecognizer
 *   waveform.stopListening()         // return to idle state
 */
class WaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val TAG = "WaveformView"

    // ---- Configuration ----
    private val barCount = 48               // Number of vertical bars
    private val barWidth = 6f               // Width of each bar in dp
    private val barSpacing = 4f             // Spacing between bars in dp
    private val minBarHeight = 6f          // Minimum bar height in dp (idle state)
    private val maxAmplitude = 120f        // Maximum bar height in dp at full RMS

    // ---- Colours — enhanced for low-light visibility ----
    private val idleColor = Color.parseColor("#30363D")     // Dim grey when idle
    private val activeColor = Color.parseColor("#3FB950")    // Bright green when listening
    private val peakColor = Color.parseColor("#58A6FF")     // Bright blue when speaking loud

    // ---- Glow paint — gives bars a luminous halo in low light ----
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        strokeCap = Paint.Cap.ROUND
        alpha = 60   // Semi-transparent for soft glow
    }

    // ---- State ----
    private var isListening = false
    private var currentRms = 0f            // Smoothed RMS value (0..~12+)
    private var targetRms = 0f             // Latest RMS from callback
    private var phase = 0f                 // Animation phase for sine wave
    private var barHeights = FloatArray(barCount) { minBarHeight }
    private var barTargets = FloatArray(barCount) { minBarHeight }
    private var random = Random(System.currentTimeMillis())

    // ---- Paints ----
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        strokeCap = Paint.Cap.ROUND
    }

    // ---- Animator ----
    private var animator: ValueAnimator? = null

    private val dp: Float = resources.displayMetrics.density

    init {
        // Set a minimum height so the view is visible in the layout editor
        minimumHeight = (80 * dp).toInt()
    }

    /**
     * Start the listening animation — bars breathe with a sine-wave pattern.
     */
    fun startListening() {
        isListening = true
        targetRms = 0.5f   // Small baseline so bars are slightly active
        if (animator == null) {
            startAnimationLoop()
        }
        Log.d(TAG, "Waveform animation started")
    }

    /**
     * Stop listening — bars return to idle (flat, dimmed) state.
     */
    fun stopListening() {
        isListening = false
        targetRms = 0f
        Log.d(TAG, "Waveform animation stopped")
    }

    /**
     * Feed a new RMS (sound level) value from SpeechRecognizer.onRmsChanged().
     * The view smooths this value for visual continuity.
     *
     * @param rms Raw RMS value from Android (typically ranges 0.0 to ~12.0+)
     */
    fun updateRms(rms: Float) {
        // Clamp and normalise: Android RMS is roughly -2dB to 10dB
        // Map to a 0..1 amplitude scale
        targetRms = (rms.coerceIn(-2f, 12f) + 2f) / 14f
    }

    /**
     * Main animation loop — runs at ~60fps via ValueAnimator.
     */
    private fun startAnimationLoop() {
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 16L     // ~60fps per cycle
            repeatMode = ValueAnimator.RESTART
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                updateBars()
                invalidate()
            }
            start()
        }
    }

    /**
     * Update bar heights each frame.
     * Combines:
     * - Smoothed RMS (decays toward target)
     * - Sine-wave breathing pattern (phase-based)
     * - Per-bar random jitter for organic feel
     */
    private fun updateBars() {
        // Smooth the RMS — fast attack, slow decay (like a real VU meter)
        val smoothing = if (targetRms > currentRms) 0.25f else 0.08f
        currentRms += (targetRms - currentRms) * smoothing

        // Advance the sine-wave phase
        phase += if (isListening) 0.06f else 0.02f
        if (phase > Math.PI * 2) phase -= (Math.PI * 2).toFloat()

        for (i in 0 until barCount) {
            if (isListening) {
                // Centre bars react more, edges less (creates a "pulse" effect)
                val centreWeight = 1f - abs(i - barCount / 2f) / (barCount / 2f)

                // Sine wave breathing — each bar is phase-shifted
                val sineValue = sin(phase + i * 0.3).toFloat()

                // Combine: baseline + RMS-driven amplitude + sine modulation
                val baseAmplitude = 0.15f + currentRms * 0.85f
                val height = minBarHeight +
                        (maxAmplitude * baseAmplitude * centreWeight) *
                        (0.4f + 0.6f * abs(sineValue))

                // Add subtle random jitter when actively speaking
                val jitter = if (currentRms > 0.1f) {
                    (random.nextFloat() - 0.5f) * 8f * currentRms
                } else 0f

                barTargets[i] = (height + jitter).coerceIn(minBarHeight, maxAmplitude)
            } else {
                // Idle: gentle flat line with tiny breathing
                val idleSine = sin(phase + i * 0.5).toFloat()
                barTargets[i] = minBarHeight + abs(idleSine) * 2f
            }

            // Smooth interpolation toward target for each bar
            barHeights[i] += (barTargets[i] - barHeights[i]) * 0.3f
        }
    }

    // ---- Drawing ----

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        val centerY = h / 2f

        val totalBarWidth = barCount * barWidth * dp + (barCount - 1) * barSpacing * dp
        val startX = (w - totalBarWidth) / 2f

        for (i in 0 until barCount) {
            val x = startX + i * (barWidth + barSpacing) * dp
            val barHeightPx = barHeights[i] * dp

            // Colour: blend idle → active → peak based on amplitude
            val amplitude = (barHeights[i] - minBarHeight) / (maxAmplitude - minBarHeight)
            val color = interpolateColor(amplitude.coerceIn(0f, 1f))

            // Draw bar centered vertically
            val top = centerY - barHeightPx / 2f
            val bottom = centerY + barHeightPx / 2f

            // Glow layer — draw a wider, semi-transparent bar behind for luminous halo
            if (isListening && amplitude > 0.1f) {
                glowPaint.color = color
                val glowExpand = 3f * dp * amplitude
                canvas.drawRoundRect(
                    x - glowExpand, top - glowExpand,
                    x + barWidth * dp + glowExpand, bottom + glowExpand,
                    (barWidth * dp + glowExpand * 2) / 2f,
                    (barWidth * dp + glowExpand * 2) / 2f,
                    glowPaint
                )
            }

            // Main bar
            barPaint.color = color
            canvas.drawRoundRect(
                x, top,
                x + barWidth * dp, bottom,
                barWidth * dp / 2f,   // rounded corners
                barWidth * dp / 2f,
                barPaint
            )
        }
    }

    /**
     * Interpolate between idle → active → peak colours based on amplitude (0..1).
     */
    private fun interpolateColor(amplitude: Float): Int {
        return when {
            !isListening && amplitude < 0.05f -> idleColor
            amplitude < 0.5f -> blendColor(idleColor, activeColor, amplitude * 2f)
            else -> blendColor(activeColor, peakColor, (amplitude - 0.5f) * 2f)
        }
    }

    /**
     * Blend two colours. t=0 → c1, t=1 → c2.
     */
    private fun blendColor(c1: Int, c2: Int, t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * tt).toInt()
        val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * tt).toInt()
        val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * tt).toInt()
        return Color.rgb(r, g, b)
    }

    /**
     * Clean up the animator when the view is detached.
     */
    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
        animator = null
        Log.d(TAG, "WaveformView detached, animator cancelled")
    }
}
