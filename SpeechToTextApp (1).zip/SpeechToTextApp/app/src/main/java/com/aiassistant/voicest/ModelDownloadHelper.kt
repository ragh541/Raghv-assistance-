package com.aiassistant.voicest

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * ModelDownloadHelper — Downloads and extracts the Vosk speech recognition model.
 *
 * The Vosk small model (~40MB) is downloaded on first launch and stored in the
 * app's external files directory. This is a one-time download — the model
 * persists across app updates.
 *
 * Usage:
 *   val progress = ModelDownloadHelper.downloadAndExtract(context) { percent ->
 *       // Update UI with download progress
 *   }
 *   if (progress) {
 *       // Model is ready — start HotwordDetector
 *   }
 */
object ModelDownloadHelper {

    private val TAG = "ModelDownloadHelper"

    /**
     * Check if the model has already been downloaded and extracted.
     */
    fun isModelDownloaded(context: Context): Boolean {
        val modelDir = File(context.getExternalFilesDir(null), "vosk-model")
        return modelDir.exists() &&
               File(modelDir, "am/final.mdl").exists() &&
               File(modelDir, "conf/mfcc.conf").exists()
    }

    /**
     * Get the path where the model is (or should be) stored.
     */
    fun getModelPath(context: Context): String {
        return File(context.getExternalFilesDir(null), "vosk-model").absolutePath
    }

    /**
     * Download and extract the Vosk model.
     *
     * This is a suspend function — call it from a coroutine.
     *
     * @param context Application or activity context
     * @param onProgress Callback called with download percentage (0-100)
     * @return true if download and extraction succeeded, false otherwise
     */
    suspend fun downloadAndExtract(
        context: Context,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {

        if (isModelDownloaded(context)) {
            Log.i(TAG, "Model already downloaded — skipping")
            onProgress(100)
            return@withContext true
        }

        val targetDir = context.getExternalFilesDir(null)
        if (targetDir == null) {
            Log.e(TAG, "External storage not available")
            return@withContext false
        }

        try {
            val modelUrl = HotwordDetector.MODEL_URL
            Log.i(TAG, "Downloading Vosk model from $modelUrl")
            onProgress(0)

            // Download the zip file
            val connection = URL(modelUrl).openConnection() as HttpURLConnection
            connection.connectTimeout = 30000
            connection.readTimeout = 60000
            connection.connect()

            val totalSize = connection.contentLengthLong
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(TAG, "Download failed: HTTP ${connection.responseCode}")
                return@withContext false
            }

            val zipFile = File(targetDir, "vosk-model.zip")
            var downloaded = 0L
            val buffer = ByteArray(8192)

            connection.inputStream.use { input ->
                FileOutputStream(zipFile).use { output ->
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        downloaded += bytesRead
                        if (totalSize > 0) {
                            val percent = ((downloaded * 100) / totalSize).toInt()
                            // Only report download progress up to 80% — extraction is the rest
                            onProgress((percent * 0.8).toInt())
                        }
                    }
                }
            }

            Log.i(TAG, "Download complete (${downloaded / 1024 / 1024}MB). Extracting...")
            onProgress(80)

            // Extract the zip file
            val modelDir = File(targetDir, "vosk-model")
            if (modelDir.exists()) {
                modelDir.deleteRecursively()
            }

            ZipInputStream(zipFile.inputStream()).use { zis ->
                var entry = zis.nextEntry
                var entryCount = 0

                while (entry != null) {
                    val entryName = entry.name

                    // The zip typically contains a top-level directory like
                    // "vosk-model-small-en-in-0.5/..." — we strip it and
                    // place contents directly under "vosk-model/"
                    val relativePath = if (entryName.contains("/")) {
                        // Strip the first directory component
                        entryName.substring(entryName.indexOf('/') + 1)
                    } else {
                        entryName
                    }

                    if (relativePath.isEmpty()) {
                        entry = zis.nextEntry
                        continue
                    }

                    val outFile = File(modelDir, relativePath)

                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }

                    entryCount++
                    if (entryCount % 20 == 0) {
                        // Update progress for extraction phase (80-100%)
                        onProgress(80 + (entryCount % 20))
                    }

                    entry = zis.nextEntry
                }
            }

            // Clean up the zip file
            zipFile.delete()

            // Verify the model was extracted correctly
            val isValid = isModelDownloaded(context)
            if (isValid) {
                Log.i(TAG, "Model extracted successfully to ${modelDir.absolutePath}")
                onProgress(100)
                true
            } else {
                Log.e(TAG, "Model extraction failed — files missing")
                onProgress(0)
                false
            }

        } catch (e: Exception) {
            Log.e(TAG, "Model download/extract failed: ${e.message}", e)
            onProgress(0)
            false
        }
    }
}
