package com.aiassistant.voicest

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

/**
 * CustomCommandAdapter — RecyclerView adapter for displaying custom commands.
 *
 * Each row shows the trigger phrase, action description, enable/disable toggle,
 * and a delete button.
 */
class CustomCommandAdapter(
    private var commands: MutableList<CustomCommand>,
    private val onToggle: (CustomCommand) -> Unit,
    private val onDelete: (CustomCommand) -> Unit
) : RecyclerView.Adapter<CustomCommandAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvIcon: TextView = view.findViewById(R.id.tvIcon)
        val tvTriggerPhrase: TextView = view.findViewById(R.id.tvTriggerPhrase)
        val tvActionDesc: TextView = view.findViewById(R.id.tvActionDesc)
        val switchEnabled: MaterialSwitch = view.findViewById(R.id.switchEnabled)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_custom_command, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val cmd = commands[position]

        holder.tvIcon.text = cmd.iconEmoji
        holder.tvTriggerPhrase.text = "\"${cmd.triggerPhrase}\""
        holder.tvActionDesc.text = "${cmd.getActionLabel()}: ${cmd.getDescription()}"
        holder.switchEnabled.isChecked = cmd.enabled

        holder.switchEnabled.setOnCheckedChangeListener { _, isChecked ->
            onToggle(cmd.copy(enabled = isChecked))
        }

        holder.btnDelete.setOnClickListener {
            onDelete(cmd)
        }
    }

    override fun getItemCount(): Int = commands.size

    /**
     * Update the full list and refresh.
     */
    fun updateList(newCommands: MutableList<CustomCommand>) {
        commands = newCommands
        notifyDataSetChanged()
    }
}
