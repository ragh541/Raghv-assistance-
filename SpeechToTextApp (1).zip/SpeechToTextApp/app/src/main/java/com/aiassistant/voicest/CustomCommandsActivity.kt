package com.aiassistant.voicest

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

/**
 * CustomCommandsActivity — Manage custom voice commands.
 *
 * Users can:
 * - View all custom commands in a RecyclerView
 * - Add new commands (trigger phrase → action mapping)
 * - Toggle commands on/off
 * - Delete commands
 *
 * The form lets the user specify:
 * - Trigger phrase (e.g. "set home", "goodnight", "work mode")
 * - Action type (Open App, Open URL, Call, Search, Alarm, Flashlight, etc.)
 * - Action payload (app name/package, URL, phone number, time, etc.)
 * - Display name (optional, shown in the list)
 * - Emoji icon (optional, for visual identification)
 */
class CustomCommandsActivity : AppCompatActivity() {

    private val TAG = "CustomCommandsActivity"

    private lateinit var store: CustomCommandStore
    private lateinit var adapter: CustomCommandAdapter

    private lateinit var recyclerCommands: RecyclerView
    private lateinit var formContainer: View
    private lateinit var etTriggerPhrase: TextInputEditText
    private lateinit var dropdownActionType: AutoCompleteTextView
    private lateinit var etActionPayload: TextInputEditText
    private lateinit var etDisplayName: TextInputEditText
    private lateinit var etEmoji: TextInputEditText
    private lateinit var tvEmpty: TextView

    // For editing existing commands
    private var editingId: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_custom_commands)

        store = CustomCommandStore(this)
        store.seedDefaultsIfEmpty()

        // Bind views
        val btnBack: ImageButton = findViewById(R.id.btnBack)
        val btnAdd: MaterialButton = findViewById(R.id.btnAdd)
        recyclerCommands = findViewById(R.id.recyclerCommands)
        formContainer = findViewById(R.id.formContainer)
        etTriggerPhrase = findViewById(R.id.etTriggerPhrase)
        dropdownActionType = findViewById(R.id.dropdownActionType)
        etActionPayload = findViewById(R.id.etActionPayload)
        etDisplayName = findViewById(R.id.etDisplayName)
        etEmoji = findViewById(R.id.etEmoji)
        tvEmpty = findViewById(R.id.tvEmpty)
        val btnCancelForm: MaterialButton = findViewById(R.id.btnCancelForm)
        val btnSaveCommand: MaterialButton = findViewById(R.id.btnSaveCommand)

        // Setup action type dropdown
        val actionTypes = CustomCommand.getAvailableActions().map { it.second }
        val adapterDropdown = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, actionTypes)
        dropdownActionType.setAdapter(adapterDropdown)

        // Default selection
        dropdownActionType.setText(actionTypes.first(), false)

        // Back button
        btnBack.setOnClickListener { finish() }

        // Add button — show the form
        btnAdd.setOnClickListener {
            editingId = null
            clearForm()
            formContainer.visibility = View.VISIBLE
            etTriggerPhrase.requestFocus()
        }

        // Cancel form
        btnCancelForm.setOnClickListener {
            formContainer.visibility = View.GONE
            clearForm()
        }

        // Save command
        btnSaveCommand.setOnClickListener {
            saveCommand()
        }

        // Setup RecyclerView
        adapter = CustomCommandAdapter(
            commands = store.getAll(),
            onToggle = { cmd ->
                store.toggleEnabled(cmd.id)
                refreshList()
            },
            onDelete = { cmd ->
                store.delete(cmd.id)
                refreshList()
                Toast.makeText(this, "Deleted \"${cmd.triggerPhrase}\"", Toast.LENGTH_SHORT).show()
            }
        )
        recyclerCommands.layoutManager = LinearLayoutManager(this)
        recyclerCommands.adapter = adapter

        refreshList()
    }

    /**
     * Save the command from the form fields.
     */
    private fun saveCommand() {
        val triggerPhrase = etTriggerPhrase.text.toString().trim()
        val actionTypeLabel = dropdownActionType.text.toString().trim()
        val actionPayload = etActionPayload.text.toString().trim()
        val displayName = etDisplayName.text.toString().trim()
        val emoji = etEmoji.text.toString().trim().ifEmpty { "⚡" }

        // Validate
        if (triggerPhrase.isEmpty()) {
            etTriggerPhrase.error = "Enter a trigger phrase"
            return
        }
        if (actionPayload.isEmpty() && actionTypeLabel != "Toggle Flashlight" && actionTypeLabel != "Play Music") {
            etActionPayload.error = "Enter action payload"
            return
        }

        // Map label to action type constant
        val actionType = CustomCommand.getAvailableActions().find { it.second == actionTypeLabel }?.first
            ?: CustomCommand.ActionType.OPEN_APP

        // For OPEN_APP, try to resolve the app name to a package name
        val finalPayload = if (actionType == CustomCommand.ActionType.OPEN_APP) {
            resolvePackageName(actionPayload)
        } else {
            actionPayload
        }

        val name = if (displayName.isEmpty()) triggerPhrase else displayName

        if (editingId != null) {
            // Update existing
            val cmd = CustomCommand(
                id = editingId!!,
                triggerPhrase = triggerPhrase,
                actionType = actionType,
                actionPayload = finalPayload,
                displayName = name,
                iconEmoji = emoji,
                enabled = true
            )
            store.update(cmd)
            Toast.makeText(this, "Updated \"${cmd.triggerPhrase}\"", Toast.LENGTH_SHORT).show()
        } else {
            // Add new
            val cmd = CustomCommand(
                id = CustomCommand.generateId(),
                triggerPhrase = triggerPhrase,
                actionType = actionType,
                actionPayload = finalPayload,
                displayName = name,
                iconEmoji = emoji,
                enabled = true
            )
            store.add(cmd)
            Toast.makeText(this, "Added \"${cmd.triggerPhrase}\"", Toast.LENGTH_SHORT).show()
        }

        formContainer.visibility = View.GONE
        clearForm()
        refreshList()
    }

    /**
     * Try to resolve an app name to its package name.
     * Uses the same mapping as VoiceAssistantService.
     */
    private fun resolvePackageName(appName: String): String {
        // Check if it's already a package name (contains dots)
        if (appName.contains(".") && appName.contains("com.")) {
            return appName
        }

        // Use the same mapping as the service
        return when (appName.lowercase().trim()) {
            "whatsapp" -> "com.whatsapp"
            "youtube" -> "com.google.android.youtube"
            "instagram" -> "com.instagram.android"
            "facebook" -> "com.facebook.katana"
            "maps", "google maps" -> "com.google.android.apps.maps"
            "gmail" -> "com.google.android.gm"
            "chrome" -> "com.android.chrome"
            "camera" -> "com.android.camera"
            "calculator" -> "com.android.calculator2"
            "calendar" -> "com.google.android.calendar"
            "spotify" -> "com.spotify.music"
            "telegram" -> "org.telegram.messenger"
            "twitter", "x" -> "com.twitter.android"
            "settings" -> "com.android.settings"
            "phone", "dialer" -> "com.google.android.dialer"
            "messages", "sms" -> "com.google.android.apps.messaging"
            "netflix" -> "com.netflix.mediaclient"
            "hotstar" -> "in.startv.hotstar"
            "amazon" -> "in.amazon.mShop.android.shopping"
            "flipkart" -> "com.flipkart.android"
            "paytm" -> "net.one97.paytm"
            "phonepe" -> "com.phonepe.app"
            "gpay", "google pay" -> "com.google.android.apps.nbu.paisa.user"
            "swiggy" -> "in.swiggy.android"
            "zomato" -> "com.application.zomato"
            "snapchat" -> "com.snapchat.android"
            "linkedin" -> "com.linkedin.android"
            "camera" -> "com.android.camera"
            "clock" -> "com.google.android.deskclock"
            "files" -> "com.google.android.documentsui"
            "music" -> "com.google.android.music"
            "photos" -> "com.google.android.apps.photos"
            "keep", "notes" -> "com.google.android.keep"
            else -> appName.replace(" ", "")
        }
    }

    /**
     * Clear all form fields.
     */
    private fun clearForm() {
        etTriggerPhrase.text?.clear()
        etActionPayload.text?.clear()
        etDisplayName.text?.clear()
        etEmoji.setText("⚡")
        dropdownActionType.setText(CustomCommand.getAvailableActions().first().second, false)
        editingId = null
    }

    /**
     * Refresh the RecyclerView with the latest data from the store.
     */
    private fun refreshList() {
        val commands = store.getAll()
        adapter.updateList(commands)

        // Show empty state if no commands
        tvEmpty.visibility = if (commands.isEmpty()) View.VISIBLE else View.GONE
        recyclerCommands.visibility = if (commands.isEmpty()) View.GONE else View.VISIBLE

        Log.i(TAG, "Refreshed list: ${commands.size} commands")
    }
}
