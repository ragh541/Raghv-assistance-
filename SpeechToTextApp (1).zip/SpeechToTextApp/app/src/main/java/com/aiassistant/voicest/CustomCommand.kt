package com.aiassistant.voicest

import com.google.gson.annotations.SerializedName

/**
 * CustomCommand — Represents a user-defined voice command mapping.
 *
 * Users can create custom commands that map a trigger phrase to a specific
 * phone action. For example:
 *   "set home"     → Action.OPEN_APP with payload "com.google.android.apps.maps"
 *   "goodnight"    → Action.SET_ALARM with payload "22:00"
 *   "work mode"    → Action.OPEN_APP with payload "com.google.android.keep"
 *
 * Custom commands are checked BEFORE built-in commands in VoiceAssistantService,
 * so they take priority. This lets users override built-in behaviour too.
 *
 * Storage: SharedPreferences (via CustomCommandStore), serialised to JSON.
 *
 * @param id Unique identifier (timestamp-based)
 * @param triggerPhrase The phrase the user speaks (e.g. "set home", "goodnight")
 * @param actionType What action to perform (see ActionType enum)
 * @param actionPayload The data for the action (app package name, URL, phone number, etc.)
 * @param displayName Human-readable name shown in the UI
 * @param enabled Whether this command is active
 * @param iconEmoji Optional emoji for visual identification in the list
 */
data class CustomCommand(
    @SerializedName("id")
    val id: Long,

    @SerializedName("triggerPhrase")
    val triggerPhrase: String,

    @SerializedName("actionType")
    val actionType: String,

    @SerializedName("actionPayload")
    val actionPayload: String,

    @SerializedName("displayName")
    val displayName: String,

    @SerializedName("enabled")
    var enabled: Boolean = true,

    @SerializedName("iconEmoji")
    val iconEmoji: String = "⚡"
) {

    /**
     * Action types that a custom command can perform.
     */
    object ActionType {
        const val OPEN_APP = "OPEN_APP"             // Launch an app by package name
        const val OPEN_URL = "OPEN_URL"             // Open a URL in the browser
        const val DIAL_NUMBER = "DIAL_NUMBER"        // Open dialer with a number
        const val WEB_SEARCH = "WEB_SEARCH"          // Google search
        const val SET_ALARM = "SET_ALARM"            // Set an alarm (payload: "HH:MM")
        const val TOGGLE_FLASHLIGHT = "TOGGLE_FLASHLIGHT" // Toggle torch
        const val COPY_TEXT = "COPY_TEXT"            // Copy text to clipboard
        const val PLAY_MUSIC = "PLAY_MUSIC"          // Open default music app
        const val CUSTOM_RESPONSE = "CUSTOM_RESPONSE" // Just speak a response (no action)
    }

    /**
     * Get a human-readable description of what this command does.
     */
    fun getDescription(): String {
        return when (actionType) {
            ActionType.OPEN_APP -> "Opens $actionPayload"
            ActionType.OPEN_URL -> "Opens $actionPayload in browser"
            ActionType.DIAL_NUMBER -> "Calls $actionPayload"
            ActionType.WEB_SEARCH -> "Searches \"$actionPayload\""
            ActionType.SET_ALARM -> "Sets alarm for $actionPayload"
            ActionType.TOGGLE_FLASHLIGHT -> "Toggles flashlight"
            ActionType.COPY_TEXT -> "Copies: $actionPayload"
            ActionType.PLAY_MUSIC -> "Plays music"
            ActionType.CUSTOM_RESPONSE -> "Says: \"$actionPayload\""
            else -> "Unknown action"
        }
    }

    /**
     * Get the action type as a user-friendly label.
     */
    fun getActionLabel(): String {
        return when (actionType) {
            ActionType.OPEN_APP -> "Open App"
            ActionType.OPEN_URL -> "Open URL"
            ActionType.DIAL_NUMBER -> "Call"
            ActionType.WEB_SEARCH -> "Search"
            ActionType.SET_ALARM -> "Alarm"
            ActionType.TOGGLE_FLASHLIGHT -> "Flashlight"
            ActionType.COPY_TEXT -> "Copy Text"
            ActionType.PLAY_MUSIC -> "Play Music"
            ActionType.CUSTOM_RESPONSE -> "Speak"
            else -> "Custom"
        }
    }

    companion object {
        /**
         * Generate a unique ID based on current timestamp.
         */
        fun generateId(): Long = System.currentTimeMillis()

        /**
         * Get all available action types with their labels (for UI dropdown).
         */
        fun getAvailableActions(): List<Pair<String, String>> {
            return listOf(
                ActionType.OPEN_APP to "Open App",
                ActionType.OPEN_URL to "Open URL",
                ActionType.DIAL_NUMBER to "Call Number",
                ActionType.WEB_SEARCH to "Web Search",
                ActionType.SET_ALARM to "Set Alarm",
                ActionType.TOGGLE_FLASHLIGHT to "Toggle Flashlight",
                ActionType.PLAY_MUSIC to "Play Music",
                ActionType.COPY_TEXT to "Copy Text",
                ActionType.CUSTOM_RESPONSE to "Speak Response"
            )
        }
    }
}
