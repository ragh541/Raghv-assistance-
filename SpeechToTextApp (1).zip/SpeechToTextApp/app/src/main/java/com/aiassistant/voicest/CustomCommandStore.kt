package com.aiassistant.voicest

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * CustomCommandStore — SharedPreferences-backed storage for custom voice commands.
 *
 * Stores all custom commands as a JSON array in SharedPreferences.
 * Provides CRUD operations: add, update, delete, getAll, findByTrigger.
 *
 * Usage:
 *   val store = CustomCommandStore(context)
 *   store.add(CustomCommand(...))
 *   val commands = store.getAll()
 *   val match = store.findByTrigger("set home")
 *   store.delete(id)
 */
class CustomCommandStore(context: Context) {

    private val TAG = "CustomCommandStore"
    private val PREFS_NAME = "custom_commands_prefs"
    private val KEY_COMMANDS = "custom_commands_json"

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    /**
     * Get all saved custom commands.
     */
    fun getAll(): MutableList<CustomCommand> {
        val json = prefs.getString(KEY_COMMANDS, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<CustomCommand>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse commands JSON", e)
            mutableListOf()
        }
    }

    /**
     * Save the full list (internal helper).
     */
    private fun saveAll(commands: List<CustomCommand>) {
        val json = gson.toJson(commands)
        prefs.edit().putString(KEY_COMMANDS, json).apply()
        Log.d(TAG, "Saved ${commands.size} custom commands")
    }

    /**
     * Add a new custom command.
     */
    fun add(command: CustomCommand) {
        val commands = getAll()
        commands.add(command)
        saveAll(commands)
        Log.i(TAG, "Added command: \"${command.triggerPhrase}\" → ${command.actionType}")
    }

    /**
     * Update an existing custom command by ID.
     */
    fun update(command: CustomCommand) {
        val commands = getAll()
        val index = commands.indexOfFirst { it.id == command.id }
        if (index >= 0) {
            commands[index] = command
            saveAll(commands)
            Log.i(TAG, "Updated command: ${command.triggerPhrase}")
        }
    }

    /**
     * Delete a custom command by ID.
     */
    fun delete(id: Long) {
        val commands = getAll()
        commands.removeAll { it.id == id }
        saveAll(commands)
        Log.i(TAG, "Deleted command with id=$id")
    }

    /**
     * Find a custom command whose trigger phrase matches the given text.
     * Matching is case-insensitive and checks both exact match and
     * "starts with" for phrases like "set home mode".
     *
     * Only returns enabled commands.
     *
     * @return The matching CustomCommand, or null if no match found.
     */
    fun findByTrigger(spokenText: String): CustomCommand? {
        val lower = spokenText.lowercase().trim()
        val commands = getAll()

        // First try exact match
        var match = commands.firstOrNull {
            it.enabled && it.triggerPhrase.lowercase().trim() == lower
        }

        // Then try "starts with" — allows extra words after the trigger
        if (match == null) {
            match = commands.firstOrNull {
                it.enabled && lower.startsWith(it.triggerPhrase.lowercase().trim())
            }
        }

        return match
    }

    /**
     * Toggle the enabled state of a command.
     */
    fun toggleEnabled(id: Long) {
        val commands = getAll()
        val cmd = commands.find { it.id == id }
        if (cmd != null) {
            cmd.enabled = !cmd.enabled
            saveAll(commands)
            Log.i(TAG, "Toggled command ${cmd.triggerPhrase}: enabled=${cmd.enabled}")
        }
    }

    /**
     * Get the count of saved commands.
     */
    fun count(): Int = getAll().size

    /**
     * Check if any custom commands exist.
     */
    fun hasCommands(): Boolean = getAll().isNotEmpty()

    /**
     * Add default commands on first launch (if store is empty).
     * These provide a starting point for the user.
     */
    fun seedDefaultsIfEmpty() {
        if (hasCommands()) return

        Log.i(TAG, "Seeding default custom commands...")
        add(CustomCommand(
            id = CustomCommand.generateId(),
            triggerPhrase = "set home",
            actionType = CustomCommand.ActionType.OPEN_APP,
            actionPayload = "com.google.android.apps.maps",
            displayName = "Navigate Home",
            iconEmoji = "🏠"
        ))
        add(CustomCommand(
            id = CustomCommand.generateId(),
            triggerPhrase = "goodnight",
            actionType = CustomCommand.ActionType.SET_ALARM,
            actionPayload = "07:00",
            displayName = "Bedtime Routine",
            iconEmoji = "🌙"
        ))
        add(CustomCommand(
            id = CustomCommand.generateId(),
            triggerPhrase = "work mode",
            actionType = CustomCommand.ActionType.OPEN_APP,
            actionPayload = "com.google.android.keep",
            displayName = "Work Mode",
            iconEmoji = "💼"
        ))
        Log.i(TAG, "Seeded 3 default commands")
    }
}
