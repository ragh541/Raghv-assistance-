package com.aiassistant.voicest

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import org.vosk.Model
import org.vosk.Recognizer
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

/**
 * OfflineCommandRecognizer — Vosk-based OFFLINE command recognition for Phase 2.
 *
 * WHEN INTERNET IS UNAVAILABLE, this recognizer takes over from SpeechRecognizer
 * to handle basic voice commands — completely offline, using the same Vosk model
 * that the HotwordDetector uses for wake word detection.
 *
 * HOW IT DIFFERS FROM HotwordDetector:
 * - HotwordDetector: Continuous listening, tiny grammar (just wake words), always-on
 * - OfflineCommandRecognizer: Single-utterance listening, large grammar (all known
 *   commands), has a timeout, stops after one result
 *
 * GRAMMAR APPROACH:
 * Vosk's grammar-constrained recognition is extremely accurate when the vocabulary
 * is well-defined. We build a comprehensive grammar covering:
 *   1. All built-in command phrases ("lock screen", "volume up", "mute", etc.)
 *   2. App names ("whatsapp", "youtube", "instagram", etc.)
 *   3. Numbers 0–100 (for "set volume to 50")
 *   4. Action verbs ("call", "open", "search", "set", etc.)
 *   5. Common compound phrases ("set volume to fifty", "volume up", etc.)
 *
 * When Vosk recognizes speech, it returns the closest match from the grammar.
 * The result is then passed to the same handleCommandPhase() that processes
 * online SpeechRecognizer results — so ALL command handling logic is shared.
 *
 * SUPPORTED OFFLINE COMMANDS:
 *   "lock screen" / "lock phone"        → Locks the device
 *   "volume up" / "volume down"          → Adjust volume
 *   "mute" / "unmute"                    → Toggle mute
 *   "max volume"                         → Set to 100%
 *   "set volume to 50"                   → Set specific volume
 *   "stop" / "go to sleep"               → Return to idle
 *   "what time is it"                    → Speak current time
 *   "what date" / "what day"             → Speak current date
 *   "open whatsapp" / "open youtube"    → Launch apps
 *   "call" / "dial"                      → Open dialer
 *   "play music"                         → Open music app
 *   "flashlight" / "torch"              → Toggle flashlight
 *   "hello" / "hi"                       → Greeting response
 *
 * USAGE:
 *   val recognizer = OfflineCommandRecognizer(context)
 *   recognizer.setListener(object : OfflineCommandRecognizer.Listener {
 *       override fun onCommandRecognized(text: String) {
 *           // Pass to handleCommandPhase(text)
 *       }
 *       override fun onTimeout() { /* return to idle */ }
 *       override fun onError(message: String) { /* fall back */ }
 *   })
 *   recognizer.start(timeoutMs = 8000)  // listens for 8 seconds
 *   recognizer.stop()                   // cancel early
 */
class OfflineCommandRecognizer(private val context: Context) {

    private val TAG = "OfflineCmdRecognizer"

    // ---- Audio Configuration (same as HotwordDetector) ----
    private val SAMPLE_RATE = 16000
    private val CHANNEL = AudioFormat.CHANNEL_IN_MONO
    private val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = AudioRecord.getMinBufferSize(
        SAMPLE_RATE, CHANNEL, AUDIO_FORMAT
    ).coerceAtLeast(4096)

    // ---- Vosk Components ----
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var audioRecord: AudioRecord? = null

    // ---- State ----
    @Volatile private var isRunning = false
    @Volatile private var isStopped = false
    private var recognitionThread: Thread? = null
    private var timeoutThread: Thread? = null
    private var listener: Listener? = null

    // ---- Command Grammar ----
    // Comprehensive list of phrases Vosk will try to match against.
    // [unk] catches anything else so Vosk doesn't force-match garbage.
    //
    // The grammar is built from several categories:
    //   1. Complete command phrases (exact matches)
    //   2. App names (for "open <app>")
    //   3. Numbers 0–100 (for "set volume to <n>")
    //   4. Common action words

    private val commandPhrases = listOf(
        // ── System control ──
        "lock screen", "lock phone", "lock the phone", "lock device",
        "stop", "go to sleep", "sleep", "cancel", "nevermind", "never mind",

        // ── Volume controls ──
        "volume up", "volume down", "increase volume", "decrease volume",
        "louder", "softer", "mute", "mute volume", "unmute", "unmute volume",
        "max volume", "full volume", "current volume",
        "set volume", "set volume to", "volume",

        // ── Time & date ──
        "what time is it", "what time", "what's the time", "time",
        "what date", "what day", "what's the date", "date", "today",

        // ── Greetings ──
        "hello", "hi", "hey", "good morning", "good evening", "good night",

        // ── Search ──
        "search", "google",

        // ── Alarm & timer ──
        "set alarm", "set timer",

        // ── Call / Dial ──
        "call", "dial", "phone",

        // ── Messaging ──
        "send message", "send sms", "send whatsapp",

        // ── Media ──
        "play music", "play",

        // ── Flashlight ──
        "flashlight", "torch", "torch on", "torch off",
        "flashlight on", "flashlight off",

        // ── Help ──
        "help", "what can you do"
    )

    private val appNames = listOf(
        "whatsapp", "youtube", "instagram", "facebook", "maps", "google maps",
        "gmail", "chrome", "camera", "calculator", "calendar", "spotify",
        "telegram", "twitter", "settings", "phone", "dialer", "messages",
        "netflix", "hotstar", "amazon", "flipkart", "paytm", "phonepe",
        "google pay", "swiggy", "zomato", "snapchat", "linkedin", "clock",
        "files", "music", "photos", "keep", "notes"
    )

    // Numbers for "set volume to <n>" — Vosk recognizes spoken numbers as words
    private val numberWords = listOf(
        "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
        "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
        "seventeen", "eighteen", "nineteen", "twenty", "thirty", "forty", "fifty",
        "sixty", "seventy", "eighty", "ninety", "hundred"
    )

    // Build the complete grammar JSON
    private val grammarJson: String by lazy {
        val allPhrases = mutableListOf<String>()

        // Add all command phrases
        allPhrases.addAll(commandPhrases)

        // Add "open <app>" for each app
        allPhrases.addAll(appNames.map { "open $it" })

        // Add "call <contact>" for common contacts (Indian nicknames included)
        allPhrases.addAll(listOf(
            "call mom", "call dad", "call home", "call mom mobile",
            "call mummy", "call papa", "call bhaiya", "call didi",
            "call mother", "call father", "call brother", "call sister",
            "call wife", "call husband", "call dadi", "call dada",
            "call nani", "call nana", "call office", "call work",
            "call ghar", "call friend", "call dost", "call yaar",
            "redial", "call back"
        ))

        // Add app names standalone (for partial matches)
        allPhrases.addAll(appNames)

        // Add user-defined voice shortcut keywords (index-based app launching)
        try {
            val shortcutStore = AppShortcutStore(context)
            allPhrases.addAll(shortcutStore.getAllKeywords())
        } catch (e: Exception) {
            // Ignore if shortcuts can't be loaded
        }

        // Add number words
        allPhrases.addAll(numberWords)

        // Add "set volume to <n>" for common percentages
        allPhrases.addAll(listOf(
            "set volume to zero", "set volume to ten", "set volume to twenty",
            "set volume to thirty", "set volume to forty", "set volume to fifty",
            "set volume to sixty", "set volume to seventy", "set volume to eighty",
            "set volume to ninety", "set volume to hundred"
        ))

        // Add action words
        allPhrases.addAll(listOf("open", "call", "dial", "search", "set"))

        // Build JSON grammar
        buildString {
            append("{\"grammar\":[")
            // Deduplicate
            val unique = allPhrases.distinct()
            unique.forEachIndexed { index, phrase ->
                append("\"$phrase\"")
                if (index < unique.size - 1) append(",")
            }
            append(",\"[unk]\"")
            append("]}")
        }
    }

    /**
     * Callback interface for recognition events.
     */
    interface Listener {
        /**
         * Called when a command is recognized.
         * @param text The recognized command text (e.g. "volume up", "lock screen")
         */
        fun onCommandRecognized(text: String)

        /**
         * Called when the recognition timeout expires without any result.
         */
        fun onTimeout() {}

        /**
         * Called when an error occurs during recognition.
         */
        fun onError(message: String) {}

        /**
         * Called when recognition has started successfully.
         */
        fun onStarted() {}
    }

    /**
     * Set the listener for recognition events.
     */
    fun setListener(listener: Listener) {
        this.listener = listener
    }

    /**
     * Check if the Vosk model exists (reuses the same model as HotwordDetector).
     */
    fun isModelAvailable(): Boolean {
        val modelPath = getModelPath()
        val modelDir = File(modelPath)
        val exists = modelDir.exists() && modelDir.isDirectory &&
                     File(modelDir, "am/final.mdl").exists()
        Log.d(TAG, "Model at $modelPath — available: $exists")
        return exists
    }

    /**
     * Get the Vosk model path (same as HotwordDetector).
     */
    private fun getModelPath(): String {
        return File(context.getExternalFilesDir(null), "vosk-model").absolutePath
    }

    /**
     * Start offline command recognition.
     *
     * Listens for a single utterance and returns the recognized text via
     * the listener callback. Automatically stops after the timeout.
     *
     * @param timeoutMs Maximum time to listen (default 8000ms = 8 seconds)
     */
    fun start(timeoutMs: Long = 8000L) {
        if (isRunning) {
            Log.w(TAG, "Already running — ignoring start()")
            return
        }

        if (!isModelAvailable()) {
            Log.e(TAG, "Vosk model not found — cannot do offline recognition")
            listener?.onError("Model not downloaded. Cannot recognize commands offline.")
            return
        }

        isStopped = false

        // Start the timeout watchdog thread
        timeoutThread = thread(name = "OfflineCmdTimeout", start = true) {
            try {
                Thread.sleep(timeoutMs)
                if (isRunning && !isStopped) {
                    Log.i(TAG, "⏱ Recognition timeout after ${timeoutMs}ms")
                    isStopped = true
                    stopRecording()
                    mainHandler.post { listener?.onTimeout() }
                }
            } catch (e: InterruptedException) {
                // Timeout cancelled — normal
            }
        }

        // Start recognition in a background thread
        recognitionThread = thread(name = "OfflineCmdRecognizer", start = true) {
            try {
                // Load Vosk model
                Log.i(TAG, "Loading Vosk model for offline command recognition...")
                model = Model(getModelPath())

                // Create recognizer with command grammar
                recognizer = Recognizer(model, SAMPLE_RATE.toFloat(), grammarJson)
                Log.i(TAG, "Recognizer created with ${commandPhrases.size}+ command phrases")

                // Initialize AudioRecord
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    CHANNEL,
                    AUDIO_FORMAT,
                    bufferSize * 2
                )

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioRecord failed to initialize")
                    listener?.onError("Could not access microphone.")
                    return@thread
                }

                // Start recording
                audioRecord?.startRecording()
                isRunning = true

                Log.i(TAG, "★ Offline command recognition started — listening for commands...")
                listener?.onStarted()

                // ---- Recognition loop — runs until a result is found or timeout ----
                val buffer = ShortArray(bufferSize)
                var silenceCount = 0
                val silenceThreshold = 15  // ~1.5 seconds of silence after speech = end of utterance
                var hasSeenSpeech = false

                while (isRunning && !isStopped) {
                    val readCount = audioRecord?.read(buffer, 0, buffer.size) ?: -1

                    if (readCount > 0) {
                        // Feed audio chunk to Vosk
                        val isComplete = recognizer!!.acceptWaveForm(buffer, readCount)

                        if (isComplete) {
                            // Complete utterance detected
                            val resultJson = recognizer!!.result
                            val text = extractText(resultJson)

                            if (text.isNotEmpty()) {
                                // We got a complete command!
                                Log.i(TAG, "★ OFFLINE COMMAND RECOGNIZED: \"$text\"")
                                isStopped = true
                                stopRecording()

                                finalResult = text
                                mainHandler.post { listener?.onCommandRecognized(text) }
                                break
                            }
                        } else {
                            // Check partial results — detect speech activity
                            val partialJson = recognizer!!.partialResult
                            val partial = extractPartial(partialJson)

                            if (partial.isNotEmpty() && partial != "[unk]") {
                                hasSeenSpeech = true
                                silenceCount = 0
                                Log.d(TAG, "Partial: \"$partial\"")
                            } else if (hasSeenSpeech) {
                                // Count silence after speech
                                silenceCount++
                                if (silenceCount >= silenceThreshold) {
                                    // End of utterance — get final result
                                    val finalJson = recognizer!!.result
                                    val finalText = extractText(finalJson)

                                    if (finalText.isNotEmpty()) {
                                        Log.i(TAG, "★ OFFLINE COMMAND (silence-end): \"$finalText\"")
                                        isStopped = true
                                        stopRecording()

                                        finalResult = finalText
                                        mainHandler.post { listener?.onCommandRecognized(finalText) }
                                        break
                                    } else if (hasSeenSpeech) {
                                        // We heard something but couldn't match — return partial
                                        Log.i(TAG, "★ OFFLINE COMMAND (partial fallback): \"$partial\"")
                                        // Try the last partial result
                                        isStopped = true
                                        stopRecording()

                                        finalResult = partial
                                        mainHandler.post { listener?.onCommandRecognized(partial) }
                                        break
                                    }
                                }
                            }
                        }
                    }
                }

            } catch (e: SecurityException) {
                Log.e(TAG, "Microphone permission denied", e)
                mainHandler.post { listener?.onError("Microphone permission denied.") }
            } catch (e: Exception) {
                Log.e(TAG, "Recognition error: ${e.message}", e)
                mainHandler.post { listener?.onError("Recognition error: ${e.message}") }
            } finally {
                cleanup()
            }
        }
    }

    /** Stores the final recognized text */
    private var finalResult: String = ""

    // Handler to post callbacks to the main thread
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    /**
     * Extract the "text" field from Vosk's result JSON.
     * Vosk returns: {"text":"volume up"}
     */
    private fun extractText(jsonResult: String): String {
        return try {
            val json = JSONObject(jsonResult)
            val text = json.optString("text", "").lowercase().trim()
            // Filter out [unk] — that means Vosk didn't match anything
            if (text == "[unk]" || text.isEmpty()) "" else text
        } catch (e: Exception) {
            Log.w(TAG, "Could not parse result: $jsonResult", e)
            ""
        }
    }

    /**
     * Extract the "partial" field from Vosk's partial result JSON.
     * Vosk returns: {"partial":"volume"}
     */
    private fun extractPartial(jsonResult: String): String {
        return try {
            val json = JSONObject(jsonResult)
            val partial = json.optString("partial", "").lowercase().trim()
            if (partial == "[unk]" || partial.isEmpty()) "" else partial
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Stop recording (internal — causes the read loop to exit).
     */
    private fun stopRecording() {
        isRunning = false
        try {
            audioRecord?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping AudioRecord", e)
        }
    }

    /**
     * Stop recognition immediately. Use this to cancel an in-progress recognition.
     */
    fun stop() {
        if (!isRunning && !isStopped) return
        Log.i(TAG, "Stopping offline command recognition...")
        isStopped = true
        stopRecording()

        // Cancel the timeout thread
        timeoutThread?.interrupt()
        timeoutThread = null

        // Wait for recognition thread to finish
        recognitionThread?.join(2000)
        recognitionThread = null
    }

    /**
     * Clean up all Vosk/audio resources.
     */
    private fun cleanup() {
        try {
            audioRecord?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing AudioRecord", e)
        }
        audioRecord = null

        try {
            recognizer?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing recognizer", e)
        }
        recognizer = null

        try {
            model?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing model", e)
        }
        model = null

        isRunning = false
    }

    /**
     * Check if recognition is currently running.
     */
    fun isRunning(): Boolean = isRunning

    /**
     * Release all resources — call when done with this recognizer.
     */
    fun destroy() {
        stop()
        cleanup()
    }

    /**
     * Get the last recognized result.
     */
    fun getResult(): String = finalResult

    companion object {
        /**
         * Check if the Vosk model is available at the expected path.
         * Can be called without creating an instance.
         */
        fun isModelAvailable(context: Context): Boolean {
            val modelPath = File(context.getExternalFilesDir(null), "vosk-model").absolutePath
            val modelDir = File(modelPath)
            return modelDir.exists() && modelDir.isDirectory &&
                   File(modelDir, "am/final.mdl").exists()
        }
    }
}
