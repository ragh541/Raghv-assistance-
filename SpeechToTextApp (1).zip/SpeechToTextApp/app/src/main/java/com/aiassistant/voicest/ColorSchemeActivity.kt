package com.aiassistant.voicest

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.card.MaterialCardView

/**
 * ColorSchemeActivity — Dynamic color scheme picker.
 *
 * Displays a grid of 6 color swatches (Cyan, Green, Purple, Orange, Pink, Red).
 * When the user taps a swatch:
 *   1. The scheme is saved via ThemeManager.setScheme()
 *   2. The theme overlay is applied immediately to this activity
 *   3. A Toast confirms the selection
 *   4. The user taps Back to return — MainActivity will pick up the new theme
 *      on its next onCreate() via ThemeManager.applyTheme()
 *
 * The currently selected scheme is highlighted with a thicker border.
 */
class ColorSchemeActivity : AppCompatActivity() {

    private val TAG = "ColorSchemeActivity"
    private lateinit var gridColors: GridLayout
    private lateinit var tvCurrentScheme: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply the saved theme BEFORE setContentView
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_color_scheme)

        gridColors = findViewById(R.id.gridColors)
        tvCurrentScheme = findViewById(R.id.tvCurrentScheme)
        val btnBack: ImageButton = findViewById(R.id.btnBack)

        btnBack.setOnClickListener { finish() }

        buildColorGrid()

        updateCurrentLabel()
    }

    /**
     * Build the grid of color swatch cards programmatically.
     * Each card is a MaterialCardView with a colored circle inside.
     */
    private fun buildColorGrid() {
        val schemes = ThemeManager.getAllSchemes()
        val currentScheme = ThemeManager.getScheme(this)
        val dp = resources.displayMetrics.density

        gridColors.removeAllViews()

        for (scheme in schemes) {
            // Container card
            val card = MaterialCardView(this).apply {
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = GridLayout.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
                    rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f)
                    setMargins((8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
                }
                radius = 16f
                cardElevation = 2f
                setCardBackgroundColor(Color.parseColor("#161B22"))
                strokeWidth = if (scheme == currentScheme) 3 else 1
                strokeColor = if (scheme == currentScheme) Color.parseColor(scheme.primaryColor) else Color.parseColor("#30363D")
                setPadding((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt())
                isClickable = true
                isFocusable = true
            }

            // Inner layout: circle + label
            val innerLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }

            // Color circle
            val circleSize = (56 * dp).toInt()
            val circle = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(circleSize, circleSize)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(scheme.primaryColor))
                    setStroke((2 * dp).toInt(), Color.parseColor(scheme.accentColor))
                }
            }

            // Label
            val label = TextView(this).apply {
                text = scheme.displayName
                setTextColor(Color.parseColor("#C9D1D9"))
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, (10 * dp).toInt(), 0, 0)
            }

            innerLayout.addView(circle)
            innerLayout.addView(label)
            card.addView(innerLayout)

            // Click listener — select this scheme
            card.setOnClickListener {
                Log.i(TAG, "★ User selected: ${scheme.displayName}")
                ThemeManager.setScheme(this, scheme)

                // Apply theme immediately for visual feedback
                ThemeManager.applyTheme(this)

                // Rebuild grid to update the selected border
                buildColorGrid()
                updateCurrentLabel()

                Toast.makeText(this, "${scheme.displayName} theme applied", Toast.LENGTH_SHORT).show()
            }

            gridColors.addView(card)
        }
    }

    /**
     * Update the "Current: X" label at the bottom.
     */
    private fun updateCurrentLabel() {
        val scheme = ThemeManager.getScheme(this)
        tvCurrentScheme.text = "Current: ${scheme.displayName}"
        tvCurrentScheme.setTextColor(Color.parseColor(scheme.primaryColor))
    }
}
