package com.aiassistant.voicest

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import java.util.Locale

/**
 * SpeechToTextHelper — Reusable wrapper around Android's SpeechRecognizer API.
 *
 * Features:
 * - Start/stop voice recognition
 * - Real-time partial results (live transcription as user speaks)
 * - Configurable language (default: en-US, supports hi-IN, ta-IN, etc.)
 * - Robust error handling with human-readable messages
 * - Auto-restart on certain transient errors
 * - Callback interface for UI updates
 *
 * Usage:
 *   val helper = SpeechToTextHelper(context)
 *   helper.setLanguage("hi-IN")
 *   helper.setListener(object : SpeechToTextHelper.Listener { ... })
 *   helper.startListening()
 *
 * IMPORTANT: Always call helper.destroy() in your Activity's onDestroy()
 * to prevent memory leaks from the SpeechRecognizer service.
 */
class SpeechToTextHelper(private val context: Context) {

    private val TAG = "SpeechToTextHelper"
    private var speechRecognizer: SpeechRecognizer? = null
    private var listener: Listener? = null
    private var language: String = "en-US"
    private var isListening = false
    private var autoRestart = true

    /**
     * Callback interface — implement this in your Activity/Fragment to receive results.
     */
    interface Listener {
        /** Called when recognition begins. Update UI to show "listening..." state. */
        fun onReadyForSpeech() {}

        /** Called continuously as the user speaks — provides partial transcription. */
        fun onPartialResults(partialText: String) {}

        /** Called when recognition completes — provides the final recognized text. */
        fun onResults(text: String) {}

        /** Called when an error occurs. errorText is a human-readable message. */
        fun onError(errorText: String) {}

        /** Called when the RMS (sound level) changes — useful for animating a mic icon. */
        fun onRmsChanged(rms: Float) {}

        /** Called when the recognizer begins processing audio data. */
        fun onBeginningOfSpeech() {}

        /** Called when the user stops speaking (end of speech detected). */
        fun onEndOfSpeech() {}
    }

    init {
        // Check if SpeechRecognizer is available on this device
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e(TAG, "SpeechRecognizer is NOT available on this device!")
        }
        createSpeechRecognizer()
    }

    private fun createSpeechRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    listener?.onReadyForSpeech()
                }

                override fun onBeginningOfSpeech() {
                    listener?.onBeginningOfSpeech()
                }

                override fun onRmsChanged(rms: Float) {
                    // Sound level: ranges roughly 0.0 to ~12.0+
                    listener?.onRmsChanged(rms)
                }

                override fun onBufferReceived(buffer: ByteArray?) {
                    // Raw audio buffer — typically not needed for text recognition
                }

                override fun onEndOfSpeech() {
                    isListening = false
                    listener?.onEndOfSpeech()
                }

                override fun onError(error: Int) {
                    isListening = false
                    val errorMsg = mapError(error)
                    Log.w(TAG, "Recognition error ($error): $errorMsg")
                    listener?.onError(errorMsg)

                    // Auto-restart on transient errors (if enabled)
                    if (autoRestart && (error == SpeechRecognizer.ERROR_NO_MATCH ||
                                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                        Log.i(TAG, "Auto-restarting recognition...")
                        startListening()
                    }
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.joinToString(" ")?.trim() ?: ""
                    Log.i(TAG, "Final result: \"$text\"")
                    listener?.onResults(text)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.joinToString(" ")
                        ?.trim() ?: ""
                    if (partial.isNotEmpty()) {
                        listener?.onPartialResults(partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {
                    // Reserved for future use by Android
                }
            })
        }
    }

    /**
     * Start listening for speech.
     * Creates a fresh recognition intent with current language settings.
     */
    fun startListening() {
        if (speechRecognizer == null) {
            createSpeechRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            // Use a web search-based language model for better accuracy
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)

            // Set the recognition language
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)

            // Prompt shown in the system speech dialog (if used)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...")

            // Request partial results — get live transcription as user speaks
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)

            // Allow multiple results (we take the best one)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)

            // On Android 13+, enable streaming results for better UX
            putExtra("android.speech.extra.DICTATION_MODE", true)
        }

        try {
            speechRecognizer?.startListening(intent)
            Log.i(TAG, "Started listening with language: $language")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException — RECORD_AUDIO permission not granted", e)
            listener?.onError("Microphone permission denied. Please grant permission in Settings.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening", e)
            listener?.onError("Could not start voice recognition: ${e.message}")
        }
    }

    /**
     * Stop listening manually (e.g., user taps mic button again to stop).
     */
    fun stopListening() {
        isListening = false
        speechRecognizer?.stopListening()
        Log.i(TAG, "Stopped listening")
    }

    /**
     * Set the recognition language.
     * Common values: "en-US", "en-IN", "hi-IN", "ta-IN", "bn-IN", "te-IN", "mr-IN"
     */
    fun setLanguage(lang: String) {
        this.language = lang
    }

    /**
     * Enable or disable auto-restart on transient errors (NO_MATCH, SPEECH_TIMEOUT).
     * Default: true
     */
    fun setAutoRestart(enabled: Boolean) {
        this.autoRestart = enabled
    }

    /**
     * Check if the recognizer is currently listening.
     */
    fun isListening(): Boolean = isListening

    /**
     * Map Android error codes to human-readable messages.
     */
    private fun mapError(error: Int): String {
        return when (error) {
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "Network timeout. Check your internet connection."
            SpeechRecognizer.ERROR_NETWORK ->
                "Network error. Check your internet connection."
            SpeechRecognizer.ERROR_AUDIO ->
                "Audio recording error. Microphone may be in use."
            SpeechRecognizer.ERROR_SERVER ->
                "Server error. Try again in a moment."
            SpeechRecognizer.ERROR_CLIENT ->
                "Client error. Try restarting the app."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "No speech detected. Try speaking again."
            SpeechRecognizer.ERROR_NO_MATCH ->
                "Could not recognize speech. Please try again."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                "Recognizer is busy. Wait a moment and try again."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "Insufficient permissions. Grant microphone access in Settings."
            else -> "Unknown error occurred (code: $error)."
        }
    }

    /**
     * Register a listener to receive callbacks.
     */
    fun setListener(listener: Listener) {
        this.listener = listener
    }

    /**
     * Clean up — MUST be called from Activity.onDestroy() to prevent memory leaks.
     */
    fun destroy() {
        isListening = false
        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
        Log.i(TAG, "SpeechRecognizer destroyed")
    }
}
