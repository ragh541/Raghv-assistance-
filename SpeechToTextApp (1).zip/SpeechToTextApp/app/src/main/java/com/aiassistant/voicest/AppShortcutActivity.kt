package com.aiassistant.voicest

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/**
 * AppShortcutActivity — UI for managing index-based voice shortcuts.
 *
 * Users can:
 *  - See all configured keyword→app shortcuts
 *  - Add a new shortcut (keyword + select from installed apps)
 *  - Edit/delete existing shortcuts
 *  - Toggle shortcuts on/off
 *
 * The shortcuts are stored via AppShortcutStore and checked in
 * VoiceAssistantService BEFORE "open <app>" commands.
 */
class AppShortcutActivity : AppCompatActivity() {

    private val TAG = "AppShortcutActivity"
    private lateinit var store: AppShortcutStore
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AppShortcutAdapter
    private lateinit var btnAdd: MaterialButton
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_shortcuts)

        store = AppShortcutStore(this)
        store.seedDefaultsIfEmpty()

        title = "Voice Shortcuts"

        recyclerView = findViewById(R.id.rvAppShortcuts)
        btnAdd = findViewById(R.id.btnAddShortcut)
        tvEmpty = findViewById(R.id.tvEmptyShortcuts)

        adapter = AppShortcutAdapter(
            shortcuts = store.getAll(),
            onMenuClick = { shortcut, anchorView -> showItemMenu(shortcut, anchorView) },
            onToggle = { shortcut ->
                store.toggleEnabled(shortcut.id)
                refreshList()
            }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        btnAdd.setOnClickListener {
            showAddDialog()
        }

        updateEmptyState()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        adapter.updateData(store.getAll())
        updateEmptyState()
    }

    private fun updateEmptyState() {
        if (store.count() == 0) {
            tvEmpty.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    /**
     * Show a popup menu for a shortcut item: Edit, Delete, Toggle.
     */
    private fun showItemMenu(shortcut: AppShortcut, anchorView: View) {
        val popup = PopupMenu(this, anchorView)
        popup.menu.add(0, 1, 0, if (shortcut.enabled) "Disable" else "Enable")
        popup.menu.add(0, 2, 1, "Edit")
        popup.menu.add(0, 3, 2, "Delete")

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    store.toggleEnabled(shortcut.id)
                    refreshList()
                    true
                }
                2 -> {
                    showEditDialog(shortcut)
                    true
                }
                3 -> {
                    store.delete(shortcut.id)
                    refreshList()
                    Toast.makeText(this, "Shortcut deleted", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    /**
     * Show the Add Shortcut dialog.
     * User enters a keyword, then picks an installed app from a list.
     */
    private fun showAddDialog() {
        showShortcutDialog(null)
    }

    /**
     * Show the Edit Shortcut dialog.
     */
    private fun showEditDialog(shortcut: AppShortcut) {
        showShortcutDialog(shortcut)
    }

    /**
     * Combined add/edit dialog.
     */
    private fun showShortcutDialog(existing: AppShortcut?) {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_shortcut, null)

        val tilKeyword: TextInputLayout = dialogView.findViewById(R.id.tilKeyword)
        val etKeyword: TextInputEditText = dialogView.findViewById(R.id.etKeyword)
        val tvSelectedApp: TextView = dialogView.findViewById(R.id.tvSelectedApp)
        val btnSelectApp: MaterialButton = dialogView.findViewById(R.id.btnSelectApp)

        var selectedPackageName = existing?.packageName ?: ""
        var selectedAppLabel = existing?.appLabel ?: ""

        if (existing != null) {
            etKeyword.setText(existing.keyword)
            tvSelectedApp.text = "→ $selectedAppLabel"
        }

        // App picker
        btnSelectApp.setOnClickListener {
            showAppPickerDialog { packageName, label ->
                selectedPackageName = packageName
                selectedAppLabel = label
                tvSelectedApp.text = "→ $label"
                tvSelectedApp.setTextColor(getColor(R.color.text_accent_blue))
            }
        }

        val title = if (existing != null) "Edit Shortcut" else "New Voice Shortcut"

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton(if (existing != null) "Update" else "Add") { _, _ ->
                val keyword = etKeyword.text?.toString()?.trim() ?: ""

                if (keyword.isEmpty()) {
                    Toast.makeText(this, "Please enter a keyword", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (selectedPackageName.isEmpty()) {
                    Toast.makeText(this, "Please select an app", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (existing != null) {
                    // Update
                    store.update(AppShortcut(
                        id = existing.id,
                        keyword = keyword,
                        packageName = selectedPackageName,
                        appLabel = selectedAppLabel,
                        enabled = existing.enabled
                    ))
                    Toast.makeText(this, "Shortcut updated", Toast.LENGTH_SHORT).show()
                } else {
                    // Add new
                    if (store.keywordExists(keyword)) {
                        Toast.makeText(this, "Keyword \"$keyword\" already exists", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    store.add(AppShortcut(
                        id = AppShortcut.generateId(),
                        keyword = keyword,
                        packageName = selectedPackageName,
                        appLabel = selectedAppLabel
                    ))
                    Toast.makeText(this, "Shortcut added: \"$keyword\" → $selectedAppLabel", Toast.LENGTH_SHORT).show()
                }
                refreshList()
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    /**
     * Show a dialog listing installed apps for the user to pick from.
     * Filters to launchable apps only (apps with a launcher intent).
     */
    private fun showAppPickerDialog(onPicked: (packageName: String, label: String) -> Unit) {
        // Get all launchable apps
        val pm = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
            .map { ri ->
                val label = ri.loadLabel(pm).toString()
                val pkg = ri.activityInfo.packageName
                Triple(label, pkg, ri)
            }
            .sortedBy { it.first.lowercase() }

        if (apps.isEmpty()) {
            Toast.makeText(this, "No installed apps found", Toast.LENGTH_SHORT).show()
            return
        }

        // Build label list for the dialog
        val labels = apps.map { "${it.first}" }
        val checkedItem = intArrayOf(-1)

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Select App (${apps.size} installed)")
            .setItems(labels.toTypedArray()) { _, which ->
                val app = apps[which]
                onPicked(app.second, app.first)
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }
}

// ──────────────────────────────────────────────────────────
//  RecyclerView Adapter
// ──────────────────────────────────────────────────────────

/**
 * Adapter for displaying voice shortcuts in a RecyclerView.
 * Each item shows: keyword → app name, with a toggle and overflow menu.
 */
class AppShortcutAdapter(
    private var shortcuts: MutableList<AppShortcut>,
    private val onMenuClick: (AppShortcut, View) -> Unit,
    private val onToggle: (AppShortcut) -> Unit
) : RecyclerView.Adapter<AppShortcutAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvKeyword: TextView = view.findViewById(R.id.tvShortcutKeyword)
        val tvApp: TextView = view.findViewById(R.id.tvShortcutApp)
        val btnMenu: MaterialButton = view.findViewById(R.id.btnShortcutMenu)
        val switchToggle: com.google.android.material.materialswitch.MaterialSwitch =
            view.findViewById(R.id.switchShortcutToggle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_shortcut, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val shortcut = shortcuts[position]
        holder.tvKeyword.text = "\"${shortcut.keyword}\""
        holder.tvApp.text = "→ ${shortcut.appLabel}"

        // Dim if disabled
        val alpha = if (shortcut.enabled) 1.0f else 0.4f
        holder.tvKeyword.alpha = alpha
        holder.tvApp.alpha = alpha

        holder.switchToggle.isChecked = shortcut.enabled
        holder.switchToggle.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked != shortcut.enabled) {
                onToggle(shortcut)
            }
        }

        holder.btnMenu.setOnClickListener {
            onMenuClick(shortcut, it)
        }
    }

    override fun getItemCount(): Int = shortcuts.size

    fun updateData(newShortcuts: MutableList<AppShortcut>) {
        shortcuts = newShortcuts
        notifyDataSetChanged()
    }
}
