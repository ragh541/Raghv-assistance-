package com.aiassistant.voicest

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import org.vosk.Model
import org.vosk.Recognizer
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

/**
 * HotwordDetector — Dedicated OFFLINE hotword detection using the Vosk library.
 *
 * WHY THIS EXISTS:
 * Android's SpeechRecognizer has inherent problems for always-on wake word detection:
 * - Gaps of 300-500ms between recognition cycles (misses can occur)
 * - Requires internet (cloud-based recognition)
 * - Drains battery faster due to cloud round-trips
 * - Can be killed by Android's memory management between cycles
 *
 * This HotwordDetector solves all of that:
 * - 100% OFFLINE — no internet needed, all processing on-device
 * - CONTINUOUS — no gaps, AudioRecord streams continuously to Vosk
 * - LIGHTWEIGHT — uses Vosk's small model (~50MB) with grammar constrained
 *   to ONLY the hotword, so recognition is extremely fast
 * - LOW BATTERY — Vosk's keyword spotting mode uses far less CPU than
 *   cloud-based SpeechRecognizer
 *
 * HOW IT WORKS:
 * 1. AudioRecord captures 16kHz mono PCM audio in a background thread
 * 2. Audio chunks are fed to Vosk Recognizer which has a grammar of
 *    ONLY ["raghav", "raghv", "raghu", "raghvant", "[unk]"]
 * 3. When Vosk returns a result matching one of the hotwords, the callback fires
 * 4. The audio thread keeps running — no restart needed, truly continuous
 *
 * MODEL SETUP:
 * The Vosk model must be downloaded on first launch (see ModelDownloadHelper).
 * The small English model (vosk-model-small-en-in-0.5, ~40MB) works well for
 * Indian English accents. The model is stored at:
 *   /sdcard/Android/data/com.aiassistant.voicest/files/vosk-model/
 *
 * USAGE:
 *   val detector = HotwordDetector(context)
 *   detector.setListener(object : HotwordDetector.Listener {
 *       override fun onHotwordDetected(word: String) {
 *           // Wake word "Raghav" was heard — activate command mode
 *       }
 *       override fun onError(message: String) { ... }
 *   })
 *   detector.start()  // begins listening
 *   detector.stop()   // stops listening
 *
 * Thread Safety:
 * - start() and stop() are safe to call from any thread
 * - onHotwordDetected is called on a background thread — switch to main
 *   thread if updating UI
 */
class HotwordDetector(private val context: Context) {

    private val TAG = "HotwordDetector"

    // ---- Audio Configuration ----
    private val SAMPLE_RATE = 16000          // Vosk requires 16kHz
    private val CHANNEL = AudioFormat.CHANNEL_IN_MONO
    private val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT

    // Buffer size for AudioRecord — Vosk processes chunks of this size
    private val bufferSize = AudioRecord.getMinBufferSize(
        SAMPLE_RATE, CHANNEL, AUDIO_FORMAT
    ).coerceAtLeast(4096)  // Minimum 4096 samples

    // ---- Vosk Components ----
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var audioRecord: AudioRecord? = null

    // ---- State ----
    @Volatile private var isRunning = false
    private var detectionThread: Thread? = null
    private var listener: Listener? = null

    // ---- Hotword Grammar ----
    // The grammar restricts Vosk to ONLY recognise these words.
    // [unk] catches everything else so Vosk doesn't try to match
    // non-hotword speech — this makes detection very fast and accurate.
    private val hotwords = listOf("raghav", "raghv", "raghu", "raghvant")
    private val grammarJson = buildString {
        append("{\"grammar\":[")
        hotwords.forEachIndexed { index, word ->
            append("\"$word\"")
            if (index < hotwords.size - 1) append(",")
        }
        append(",\"[unk]\"")
        append("]}")
    }

    /**
     * Callback interface for hotword detection events.
     */
    interface Listener {
        /**
         * Called when the hotword is detected.
         * @param word The specific variation that was detected (e.g. "raghav")
         */
        fun onHotwordDetected(word: String)

        /**
         * Called when an error occurs.
         */
        fun onError(message: String) {}

        /**
         * Called when detection has started successfully.
         */
        fun onStarted() {}

        /**
         * Called when detection has stopped.
         */
        fun onStopped() {}
    }

    /**
     * Check if the Vosk model exists at the expected path.
     */
    fun isModelAvailable(): Boolean {
        val modelPath = getModelPath()
        val modelDir = File(modelPath)
        val exists = modelDir.exists() && modelDir.isDirectory &&
                     File(modelDir, "am/final.mdl").exists()
        Log.d(TAG, "Model at $modelPath — available: $exists")
        return exists
    }

    /**
     * Get the path where the Vosk model should be stored.
     * Uses the app's external files directory so it persists across app updates.
     */
    private fun getModelPath(): String {
        return File(context.getExternalFilesDir(null), "vosk-model").absolutePath
    }

    /**
     * Set the listener for hotword events.
     */
    fun setListener(listener: Listener) {
        this.listener = listener
    }

    /**
     * Start hotword detection.
     * Initializes Vosk model + recognizer, starts AudioRecord, and begins
     * the detection thread. If already running, does nothing.
     */
    fun start() {
        if (isRunning) {
            Log.w(TAG, "Already running — ignoring start()")
            return
        }

        // Check if model is available
        if (!isModelAvailable()) {
            Log.e(TAG, "Vosk model not found at ${getModelPath()}")
            listener?.onError("Model not downloaded. Please download the model first.")
            return
        }

        // Initialize in a background thread (model loading takes ~1-2 seconds)
        detectionThread = thread(name = "HotwordDetector", start = true) {
            try {
                // Load Vosk model
                Log.i(TAG, "Loading Vosk model from ${getModelPath()}...")
                model = Model(getModelPath())

                // Create recognizer with hotword grammar
                recognizer = Recognizer(model, SAMPLE_RATE.toFloat(), grammarJson)
                Log.i(TAG, "Recognizer created with grammar: $grammarJson")

                // Initialize AudioRecord
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,  // Optimised for voice
                    SAMPLE_RATE,
                    CHANNEL,
                    AUDIO_FORMAT,
                    bufferSize * 2  // Double buffer for safety
                )

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioRecord failed to initialize")
                    listener?.onError("Could not access microphone. Check permissions.")
                    return@thread
                }

                // Start recording
                audioRecord?.startRecording()
                isRunning = true

                Log.i(TAG, "★ Hotword detection started — listening for: $hotwords")
                listener?.onStarted()

                // ---- Main detection loop ----
                val buffer = ShortArray(bufferSize)
                while (isRunning) {
                    val readCount = audioRecord?.read(buffer, 0, buffer.size) ?: -1

                    if (readCount > 0) {
                        // Feed audio chunk to Vosk
                        // acceptWaveform returns true when a complete utterance is detected
                        val result = if (recognizer!!.acceptWaveForm(buffer, readCount)) {
                            // Complete utterance — get full result JSON
                            recognizer!!.result
                        } else {
                            // Partial result — check if it contains the hotword
                            recognizer!!.partialResult
                        }

                        // Check if the result contains a hotword
                        val detected = checkForHotword(result)
                        if (detected != null) {
                            Log.i(TAG, "★ HOTWORD DETECTED: \"$detected\"")
                            listener?.onHotwordDetected(detected)

                            // Reset recognizer to avoid duplicate detections
                            recognizer!!.reset()
                        }
                    }
                }

            } catch (e: SecurityException) {
                Log.e(TAG, "Microphone permission denied", e)
                listener?.onError("Microphone permission denied.")
            } catch (e: Exception) {
                Log.e(TAG, "Hotword detection error: ${e.message}", e)
                listener?.onError("Detection error: ${e.message}")
            } finally {
                cleanup()
                listener?.onStopped()
                Log.i(TAG, "Hotword detection stopped")
            }
        }
    }

    /**
     * Parse Vosk result JSON and check if it contains a hotword.
     * Vosk returns JSON like: {"text":"raghav","partial":"raghav"}
     */
    private fun checkForHotword(jsonResult: String): String? {
        return try {
            val json = JSONObject(jsonResult)

            // Check full text result
            val text = json.optString("text", "").lowercase().trim()
            if (hotwords.any { text == it || text.contains(" $it ") || text.startsWith("$it ") }) {
                return hotwords.find { text.contains(it) }
            }

            // Check partial result (faster feedback for user)
            val partial = json.optString("partial", "").lowercase().trim()
            if (hotwords.any { partial == it || partial.contains(" $it ") || partial.startsWith("$it ") }) {
                return hotwords.find { partial.contains(it) }
            }

            null
        } catch (e: Exception) {
            Log.w(TAG, "Could not parse result: $jsonResult", e)
            null
        }
    }

    /**
     * Stop hotword detection.
     * Stops AudioRecord and the detection thread.
     */
    fun stop() {
        if (!isRunning) return
        Log.i(TAG, "Stopping hotword detection...")
        isRunning = false

        // Stop AudioRecord (this will cause the read loop to exit)
        try {
            audioRecord?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping AudioRecord", e)
        }

        // Wait for thread to finish
        detectionThread?.join(2000)
        detectionThread = null
    }

    /**
     * Clean up all resources.
     */
    private fun cleanup() {
        try {
            audioRecord?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing AudioRecord", e)
        }
        audioRecord = null

        recognizer?.close()
        recognizer = null

        model?.close()
        model = null

        isRunning = false
    }

    /**
     * Check if the detector is currently running.
     */
    fun isRunning(): Boolean = isRunning

    /**
     * Release all resources — call when the service is destroyed.
     */
    fun destroy() {
        stop()
        cleanup()
    }

    companion object {
        /**
         * The URL for downloading the Vosk small English model.
         * This is the India-English model which works well for Indian accents.
         *
         * Alternative models:
         * - Small general English: https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
         * - Hindi: https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip
         */
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.5.zip"

        /**
         * Expected size of the model zip (~40MB).
         */
        const val MODEL_SIZE_BYTES = 40_000_000L
    }
}

// Extension function to bridge Vosk's Java API naming
private fun Recognizer.acceptWaveForm(buffer: ShortArray, count: Int): Boolean {
    return this.acceptWaveForm(buffer, count)
}
