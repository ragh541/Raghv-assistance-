package com.aiassistant.voicest

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

/**
 * MainActivity — Voice Assistant with Speech-to-Text & Command Processing.
 *
 * Flow:
 * 1. User taps mic button → request mic permission if needed → start listening
 * 2. SpeechToTextHelper captures audio → returns partial & final results
 * 3. Final result is processed → commands detected (call, open app, set alarm, etc.)
 * 4. Result displayed on screen
 *
 * Supported voice commands:
 * - "call <name>"          → Open dialer (contact matching can be extended)
 * - "open <app name>"      → Launch installed app by name
 * - "set alarm <time>"     → Open alarm with parsed time
 * - "set timer <seconds>"  → Set a timer
 * - "search <query>"       → Open Google search
 * - "what time is it"      → Speak current time
 * - "open <website>"       → Open URL in browser
 */
class MainActivity : AppCompatActivity(), SpeechToTextHelper.Listener {

    private val TAG = "MainActivity"

    private lateinit var btnMic: FloatingActionButton
    private lateinit var tvResult: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvCommand: TextView
    private lateinit var waveform: WaveformView
    private lateinit var switchHandsFree: com.google.android.material.materialswitch.MaterialSwitch
    private lateinit var tvHandsFreeHint: TextView
    private lateinit var commandDisplay: CommandDisplayView

    private lateinit var speechHelper: SpeechToTextHelper
    private var isListening = false
    private var pendingHandsFree = false   // True if permission was requested for hands-free mode

    /**
     * Permission launcher — handles RECORD_AUDIO + READ_CONTACTS + CALL_PHONE permission requests.
     * Multiple permissions are requested together so the user sees one clean dialog.
     */
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val audioGranted = results[Manifest.permission.RECORD_AUDIO] ?: false
        val contactsGranted = results[Manifest.permission.READ_CONTACTS] ?: false
        val callGranted = results[Manifest.permission.CALL_PHONE] ?: false

        if (audioGranted) {
            Log.i(TAG, "RECORD_AUDIO permission granted")
            if (pendingHandsFree) {
                pendingHandsFree = false
                // Re-enable hands-free mode now that permission is granted
                switchHandsFree.isChecked = true
                enableHandsFreeMode()
            } else {
                startSpeechRecognition()
            }
        } else {
            Log.w(TAG, "RECORD_AUDIO permission denied")
            pendingHandsFree = false
            switchHandsFree.isChecked = false
            tvStatus.text = "Microphone permission required"
            Toast.makeText(this, "Please grant microphone permission in Settings", Toast.LENGTH_LONG).show()

            // If denied permanently, guide user to settings
            if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                showAppSettings()
            }
        }

        if (contactsGranted) {
            Log.i(TAG, "READ_CONTACTS permission granted — contact lookup for calls is now available")
        } else {
            Log.w(TAG, "READ_CONTACTS permission denied — call by contact name won't work, only raw numbers")
        }

        if (callGranted) {
            Log.i(TAG, "CALL_PHONE permission granted — direct calling enabled")
        } else {
            Log.w(TAG, "CALL_PHONE permission denied — will fall back to dialer")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Apply saved color scheme BEFORE setContentView so views inflate with correct colors
        ThemeManager.applyTheme(this)
        setContentView(R.layout.activity_main)

        // Bind views
        btnMic = findViewById(R.id.btnMic)
        tvResult = findViewById(R.id.tvResult)
        tvStatus = findViewById(R.id.tvStatus)
        tvCommand = findViewById(R.id.tvCommand)
        waveform = findViewById(R.id.waveform)
        switchHandsFree = findViewById(R.id.switchHandsFree)
        tvHandsFreeHint = findViewById(R.id.tvHandsFreeHint)
        commandDisplay = findViewById(R.id.commandDisplay)

        // Initialize Speech-to-Text helper
        speechHelper = SpeechToTextHelper(this)
        speechHelper.setListener(this)

        // Mic button click — toggle listening
        btnMic.setOnClickListener {
            if (isListening) {
                speechHelper.stopListening()
                waveform.stopListening()
                isListening = false
                tvStatus.text = "Stopped"
            } else {
                checkPermissionAndStart()
            }
        }

        // Custom Commands button — open the custom commands management screen
        val btnCustomCommands: com.google.android.material.button.MaterialButton =
            findViewById(R.id.btnCustomCommands)
        btnCustomCommands.setOnClickListener {
            val intent = Intent(this, CustomCommandsActivity::class.java)
            startActivity(intent)
        }

        // Color Scheme button — open the color scheme picker
        val btnColorScheme: com.google.android.material.button.MaterialButton =
            findViewById(R.id.btnColorScheme)
        btnColorScheme.setOnClickListener {
            val intent = Intent(this, ColorSchemeActivity::class.java)
            startActivity(intent)
        }

        // Voice Shortcuts button — open the app shortcuts manager
        val btnVoiceShortcuts: com.google.android.material.button.MaterialButton =
            findViewById(R.id.btnVoiceShortcuts)
        btnVoiceShortcuts.setOnClickListener {
            val intent = Intent(this, AppShortcutActivity::class.java)
            startActivity(intent)
        }

        // Hands-Free toggle — starts/stops the always-listening background service
        switchHandsFree.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                enableHandsFreeMode()
            } else {
                disableHandsFreeMode()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // If the user changed the color scheme in ColorSchemeActivity, recreate
        // this activity so the new theme overlay takes effect on all views.
        if (ThemeManager.themeChanged) {
            ThemeManager.themeChanged = false
            recreate()
        }
    }

    /**
     * Enable Hands-Free mode — request permissions, then start the
     * VoiceAssistantService (always-listening foreground service).
     * The service runs in the background and executes voice commands
     * without the user touching the phone.
     */
    private fun enableHandsFreeMode() {
        // Collect all permissions that are needed but not yet granted
        val needed = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_CONTACTS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CALL_PHONE)
        }

        if (needed.isNotEmpty()) {
            // Set flag so permission callback knows to start hands-free mode
            pendingHandsFree = true
            switchHandsFree.isChecked = false
            requestPermissionLauncher.launch(needed.toTypedArray())
            Toast.makeText(this,
                "Permissions needed for hands-free mode and calling",
                Toast.LENGTH_LONG).show()
            return
        }

        // Check POST_NOTIFICATIONS permission (Android 13+)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                // Continue starting the service even if notification permission is denied
                // — the service will still work, just without a visible notification
            }
        }

        // Request battery optimization exemption — CRITICAL for lock-screen listening.
        // Without this, Android will kill the service when the screen is off,
        // and the wake word won't be detected.
        requestBatteryOptimizationExemption()

        // Check if Vosk model is downloaded — if not, download it before starting
        if (!ModelDownloadHelper.isModelDownloaded(this)) {
            downloadVoskModel()
            return  // Service will start after model download completes
        }

        // Start the hands-free service
        tvHandsFreeHint.visibility = android.view.View.VISIBLE
        tvStatus.text = "Say \"Raghv\" to activate"
        VoiceAssistantService.start(this)
        Toast.makeText(this,
            "Hands-free mode ON — say \"Raghv\" then your command",
            Toast.LENGTH_LONG).show()
    }

    /**
     * Disable Hands-Free mode — stop the background listening service.
     */
    private fun disableHandsFreeMode() {
        VoiceAssistantService.stop(this)
        tvHandsFreeHint.visibility = android.view.View.GONE
        tvStatus.text = "Tap mic to speak"
        Toast.makeText(this, "Hands-free mode OFF", Toast.LENGTH_SHORT).show()
    }

    /**
     * Request battery optimization exemption — prevents Android from killing
     * the always-listening service when the screen is off.
     *
     * This opens the system "Ignore battery optimization" dialog for the user
     * to approve. Without this, Android's Doze mode will suspend the service
     * after a few minutes of screen-off, and the wake word won't work.
     *
     * Only needed on Android 6 (API 23) and above.
     */
    private fun requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            val isIgnoring = powerManager.isIgnoringBatteryOptimizations(packageName)

            if (!isIgnoring) {
                Log.i(TAG, "Requesting battery optimization exemption")
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    Toast.makeText(
                        this,
                        "Please allow battery optimization exemption to keep the assistant listening when the screen is off.",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Log.w(TAG, "Could not request battery optimization exemption", e)
                    // Fallback — open battery optimization settings directly
                    try {
                        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        startActivity(intent)
                    } catch (e2: Exception) {
                        Log.e(TAG, "Battery optimization settings not accessible", e2)
                    }
                }
            } else {
                Log.i(TAG, "Already exempt from battery optimization")
            }
        }
    }

    /**
     * Download the Vosk speech model for offline hotword detection.
     * Shows progress in the status text and starts the service when done.
     */
    private fun downloadVoskModel() {
        tvStatus.text = "Downloading speech model (one-time, ~40MB)..."
        tvHandsFreeHint.visibility = android.view.View.VISIBLE
        tvHandsFreeHint.text = "Downloading offline model for hotword detection..."

        lifecycleScope.launch {
            val success = ModelDownloadHelper.downloadAndExtract(this@MainActivity) { percent ->
                runOnUiThread {
                    tvStatus.text = "Downloading model: $percent%"
                }
            }

            if (success) {
                tvStatus.text = "Model downloaded! Starting hands-free..."
                tvHandsFreeHint.text = "Say "Raghav" to wake the assistant, then speak your command"
                Toast.makeText(this@MainActivity,
                    "Model ready! Hotword detection is now offline.",
                    Toast.LENGTH_LONG).show()

                // Now start the service
                VoiceAssistantService.start(this@MainActivity)
            } else {
                tvStatus.text = "Download failed. Using cloud-based fallback."
                tvHandsFreeHint.visibility = android.view.View.GONE
                switchHandsFree.isChecked = false
                Toast.makeText(this@MainActivity,
                    "Could not download offline model. The assistant will use cloud-based detection (needs internet).",
                    Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Permission launcher for POST_NOTIFICATIONS (Android 13+).
     */
    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (!isGranted) {
            Log.w(TAG, "POST_NOTIFICATIONS permission denied — service notification may not show")
        }
        // Start the service regardless — it can function without notification visibility
        tvHandsFreeHint.visibility = android.view.View.VISIBLE
        tvStatus.text = "Say \"Raghv\" to activate"
        VoiceAssistantService.start(this)
    }

    /**
     * Check if RECORD_AUDIO permission is granted; request if not.
     * Also requests READ_CONTACTS and CALL_PHONE for calling functionality.
     */
    private fun checkPermissionAndStart() {
        when {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {
                // Permission already granted — start recognition
                startSpeechRecognition()
                // Also request contacts + call permissions if not yet granted
                val contactPerm = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.READ_CONTACTS
                ) == PackageManager.PERMISSION_GRANTED
                val callPerm = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.CALL_PHONE
                ) == PackageManager.PERMISSION_GRANTED
                if (!contactPerm || !callPerm) {
                    requestPermissionLauncher.launch(
                        arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
                    )
                }
            }
            shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO) -> {
                // Show rationale, then request
                tvStatus.text = "Microphone access needed to hear your voice commands"
                requestPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.CALL_PHONE
                    )
                )
            }
            else -> {
                // Request permission directly
                requestPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.CALL_PHONE
                    )
                )
            }
        }
    }

    /**
     * Start speech recognition — update UI to "listening" state.
     */
    private fun startSpeechRecognition() {
        tvResult.text = ""
        tvCommand.text = ""
        tvStatus.text = "Listening..."
        btnMic.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.holo_red_light)
        waveform.startListening()
        commandDisplay.setState(CommandDisplayView.State.LISTENING)
        speechHelper.startListening()
        isListening = true
    }

    // ============================================================
    // SpeechToTextHelper.Listener callbacks
    // ============================================================

    override fun onReadyForSpeech() {
        runOnUiThread {
            tvStatus.text = "Listening..."
            commandDisplay.setState(CommandDisplayView.State.LISTENING)
        }
    }

    override fun onBeginningOfSpeech() {
        runOnUiThread {
            tvStatus.text = "Hearing you..."
        }
    }

    override fun onRmsChanged(rms: Float) {
        // Feed RMS to waveform for real-time visual feedback
        waveform.updateRms(rms)
    }

    override fun onPartialResults(partialText: String) {
        runOnUiThread {
            tvResult.text = partialText
            tvResult.setTextColor(getColor(android.R.color.holo_blue_light))
            // Show partial text as it comes in
            commandDisplay.setCommand(partialText)
            commandDisplay.setState(CommandDisplayView.State.RECOGNIZED)
        }
    }

    override fun onEndOfSpeech() {
        runOnUiThread {
            tvStatus.text = "Processing..."
            btnMic.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.darker_gray)
            waveform.stopListening()
            commandDisplay.setState(CommandDisplayView.State.PROCESSING)
        }
    }

    override fun onResults(text: String) {
        runOnUiThread {
            tvResult.text = text
            tvResult.setTextColor(getColor(android.R.color.white))
            tvStatus.text = "Done"

            // Show the recognized command with typewriter animation
            commandDisplay.setCommand(text)
            commandDisplay.setState(CommandDisplayView.State.RECOGNIZED)

            // Process the recognized text as a command
            val commandResult = processVoiceCommand(text)
            tvCommand.text = commandResult

            // Show result on the command display
            commandDisplay.setResult(commandResult)
            commandDisplay.setState(CommandDisplayView.State.COMPLETE)
        }
    }

    override fun onError(errorText: String) {
        runOnUiThread {
            tvStatus.text = "Error"
            tvCommand.text = errorText
            btnMic.backgroundTintList = ContextCompat.getColorStateList(this, R.color.purple_500)
            waveform.stopListening()
            commandDisplay.setCommand(errorText)
            commandDisplay.setResult(errorText)
            commandDisplay.setState(CommandDisplayView.State.ERROR)
            isListening = false
            Toast.makeText(this, errorText, Toast.LENGTH_SHORT).show()
        }
    }

    // ============================================================
    // Voice Command Processing
    // ============================================================

    /**
     * Process the recognized text and execute matching commands.
     * Returns a human-readable description of what action was taken.
     */
    private fun processVoiceCommand(text: String): String {
        val command = text.lowercase(Locale.getDefault()).trim()
        Log.i(TAG, "Processing command: $command")

        // ── Check custom commands FIRST ──
        val store = CustomCommandStore(this)
        val customMatch = store.findByTrigger(command)
        if (customMatch != null) {
            Log.i(TAG, "★ Custom command matched: ${customMatch.triggerPhrase}")
            return "Custom command: ${customMatch.displayName}. (Active in hands-free mode)"
        }

        return when {
            // Call / Dial command: "call mom", "call 9876543210", "dial john", "phone dad"
            command.startsWith("call ") || command.startsWith("dial ") || command.startsWith("phone ") -> {
                val prefix = when {
                    command.startsWith("call ") -> "call "
                    command.startsWith("dial ") -> "dial "
                    else -> "phone "
                }
                val name = command.removePrefix(prefix).trim()
                val result = CallHelper.call(this, name)
                result.spokenResponse
            }

            // Open app: "open whatsapp", "open youtube"
            command.startsWith("open ") -> {
                val appName = command.removePrefix("open ").trim()
                openApp(appName)
                "Opening: $appName"
            }

            // Set alarm: "set alarm 7 30"
            command.startsWith("set alarm") -> {
                setAlarm(command)
            }

            // Set timer: "set timer 30 seconds"
            command.startsWith("set timer") -> {
                setTimer(command)
            }

            // ── Volume controls ──
            // "set volume to 50%", "volume 50", "volume to 80 percent"
            command.startsWith("set volume") || command.startsWith("volume ") -> {
                val percent = VolumeController.parseVolumePercent(command)
                if (percent != null) {
                    VolumeController.setVolumePercent(this, percent).spokenResponse
                } else {
                    "What volume level? For example, say \"set volume to 50 percent\""
                }
            }
            command == "volume up" || command == "increase volume" || command == "louder" -> {
                val steps = if (command == "louder") 2 else 1
                VolumeController.increaseVolume(this, steps).spokenResponse
            }
            command == "volume down" || command == "decrease volume" || command == "softer" -> {
                val steps = if (command == "softer") 2 else 1
                VolumeController.decreaseVolume(this, steps).spokenResponse
            }
            command == "mute" || command == "mute volume" -> {
                VolumeController.mute(this).spokenResponse
            }
            command == "unmute" || command == "unmute volume" -> {
                VolumeController.unmute(this).spokenResponse
            }
            command == "max volume" || command == "full volume" -> {
                VolumeController.setMaxVolume(this).spokenResponse
            }
            command.contains("what") && command.contains("volume") || command == "current volume" -> {
                VolumeController.getVolumeDescription(this).spokenResponse
            }

            // Search: "search best restaurants in delhi"
            command.startsWith("search ") -> {
                val query = command.removePrefix("search ").trim()
                searchWeb(query)
                "Searching: $query"
            }

            // Google search: "google <query>"
            command.startsWith("google ") -> {
                val query = command.removePrefix("google ").trim()
                searchWeb(query)
                "Googling: $query"
            }

            // Open website: "open youtube.com"
            command.contains(".com") || command.contains(".in") || command.contains(".org") -> {
                openWebsite(command)
            }

            // What time is it
            command.contains("time") && command.contains("what") -> {
                val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                "Current time: $time"
            }

            // What date is it
            command.contains("date") && command.contains("what") -> {
                val date = SimpleDateFormat("dd MMMM yyyy, EEEE", Locale.getDefault()).format(Date())
                "Today: $date"
            }

            // Set reminder / note (can be extended with database)
            command.startsWith("remind me ") -> {
                val reminder = command.removePrefix("remind me ").trim()
                "Reminder saved: $reminder"
            }

            // Help
            command == "help" || command == "what can you do" -> {
                "Try: 'call John', 'open WhatsApp', 'search weather', 'set alarm 7:30', 'set volume to 50%', 'mute', 'volume up', 'what time is it'"
            }

            // No matching command — just display the text
            else -> {
                "Heard: \"$text\" — no matching command"
            }
        }
    }

    /**
     * Open the dialer with a contact name (or raw number).
     * Delegates to CallHelper for contact lookup + Intent dispatch.
     */
    private fun initiateCall(name: String) {
        val result = CallHelper.call(this, name)
        Toast.makeText(this, result.spokenResponse, Toast.LENGTH_SHORT).show()
    }

    /**
     * Launch an app by name using PackageManager.
     */
    private fun openApp(appName: String) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(getPackageName(appName))
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } else {
                // App not found — open Play Store search for it
                val playStoreIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("market://search?q=$appName")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(playStoreIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open app: $appName", e)
            Toast.makeText(this, "Could not open $appName", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Map common app names to their package IDs.
     */
    private fun getPackageName(appName: String): String {
        return when (appName.lowercase().trim()) {
            "whatsapp" -> "com.whatsapp"
            "youtube" -> "com.google.android.youtube"
            "instagram" -> "com.instagram.android"
            "facebook" -> "com.facebook.katana"
            "maps", "google maps" -> "com.google.android.apps.maps"
            "gmail" -> "com.google.android.gm"
            "chrome" -> "com.android.chrome"
            "camera" -> "com.android.camera"
            "calculator" -> "com.android.calculator2"
            "calendar" -> "com.google.android.calendar"
            "spotify" -> "com.spotify.music"
            "telegram" -> "org.telegram.messenger"
            "twitter", "x" -> "com.twitter.android"
            "settings" -> "com.android.settings"
            "phone", "dialer" -> "com.google.android.dialer"
            "messages", "sms" -> "com.google.android.apps.messaging"
            else -> appName.replace(" ", "")
        }
    }

    /**
     * Set an alarm using AlarmClock intent.
     * Supports phrases like "set alarm 7 30", "set alarm 7:30 am"
     */
    private fun setAlarm(command: String): String {
        // Extract time from command — look for patterns like "7:30", "7 30", "0730"
        val timeRegex = Regex("(\\d{1,2})[:\\s](\\d{2})")
        val match = timeRegex.find(command)

        return if (match != null) {
            val hour = match.groupValues[1].toInt()
            val minute = match.groupValues[2].toInt()

            // Determine AM/PM
            val isPM = command.contains("pm") || (hour <= 12 && command.contains("afternoon"))
            val isAM = command.contains("am")
            val adjustedHour = when {
                isPM && hour < 12 -> hour + 12
                isAM && hour == 12 -> 0
                else -> hour
            }

            try {
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, adjustedHour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Voice Assistant Alarm")
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                "Alarm set for %02d:%02d".format(adjustedHour, minute)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to set alarm", e)
                "Could not set alarm. Please set manually."
            }
        } else {
            "Could not understand the alarm time. Try: 'set alarm 7:30'"
        }
    }

    /**
     * Set a timer using AlarmClock intent.
     * Supports "set timer 30 seconds", "set timer 5 minutes"
     */
    private fun setTimer(command: String): String {
        val secondsRegex = Regex("(\\d+)\\s*seconds?")
        val minutesRegex = Regex("(\\d+)\\s*minutes?")

        val totalSeconds = when {
            secondsRegex.containsMatchIn(command) ->
                secondsRegex.find(command)!!.groupValues[1].toInt()
            minutesRegex.containsMatchIn(command) ->
                minutesRegex.find(command)!!.groupValues[1].toInt() * 60
            else -> 0
        }

        return if (totalSeconds > 0) {
            try {
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, totalSeconds)
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Voice Assistant Timer")
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                "Timer set for $totalSeconds seconds"
            } catch (e: Exception) {
                Log.e(TAG, "Failed to set timer", e)
                "Could not set timer."
            }
        } else {
            "Could not understand timer duration. Try: 'set timer 30 seconds'"
        }
    }

    /**
     * Open Google search with the given query.
     */
    private fun searchWeb(query: String) {
        try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback: open in browser directly
            val browserIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://www.google.com/search?q=$query")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(browserIntent)
        }
    }

    /**
     * Open a website URL in the default browser.
     */
    private fun openWebsite(url: String): String {
        var cleanUrl = url.trim()
        if (!cleanUrl.startsWith("http")) {
            cleanUrl = "https://$cleanUrl"
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(cleanUrl)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            return "Opening: $cleanUrl"
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open website", e)
            return "Could not open: $cleanUrl"
        }
    }

    /**
     * Guide user to the app settings page to manually grant permissions.
     */
    private fun showAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    /**
     * Clean up the SpeechRecognizer when activity is destroyed.
     */
    override fun onDestroy() {
        super.onDestroy()
        speechHelper.destroy()
        Log.i(TAG, "Activity destroyed, speech helper cleaned up")
    }
}
