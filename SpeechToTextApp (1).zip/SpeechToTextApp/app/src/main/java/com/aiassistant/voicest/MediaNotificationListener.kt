package com.aiassistant.voicest

import android.service.notification.NotificationListenerService
import android.util.Log

/**
 * MediaNotificationListener — NotificationListenerService that grants
 * the app access to media sessions via MediaSessionManager.
 *
 * WHY THIS EXISTS:
 * Android requires either:
 *   1. android.permission.MEDIA_CONTENT_CONTROL (system apps only), OR
 *   2. A NotificationListenerService component enabled by the user
 *
 * for an app to access other apps' media sessions via MediaSessionManager.
 *
 * This empty NotificationListenerService serves as that component.
 * The user needs to enable "Notification Access" for the app in:
 *   Settings → Apps → Special Access → Notification Access → Voice Assistant → Enable
 *
 * Once enabled, MediaSessionHelper can detect when Spotify, YouTube Music,
 * or any other media app is playing, and the ContextualCardView will show
 * the media controls automatically.
 *
 * The service itself doesn't process notifications — it just needs to exist
 * and be enabled by the user to unlock media session access.
 */
class MediaNotificationListener : NotificationListenerService() {

    private val TAG = "MediaNotificationListener"

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.i(TAG, "★ Notification listener connected — media session access is now available")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.w(TAG, "Notification listener disconnected — media session access lost")
    }
}
