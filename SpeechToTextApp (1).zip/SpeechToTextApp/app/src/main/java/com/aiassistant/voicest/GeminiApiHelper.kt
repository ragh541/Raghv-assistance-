package com.aiassistant.voicest

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

/**
 * GeminiApiHelper — Handles communication with Google's Gemini AI API.
 *
 * This allows the voice assistant to give INTELLIGENT, conversational responses
 * instead of hardcoded ones. When the user asks something that doesn't match
 * any specific command (open, call, search, etc.), the text is sent to Gemini
 * which generates a natural language response.
 *
 * SETUP:
 * 1. Get a free API key from https://aistudio.google.com/apikey
 * 2. Replace YOUR_API_KEY below with your key
 * 3. The assistant will then answer questions like "what's the weather",
 *    "tell me a joke", "explain quantum computing", etc.
 *
 * SECURITY NOTE:
 * In production, the API key should be stored in BuildConfig or a local.properties
 * file, NOT hardcoded. For this demo it's a placeholder — replace it with your own.
 */
object GeminiApiHelper {

    private val TAG = "GeminiApiHelper"

    // ===================================================================
    // API KEY — REPLACE THIS WITH YOUR OWN KEY
    // Get one free at: https://aistudio.google.com/apikey
    // ===================================================================
    private const val API_KEY = "YOUR_API_KEY_HERE"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"
    private const val MODEL = "gemini-1.5-flash-latest"

    // System instruction — tells Gemini how to behave
    private const val SYSTEM_PROMPT = "You are Raghv's personal voice assistant, " +
            "similar to Jarvis from Iron Man. Keep responses SHORT and conversational " +
            "(1-3 sentences max) since they will be spoken aloud via text-to-speech. " +
            "Be helpful, concise, and friendly. If asked to open apps or make calls, " +
            "just say you's handling it."

    private val isApiKeyValid: Boolean
        get() = API_KEY != "YOUR_API_KEY_HERE" && API_KEY.isNotBlank()

    // ---- Retrofit interface ----
    private interface GeminiApi {
        @POST("v1beta/models/$MODEL:generateContent")
        suspend fun generateContent(
            @Query("key") apiKey: String,
            @Body request: GeminiRequest
        ): GeminiResponse
    }

    // ---- Request/Response data classes ----
    data class GeminiRequest(
        val contents: List<Content>,
        val systemInstruction: Content? = null
    )

    data class Content(
        val parts: List<Part>,
        val role: String = "user"
    )

    data class Part(val text: String)

    data class GeminiResponse(
        val candidates: List<Candidate>?
    )

    data class Candidate(
        val content: ResponseContent?
    )

    data class ResponseContent(
        val parts: List<Part>?,
        val role: String?
    )

    // ---- Retrofit instance ----
    private val api: GeminiApi by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
    }

    /**
     * Send a prompt to Gemini and get a text response.
     * Returns null if API key is not set or an error occurs.
     *
     * Call this from a coroutine:
     *   val response = GeminiApiHelper.ask("What's the weather?")
     *   if (response != null) { speak(response) }
     */
    suspend fun ask(userPrompt: String): String? {
        if (!isApiKeyValid) {
            Log.w(TAG, "API key not set — using fallback. Get a key at https://aistudio.google.com/apikey")
            return null
        }

        return withContext(Dispatchers.IO) {
            try {
                val request = GeminiRequest(
                    contents = listOf(
                        Content(parts = listOf(Part(userPrompt)))
                    ),
                    systemInstruction = Content(
                        parts = listOf(Part(SYSTEM_PROMPT)),
                        role = "model"
                    )
                )

                Log.i(TAG, "Sending to Gemini: \"$userPrompt\"")
                val response = api.generateContent(API_KEY, request)
                val text = response.candidates?.firstOrNull()
                    ?.content?.parts?.firstOrNull()?.text

                if (text != null) {
                    Log.i(TAG, "Gemini response: \"$text\"")
                    text.trim()
                } else {
                    Log.w(TAG, "Gemini returned empty response")
                    null
                }
            } catch (e: Exception) {
                Log.e(TAG, "Gemini API error: ${e.message}", e)
                null
            }
        }
    }

    /**
     * Check if the API key has been configured.
     */
    fun isConfigured(): Boolean = isApiKeyValid
}
