package com.aiassistant.voicest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.card.MaterialCardView

/**
 * ContextualCardView — A dynamic UI element that shows contextual information
 * based on what's happening on the device.
 *
 * PRIMARY USE CASE: Media Player Controls
 * When music or audio is playing (Spotify, YouTube Music, etc.), this card
 * automatically appears with:
 *   - Album art / media thumbnail
 *   - Track title and artist name
 *   - Play/Pause, Previous, Next buttons
 *   - A subtle progress indicator
 *
 * When no media is active, the card animates away (visibility = GONE).
 *
 * DESIGN:
 * - Dark, translucent card with rounded corners
 * - Album art on the left (48dp square, rounded)
 * - Track info in the middle (title bold, artist subtitle)
 * - Transport controls on the right (prev / play-pause / next)
 * - Subtle accent glow when music is playing
 * - Typewriter-style fade-in for title changes
 *
 * The card is designed to be embedded in both:
 *   - activity_main.xml (below the waveform)
 *   - activity_lockscreen.xml (above the command display)
 *
 * USAGE:
 *   val card = findViewById<ContextualCardView>(R.id.contextualCard)
 *   card.updateMediaInfo("Bohemian Rhapsody", "Queen", albumArtBitmap, isPlaying = true)
 *   card.setMediaControlListener(object : ContextualCardView.MediaControlListener {
 *       override fun onPlayPause() { /* toggle playback */ }
 *       override fun onNext() { /* skip to next */ }
 *       override fun onPrevious() { /* previous track */ }
 *   })
 *   card.hide()  // when no media is active
 */
class ContextualCardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : MaterialCardView(context, attrs, defStyleAttr) {

    private val TAG = "ContextualCardView"

    // ---- UI Elements ----
    private lateinit var ivAlbumArt: ImageView
    private lateinit var tvTrackTitle: TextView
    private lateinit var tvArtistName: TextView
    private lateinit var btnPrev: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var layoutContent: LinearLayout

    // ---- State ----
    private var isPlaying = false
    private var isVisible = false
    private var mediaControlListener: MediaControlListener? = null

    /**
     * Listener for media transport control button presses.
     */
    interface MediaControlListener {
        fun onPlayPause()
        fun onNext()
        fun onPrevious()
    }

    init {
        initView()
    }

    private fun initView() {
        // Build the card content programmatically — keeps it self-contained
        // and avoids the need for a separate layout XML file
        radius = 16f
        cardElevation = 4f
        setCardBackgroundColor(Color.parseColor("#1A1A2E"))
        strokeColor = Color.parseColor("#3300D4FF")
        strokeWidth = 1
        visibility = View.GONE
        setPadding(12, 12, 12, 12)

        // Root horizontal layout
        layoutContent = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT
            )
        }

        // ---- Album Art ----
        ivAlbumArt = ImageView(context).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                dpToPx(48), dpToPx(48)
            ).apply {
                marginEnd = dpToPx(12)
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.parseColor("#2A2A3E"))
            // Rounded corners via clip
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dpToPx(8).toFloat())
                }
            }
            setImageResource(android.R.drawable.ic_media_play) // placeholder
        }
        layoutContent.addView(ivAlbumArt)

        // ---- Track Info (title + artist) ----
        val infoLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            )
        }

        tvTrackTitle = TextView(context).apply {
            text = "No media playing"
            setTextColor(Color.parseColor("#E0E0E0"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        tvArtistName = TextView(context).apply {
            text = ""
            setTextColor(Color.parseColor("#8888AA"))
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        infoLayout.addView(tvTrackTitle)
        infoLayout.addView(tvArtistName)
        layoutContent.addView(infoLayout)

        // ---- Transport Controls ----
        btnPrev = ImageButton(context).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                dpToPx(36), dpToPx(36)
            ).apply { marginStart = dpToPx(8) }
            setImageResource(android.R.drawable.ic_media_previous)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.parseColor("#8888AA"))
            background = null
            contentDescription = "Previous track"
        }

        btnPlayPause = ImageButton(context).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                dpToPx(40), dpToPx(40)
            ).apply { marginStart = dpToPx(4) }
            setImageResource(android.R.drawable.ic_media_play)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.parseColor("#00D4FF"))
            background = null
            contentDescription = "Play/Pause"
        }

        btnNext = ImageButton(context).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                dpToPx(36), dpToPx(36)
            ).apply { marginStart = dpToPx(4) }
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.parseColor("#8888AA"))
            background = null
            contentDescription = "Next track"
        }

        layoutContent.addView(btnPrev)
        layoutContent.addView(btnPlayPause)
        layoutContent.addView(btnNext)

        addView(layoutContent)

        // ---- Click listeners ----
        btnPlayPause.setOnClickListener {
            Log.d(TAG, "Play/Pause button pressed")
            mediaControlListener?.onPlayPause()
            // Optimistic UI update — toggle the icon immediately
            updatePlayPauseIcon(!isPlaying)
        }

        btnNext.setOnClickListener {
            Log.d(TAG, "Next button pressed")
            mediaControlListener?.onNext()
        }

        btnPrev.setOnClickListener {
            Log.d(TAG, "Previous button pressed")
            mediaControlListener?.onPrevious()
        }
    }

    /**
     * Update the card with media info.
     *
     * @param title Track title (e.g. "Bohemian Rhapsody")
     * @param artist Artist name (e.g. "Queen")
     * @param albumArt Album art bitmap, or null for placeholder
     * @param isPlaying Whether media is currently playing
     */
    fun updateMediaInfo(title: String, artist: String, albumArt: Bitmap?, playing: Boolean) {
        Log.d(TAG, "updateMediaInfo: \"$title\" by \"$artist\" (playing=$playing)")

        // Animate title change with a fade
        tvTrackTitle.alpha = 0.5f
        tvTrackTitle.text = title
        tvTrackTitle.animate().alpha(1f).setDuration(200).start()

        tvArtistName.text = artist
        isPlaying = playing
        updatePlayPauseIcon(playing)

        if (albumArt != null) {
            ivAlbumArt.setImageBitmap(albumArt)
        } else {
            ivAlbumArt.setImageResource(android.R.drawable.ic_media_play)
            ivAlbumArt.setBackgroundColor(Color.parseColor("#2A2A3E"))
        }

        show()
    }

    /**
     * Update just the play/pause state without changing track info.
     */
    fun updatePlaybackState(playing: Boolean) {
        isPlaying = playing
        updatePlayPauseIcon(playing)
    }

    /**
     * Update the play/pause icon based on playback state.
     */
    private fun updatePlayPauseIcon(playing: Boolean) {
        isPlaying = playing
        if (playing) {
            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
            // Subtle glow effect when playing
            strokeColor = Color.parseColor("#6600D4FF")
            strokeWidth = 2
        } else {
            btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
            strokeColor = Color.parseColor("#3300D4FF")
            strokeWidth = 1
        }
    }

    /**
     * Show the card with a slide-up + fade-in animation.
     */
    fun show() {
        if (isVisible) return
        visibility = View.VISIBLE
        alpha = 0f
        translationY = dpToPx(16).toFloat()
        animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(250)
            .start()
        isVisible = true
    }

    /**
     * Hide the card with a fade-out + slide-down animation.
     */
    fun hide() {
        if (!isVisible) return
        animate()
            .alpha(0f)
            .translationY(dpToPx(16).toFloat())
            .setDuration(200)
            .withEndAction { visibility = View.GONE }
            .start()
        isVisible = false
    }

    /**
     * Set the media control listener for transport button callbacks.
     */
    fun setMediaControlListener(listener: MediaControlListener) {
        this.mediaControlListener = listener
    }

    /**
     * Check if the card is currently visible.
     */
    fun isCardVisible(): Boolean = isVisible

    /**
     * Helper: convert dp to pixels.
     */
    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }
}
