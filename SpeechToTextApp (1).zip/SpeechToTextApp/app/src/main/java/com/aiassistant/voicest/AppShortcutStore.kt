package com.aiassistant.voicest

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * AppShortcutStore — SharedPreferences-backed storage for index-based
 * voice shortcuts (keyword → installed app mapping).
 *
 * Provides CRUD operations and fast lookup by keyword.
 *
 * Usage:
 *   val store = AppShortcutStore(context)
 *   store.add(AppShortcut(...))
 *   val match = store.findByKeyword("insta")  // → AppShortcut or null
 *   store.delete(id)
 */
class AppShortcutStore(context: Context) {

    private val TAG = "AppShortcutStore"
    private val PREFS_NAME = "app_shortcuts_prefs"
    private val KEY_SHORTCUTS = "app_shortcuts_json"

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    /**
     * Get all saved shortcuts.
     */
    fun getAll(): MutableList<AppShortcut> {
        val json = prefs.getString(KEY_SHORTCUTS, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<AppShortcut>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse shortcuts JSON", e)
            mutableListOf()
        }
    }

    private fun saveAll(shortcuts: List<AppShortcut>) {
        val json = gson.toJson(shortcuts)
        prefs.edit().putString(KEY_SHORTCUTS, json).apply()
        Log.d(TAG, "Saved ${shortcuts.size} shortcuts")
    }

    /**
     * Add a new shortcut. If the keyword already exists, it's updated.
     */
    fun add(shortcut: AppShortcut) {
        val shortcuts = getAll()
        // Remove any existing shortcut with the same keyword (case-insensitive)
        shortcuts.removeAll {
            it.keyword.lowercase().trim() == shortcut.keyword.lowercase().trim()
        }
        shortcuts.add(shortcut)
        saveAll(shortcuts)
        Log.i(TAG, "Added shortcut: \"${shortcut.keyword}\" → ${shortcut.packageName}")
    }

    /**
     * Update an existing shortcut by ID.
     */
    fun update(shortcut: AppShortcut) {
        val shortcuts = getAll()
        val index = shortcuts.indexOfFirst { it.id == shortcut.id }
        if (index >= 0) {
            shortcuts[index] = shortcut
            saveAll(shortcuts)
            Log.i(TAG, "Updated shortcut: ${shortcut.keyword}")
        }
    }

    /**
     * Delete a shortcut by ID.
     */
    fun delete(id: Long) {
        val shortcuts = getAll()
        shortcuts.removeAll { it.id == id }
        saveAll(shortcuts)
        Log.i(TAG, "Deleted shortcut with id=$id")
    }

    /**
     * Find a shortcut by keyword (case-insensitive, exact match).
     * Only returns enabled shortcuts.
     *
     * @return The matching AppShortcut, or null if no match.
     */
    fun findByKeyword(spokenText: String): AppShortcut? {
        val lower = spokenText.lowercase().trim()
        val shortcuts = getAll()

        // Exact match
        return shortcuts.firstOrNull {
            it.enabled && it.keyword.lowercase().trim() == lower
        }
    }

    /**
     * Check if a keyword is already in use.
     */
    fun keywordExists(keyword: String): Boolean {
        val lower = keyword.lowercase().trim()
        return getAll().any { it.keyword.lowercase().trim() == lower }
    }

    /**
     * Toggle the enabled state of a shortcut.
     */
    fun toggleEnabled(id: Long) {
        val shortcuts = getAll()
        val sc = shortcuts.find { it.id == id }
        if (sc != null) {
            sc.enabled = !sc.enabled
            saveAll(shortcuts)
            Log.i(TAG, "Toggled shortcut ${sc.keyword}: enabled=${sc.enabled}")
        }
    }

    /**
     * Get all shortcuts as keyword phrases for offline grammar.
     */
    fun getAllKeywords(): List<String> = getAll().filter { it.enabled }.map { it.keyword }

    /**
     * Get count of saved shortcuts.
     */
    fun count(): Int = getAll().size

    /**
     * Seed default shortcuts on first launch (if store is empty).
     * Only seeds shortcuts for very common apps — the actual apps
     * may or may not be installed; non-installed ones do nothing.
     */
    fun seedDefaultsIfEmpty() {
        if (getAll().isNotEmpty()) return

        Log.i(TAG, "Seeding default app shortcuts...")
        add(AppShortcut(generateId(), "insta", "com.instagram.android", "Instagram"))
        add(AppShortcut(generateId(), "pay", "com.phonepe.app", "PhonePe"))
        add(AppShortcut(generateId(), "mail", "com.google.android.gm", "Gmail"))
        Log.i(TAG, "Seeded 3 default shortcuts")
    }

    companion object {
        fun generateId(): Long = System.currentTimeMillis()
    }
}
