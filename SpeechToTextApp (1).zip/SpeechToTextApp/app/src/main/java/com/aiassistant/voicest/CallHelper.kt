package com.aiassistant.voicest

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * CallHelper — Voice-triggered contact access for initiating phone calls.
 *
 * Allows the user to say "Call [Name]" and have the assistant look up the
 * contact and place a phone call. Supports:
 *
 *   1. Contact name lookup via ContactsContract (fuzzy, multi-pass)
 *   2. Indian nicknames (mummy, papa, bhaiya, didi, etc.)
 *   3. Raw phone numbers spoken directly ("call 9876543210")
 *   4. Multiple matching contacts — picks best, announces which
 *   5. Redial / call-back (tracks last called number)
 *   6. Indian phone number normalization (adds +91 if needed)
 *   7. ACTION_CALL (direct) with ACTION_DIAL fallback
 *
 * Supported voice commands (handled by caller):
 *   "call mom"          → CallHelper.call(context, "mom")
 *   "call mummy"         → resolves via nickname map → "Mom"
 *   "call 9876543210"   → direct number
 *   "dial john"          → opens dialer
 *   "phone dad"          → same as call
 *   "redial" / "call back" → CallHelper.redial(context)
 */
object CallHelper {

    private const val TAG = "CallHelper"

    // SharedPreferences key for last called number
    private const val PREFS_NAME = "call_helper_prefs"
    private const val KEY_LAST_NUMBER = "last_called_number"
    private const val KEY_LAST_NAME = "last_called_name"

    /**
     * Indian nickname → standard English mapping.
     * When user says "call mummy", we look up "mummy" in contacts,
     * and also try "mom", "mother", etc.
     */
    private val nicknameMap = mapOf(
        // Mother
        "mummy" to listOf("mom", "mother", "mummy", "maa", "amma"),
        "mom" to listOf("mom", "mother", "mummy", "maa", "amma"),
        "mother" to listOf("mother", "mom", "mummy", "maa", "amma"),
        "maa" to listOf("maa", "mom", "mother", "mummy", "amma"),
        "amma" to listOf("amma", "mom", "mother", "mummy", "maa"),
        // Father
        "papa" to listOf("papa", "dad", "father", "daddy", "abba"),
        "dad" to listOf("dad", "father", "papa", "daddy", "abba"),
        "father" to listOf("father", "dad", "papa", "daddy", "abba"),
        "daddy" to listOf("daddy", "dad", "father", "papa", "abba"),
        "abba" to listOf("abba", "dad", "father", "papa", "daddy"),
        // Siblings
        "bhaiya" to listOf("bhaiya", "brother", "bhai", "bhaiya"),
        "bhai" to listOf("bhai", "brother", "bhaiya"),
        "brother" to listOf("brother", "bhai", "bhaiya"),
        "didi" to listOf("didi", "sister", "di", "didi"),
        "sister" to listOf("sister", "didi", "di"),
        "di" to listOf("di", "didi", "sister"),
        // Grandparents
        "dadi" to listOf("dadi", "grandmother", "dadi ma", "dadi"),
        "dada" to listOf("dada", "grandfather", "dada ji", "dada"),
        "nani" to listOf("nani", "grandmother", "nani ma", "nani"),
        "nana" to listOf("nana", "grandfather", "nana ji", "nana"),
        // Spouse
        "wife" to listOf("wife", "jaan", "shona"),
        "husband" to listOf("husband", "jaan"),
        // Home / Office
        "home" to listOf("home", "ghar", "house"),
        "ghar" to listOf("ghar", "home", "house"),
        "office" to listOf("office", "work", "kaam"),
        "work" to listOf("work", "office", "kaam"),
        // Friends (common slang)
        "yaar" to listOf("yaar", "friend", "dost"),
        "dost" to listOf("dost", "friend", "yaar"),
        "friend" to listOf("friend", "dost", "yaar"),
    )

    /**
     * Result of a call/dial attempt.
     */
    data class CallResult(
        val success: Boolean,
        val spokenResponse: String,
        val matchedName: String = "",
        val phoneNumber: String = ""
    )

    /**
     * A single contact match found in the phonebook.
     */
    data class ContactMatch(
        val name: String,
        val phoneNumber: String,
        val phoneType: String = "",
        val matchScore: Int = 0  // Higher = better match
    )

    // ──────────────────────────────────────────────────────────
    //  PUBLIC API
    // ──────────────────────────────────────────────────────────

    /**
     * Initiate a direct phone call (ACTION_CALL).
     * Falls back to ACTION_DIAL if CALL_PHONE permission is not granted.
     *
     * @param context Activity or Service context
     * @param query Contact name, nickname, or raw phone number
     * @return CallResult with status and spoken response
     */
    fun call(context: Context, query: String): CallResult {
        val trimmedQuery = query.trim()

        if (trimmedQuery.isEmpty()) {
            return CallResult(
                success = false,
                spokenResponse = "Who would you like me to call? You can say a name like 'call mom' or a number like 'call 9876543210'."
            )
        }

        val hasCallPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        // Resolve the phone number (from contacts, nicknames, or raw input)
        val resolved = resolvePhoneNumber(context, trimmedQuery)

        if (resolved.phoneNumber.isEmpty()) {
            // Try to find multiple matches and suggest
            val matches = searchContacts(context, trimmedQuery)
            return if (matches.size > 1) {
                val names = matches.take(3).joinToString(", ") { it.name }
                CallResult(
                    success = false,
                    spokenResponse = "I found multiple contacts: $names. Which one would you like to call?"
                )
            } else {
                CallResult(
                    success = false,
                    spokenResponse = "I couldn't find a contact named \"$trimmedQuery\". " +
                        "You can try saying the phone number directly, like \"call 9876543210\"."
                )
            }
        }

        val displayName = resolved.displayName.ifEmpty { resolved.phoneNumber }
        val normalizedNumber = normalizePhoneNumber(resolved.phoneNumber)

        return if (hasCallPermission) {
            try {
                val intent = Intent(Intent.ACTION_CALL).apply {
                    data = Uri.parse("tel:$normalizedNumber")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                saveLastCalled(context, normalizedNumber, displayName)
                Log.i(TAG, "★ ACTION_CALL → $displayName ($normalizedNumber)")
                CallResult(
                    success = true,
                    spokenResponse = "Calling $displayName",
                    matchedName = displayName,
                    phoneNumber = normalizedNumber
                )
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException on ACTION_CALL, falling back to DIAL", e)
                dial(context, trimmedQuery)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initiate call", e)
                CallResult(
                    success = false,
                    spokenResponse = "I couldn't place the call to $displayName"
                )
            }
        } else {
            Log.w(TAG, "CALL_PHONE permission not granted, using ACTION_DIAL instead")
            dial(context, trimmedQuery)
        }
    }

    /**
     * Open the dialer with a contact's number (ACTION_DIAL).
     * Does not require CALL_PHONE permission.
     */
    fun dial(context: Context, query: String): CallResult {
        val trimmedQuery = query.trim()

        if (trimmedQuery.isEmpty()) {
            return CallResult(
                success = false,
                spokenResponse = "Who would you like me to call?"
            )
        }

        val resolved = resolvePhoneNumber(context, trimmedQuery)

        if (resolved.phoneNumber.isEmpty()) {
            return CallResult(
                success = false,
                spokenResponse = "I couldn't find a contact named \"$trimmedQuery\" in your phonebook."
            )
        }

        val displayName = resolved.displayName.ifEmpty { resolved.phoneNumber }
        val normalizedNumber = normalizePhoneNumber(resolved.phoneNumber)

        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$normalizedNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            saveLastCalled(context, normalizedNumber, displayName)
            Log.i(TAG, "★ ACTION_DIAL → $displayName ($normalizedNumber)")
            CallResult(
                success = true,
                spokenResponse = "Opening dialer for $displayName",
                matchedName = displayName,
                phoneNumber = normalizedNumber
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open dialer", e)
            CallResult(
                success = false,
                spokenResponse = "I couldn't open the dialer for $displayName"
            )
        }
    }

    /**
     * Redial the last called number.
     * Returns a CallResult indicating whether a previous call was found.
     */
    fun redial(context: Context): CallResult {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastNumber = prefs.getString(KEY_LAST_NUMBER, null)
        val lastName = prefs.getString(KEY_LAST_NAME, null)

        if (lastNumber.isNullOrEmpty()) {
            return CallResult(
                success = false,
                spokenResponse = "I don't have a recent call to redial."
            )
        }

        val hasCallPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val displayName = lastName ?: lastNumber

        return try {
            val intent = if (hasCallPermission) {
                Intent(Intent.ACTION_CALL).apply {
                    data = Uri.parse("tel:$lastNumber")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:$lastNumber")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(intent)
            Log.i(TAG, "★ REDIAL → $displayName ($lastNumber)")
            CallResult(
                success = true,
                spokenResponse = "Redialing $displayName",
                matchedName = displayName,
                phoneNumber = lastNumber
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to redial", e)
            CallResult(
                success = false,
                spokenResponse = "I couldn't redial $displayName"
            )
        }
    }

    /**
     * Search contacts and return ALL matches (for display or disambiguation).
     * Useful when multiple contacts match and the user needs to choose.
     */
    fun searchContacts(context: Context, query: String): List<ContactMatch> {
        val results = mutableListOf<ContactMatch>()
        val lowerQuery = query.lowercase().trim()

        // Expand nicknames
        val searchTerms = expandNickname(lowerQuery)

        val hasContactsPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasContactsPermission) return results

        try {
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.LABEL
            )

            // Query all contacts and score them
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val seenNames = mutableSetOf<String>()

                while (cursor.moveToNext()) {
                    val number = cursor.getString(0) ?: continue
                    val name = cursor.getString(1) ?: continue
                    if (number.isEmpty()) continue

                    val lowerName = name.lowercase()
                    var score = 0

                    // Score against each search term
                    for (term in searchTerms) {
                        when {
                            lowerName == term -> score = maxOf(score, 100)
                            lowerName.startsWith(term) -> score = maxOf(score, 80)
                            lowerName.contains(" $term ") -> score = maxOf(score, 75)
                            lowerName.contains(" $term") -> score = maxOf(score, 70)
                            lowerName.contains("$term ") -> score = maxOf(score, 70)
                            lowerName.contains(term) -> score = maxOf(score, 50)
                        }

                        // Check if all words in the term appear in the name
                        val termWords = term.split(Regex("\\s+"))
                        if (termWords.size > 1 && termWords.all { lowerName.contains(it) }) {
                            score = maxOf(score, 60)
                        }
                    }

                    if (score > 0) {
                        val key = "$name:$number"
                        if (key !in seenNames) {
                            seenNames.add(key)
                            val typeLabel = cursor.getString(3) ?: ""
                            results.add(ContactMatch(name, number, typeLabel, score))
                        }
                    }
                }
            }

            // Sort by score descending, then by name
            results.sortByDescending { it.matchScore }

        } catch (e: Exception) {
            Log.e(TAG, "Error searching contacts for \"$query\"", e)
        }

        return results
    }

    // ──────────────────────────────────────────────────────────
    //  INTERNAL METHODS
    // ──────────────────────────────────────────────────────────

    /**
     * Expand a nickname into all its variants.
     * e.g. "mummy" → ["mummy", "mom", "mother", "maa", "amma"]
     */
    private fun expandNickname(query: String): List<String> {
        val terms = mutableListOf(query)

        // Check if the query (or any word in it) matches a nickname
        val queryWords = query.split(Regex("\\s+"))
        for (word in queryWords) {
            val nickVariants = nicknameMap[word]
            if (nickVariants != null) {
                terms.addAll(nickVariants)
            }
        }

        // Also add the full query as a single term
        if (query.contains(" ")) {
            terms.add(0, query)
        }

        return terms.distinct()
    }

    /**
     * Resolve a spoken query to a phone number.
     *
     * Logic:
     *   1. If the query is a raw phone number → return directly
     *   2. If READ_CONTACTS permission → search contacts with nickname expansion
     *   3. If no permission → return query as-is (dialer will handle)
     */
    private fun resolvePhoneNumber(context: Context, query: String): ResolvedContact {
        // ── 1. Check if query is a raw phone number ──
        val phonePattern = Regex("^[+]?[\\d\\s\\-()]{7,15}$")
        if (query.matches(phonePattern)) {
            val cleaned = query.replace(Regex("[\\s\\-()]"), "")
            Log.d(TAG, "Query is a raw phone number: $cleaned")
            return ResolvedContact(phoneNumber = cleaned, displayName = cleaned)
        }

        // ── 2. Check READ_CONTACTS permission ──
        val hasContactsPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasContactsPermission) {
            Log.w(TAG, "READ_CONTACTS not granted — cannot look up \"$query\"")
            return ResolvedContact(phoneNumber = query, displayName = query)
        }

        // ── 3. Search contacts with nickname expansion ──
        return queryContactsWithNicknames(context, query)
    }

    /**
     * Query contacts using the full nickname-expanded search.
     * Tries exact matches first, then fuzzy matches, across all nickname variants.
     */
    private fun queryContactsWithNicknames(context: Context, query: String): ResolvedContact {
        val lowerQuery = query.lowercase().trim()
        val searchTerms = expandNickname(lowerQuery)

        Log.d(TAG, "Searching contacts for: $searchTerms")

        try {
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            )

            // ── Pass A: Exact match on DISPLAY_NAME (case-insensitive) for each term ──
            for (term in searchTerms) {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} = ? COLLATE NOCASE",
                    arrayOf(term),
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val number = cursor.getString(0) ?: ""
                        val name = cursor.getString(1) ?: query
                        if (number.isNotEmpty()) {
                            Log.i(TAG, "★ Exact match: \"$name\" → $number (term: $term)")
                            return ResolvedContact(phoneNumber = number, displayName = name)
                        }
                    }
                }
            }

            // ── Pass B: Partial DISPLAY_NAME match (LIKE %term%) for each term ──
            for (term in searchTerms) {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                    arrayOf("%$term%"),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val number = cursor.getString(0) ?: ""
                        val name = cursor.getString(1) ?: query
                        if (number.isNotEmpty()) {
                            Log.i(TAG, "★ Partial match: \"$name\" → $number (term: $term)")
                            return ResolvedContact(phoneNumber = number, displayName = name)
                        }
                    }
                }
            }

            // ── Pass C: All-words match (scan all contacts, check if all query words appear) ──
            val queryWords = lowerQuery.split(Regex("\\s+"))
            if (queryWords.isNotEmpty()) {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(1) ?: continue
                        val number = cursor.getString(0) ?: continue
                        val lowerName = name.lowercase()

                        // Check if all words in the query appear in the contact name
                        val matchesAllWords = queryWords.all { word ->
                            lowerName.contains(word)
                        }

                        if (matchesAllWords && number.isNotEmpty()) {
                            Log.i(TAG, "★ Word-match: \"$name\" → $number")
                            return ResolvedContact(phoneNumber = number, displayName = name)
                        }
                    }
                }
            }

            // ── Pass D: Try each word individually (skip short words) ──
            for (word in queryWords) {
                if (word.length < 3) continue
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                    arrayOf("%$word%"),
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val number = cursor.getString(0) ?: ""
                        val name = cursor.getString(1) ?: query
                        if (number.isNotEmpty()) {
                            Log.i(TAG, "★ Single-word match: \"$name\" → $number (word: $word)")
                            return ResolvedContact(phoneNumber = number, displayName = name)
                        }
                    }
                }
            }

            // ── Pass E: Try nickname variants as single words ──
            for (term in searchTerms) {
                if (term == lowerQuery) continue  // Already tried
                if (term.length < 3) continue

                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                    arrayOf("%$term%"),
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val number = cursor.getString(0) ?: ""
                        val name = cursor.getString(1) ?: query
                        if (number.isNotEmpty()) {
                            Log.i(TAG, "★ Nickname match: \"$name\" → $number (term: $term)")
                            return ResolvedContact(phoneNumber = number, displayName = name)
                        }
                    }
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error querying contacts for \"$query\"", e)
        }

        Log.w(TAG, "No contact found for \"$query\" (tried: $searchTerms)")
        return ResolvedContact(phoneNumber = "", displayName = query)
    }

    /**
     * Normalize a phone number for Indian context.
     * - Removes spaces, dashes, parentheses
     * - If 10 digits and starts with 0, removes leading 0
     * - If 10 digits without country code, adds +91
     * - If 11 digits starting with 0, removes 0 → adds +91
     */
    private fun normalizePhoneNumber(number: String): String {
        var cleaned = number.replace(Regex("[\\s\\-()]"), "")

        // Remove leading 0 (Indian landline/mobile convention)
        if (cleaned.startsWith("0") && cleaned.length == 11) {
            cleaned = cleaned.substring(1)
        }

        // If 10 digits and no country code, add +91 (India)
        if (cleaned.length == 10 && !cleaned.startsWith("+")) {
            cleaned = "+91$cleaned"
        }

        // If starts with 91 and 12 digits, add +
        if (cleaned.startsWith("91") && cleaned.length == 12 && !cleaned.startsWith("+")) {
            cleaned = "+$cleaned"
        }

        return cleaned
    }

    /**
     * Save the last called number for redial functionality.
     */
    private fun saveLastCalled(context: Context, number: String, name: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_LAST_NUMBER, number)
            .putString(KEY_LAST_NAME, name)
            .apply()
    }

    /**
     * Internal data class for resolved contact info.
     */
    private data class ResolvedContact(
        val phoneNumber: String,
        val displayName: String
    )
}
