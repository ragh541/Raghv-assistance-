package com.aiassistant.voicest

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

/**
 * CommandDisplayView — A rich visual feedback component that displays the
 * recognized user command as text while the assistant is processing.
 *
 * Features:
 * 1. STATE-DRIVEN VISUAL FEEDBACK:
 *    - IDLE: Dim placeholder text, subtle pulsing dot
 *    - LISTENING: Animated waveform dots + "Listening..." text with shimmer
 *    - RECOGNIZED: Full command text appears with typewriter animation
 *    - PROCESSING: Animated spinner ring + "Processing..." text
 *    - COMPLETE: Command text + result with success checkmark pulse
 *    - ERROR: Red text with shake animation
 *
 * 2. TYPEWRITER ANIMATION:
 *    When the recognized command arrives, text types out character-by-character
 *    at 30ms per char — giving a "Jarvis terminal" feel
 *
 * 3. DYNAMIC STATUS LINE:
 *    Below the command text, a secondary line shows the assistant's response
 *    or current processing status, with smooth colour transitions
 *
 * 4. SHIMMER EFFECT:
 *    A horizontal gradient sweep animates across the text during LISTENING
 *    and PROCESSING states — visual "thinking" indicator
 *
 * Usage:
 *   commandDisplay.setState(CommandDisplayView.State.LISTENING)
 *   commandDisplay.setCommand("open youtube")
 *   commandDisplay.setState(CommandDisplayView.State.PROCESSING)
 *   commandDisplay.setResult("Opening youtube")
 *   commandDisplay.setState(CommandDisplayView.State.COMPLETE)
 *
 * In XML:
 *   <com.aiassistant.voicest.CommandDisplayView
 *       android:id="@+id/commandDisplay"
 *       android:layout_width="match_parent"
 *       android:layout_height="wrap_content"
 *       android:minHeight="120dp" />
 */
class CommandDisplayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val TAG = "CommandDisplayView"

    // ---- States ----
    enum class State {
        IDLE,         // Waiting — dim, nothing happening
        LISTENING,   // Mic is active, hearing user
        RECOGNIZED,  // Command text received, displaying
        PROCESSING,  // Assistant is processing / AI thinking
        COMPLETE,    // Command executed, showing result
        ERROR        // Something went wrong
    }

    // ---- Current State ----
    private var currentState = State.IDLE
    private var commandText = ""
    private var displayText = ""        // Typewriter animated version of commandText
    private var resultText = ""
    private var displayResult = ""     // Typewriter animated version of resultText

    // ---- Typewriter Animation ----
    private var typewriterIndex = 0
    private var typewriterResultIndex = 0
    private val TYPEWRITER_DELAY = 30L  // ms per character
    private val mainHandler = Handler(Looper.getMainLooper())
    private var typewriterRunnable: Runnable? = null

    // ---- Shimmer ----
    private var shimmerOffset = 0f
    private var shimmerAnimator: ValueAnimator? = null

    // ---- Spinner ----
    private var spinnerAngle = 0f

    // ---- Pulsing dot ----
    private var dotPhase = 0f

    // ---- Error shake ----
    private var shakeOffset = 0f
    private var shakeAnimator: ValueAnimator? = null

    // ---- Paints ----
    private val commandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 42f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val resultPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 32f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
        textAlign = Paint.Align.CENTER
    }

    private val statusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 28f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.ITALIC)
        textAlign = Paint.Align.CENTER
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val spinnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
    }

    private val shimmerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    // ---- Colours ----
    private val colorIdle = Color.parseColor("#30363D")
    private val colorListening = Color.parseColor("#3FB950")
    private val colorRecognized = Color.parseColor("#58A6FF")
    private val colorProcessing = Color.parseColor("#F0883E")
    private val colorComplete = Color.parseColor("#3FB950")
    private val colorError = Color.parseColor("#F85149")
    private val colorTextBright = Color.parseColor("#F0F6FC")
    private val colorTextDim = Color.parseColor("#8B949E")

    private val dp = resources.displayMetrics.density

    init {
        minimumHeight = (120 * dp).toInt()
        startShimmerAnimation()
        startPulseAnimation()
    }

    // ============================================================
    // Public API
    // ============================================================

    /**
     * Transition to a new state. Handles visual transitions.
     */
    fun setState(state: State) {
        Log.i(TAG, "State: $currentState → $state")
        currentState = state

        when (state) {
            State.IDLE -> {
                displayText = ""
                displayResult = ""
                commandText = ""
                resultText = ""
            }
            State.LISTENING -> {
                displayText = ""
                displayResult = ""
            }
            State.RECOGNIZED -> {
                startTypewriter()
            }
            State.PROCESSING -> {
                // Keep showing the command text, add processing indicator
            }
            State.COMPLETE -> {
                startResultTypewriter()
            }
            State.ERROR -> {
                startShake()
            }
        }

        invalidate()
    }

    /**
     * Set the recognized command text. Triggers typewriter animation.
     */
    fun setCommand(text: String) {
        commandText = text
        displayText = ""
        typewriterIndex = 0
        startTypewriter()
    }

    /**
     * Set the result/response text. Shown below the command.
     */
    fun setResult(text: String) {
        resultText = text
        displayResult = ""
        typewriterResultIndex = 0
        startResultTypewriter()
    }

    /**
     * Get current state.
     */
    fun getState(): State = currentState

    /**
     * Reset to idle state.
     */
    fun reset() {
        typewriterRunnable?.let { mainHandler.removeCallbacks(it) }
        commandText = ""
        displayText = ""
        resultText = ""
        displayResult = ""
        typewriterIndex = 0
        typewriterResultIndex = 0
        setState(State.IDLE)
    }

    // ============================================================
    // Typewriter Animation
    // ============================================================

    private fun startTypewriter() {
        typewriterRunnable?.let { mainHandler.removeCallbacks(it) }

        typewriterRunnable = object : Runnable {
            override fun run() {
                if (typewriterIndex < commandText.length) {
                    displayText = commandText.substring(0, typewriterIndex + 1)
                    typewriterIndex++
                    invalidate()
                    mainHandler.postDelayed(this, TYPEWRITER_DELAY)
                } else {
                    displayText = commandText
                    invalidate()
                }
            }
        }
        mainHandler.postDelayed(typewriterRunnable!!, TYPEWRITER_DELAY)
    }

    private fun startResultTypewriter() {
        val resultRunnable = object : Runnable {
            override fun run() {
                if (typewriterResultIndex < resultText.length) {
                    displayResult = resultText.substring(0, typewriterResultIndex + 1)
                    typewriterResultIndex++
                    invalidate()
                    mainHandler.postDelayed(this, TYPEWRITER_DELAY)
                } else {
                    displayResult = resultText
                    invalidate()
                }
            }
        }
        mainHandler.postDelayed(resultRunnable, TYPEWRITER_DELAY)
    }

    // ============================================================
    // Shimmer Animation — sweeps across text during listening/processing
    // ============================================================

    private fun startShimmerAnimation() {
        shimmerAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1500L
            repeatMode = ValueAnimator.RESTART
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                shimmerOffset = it.animatedValue as Float
                if (currentState == State.LISTENING || currentState == State.PROCESSING) {
                    invalidate()
                }
            }
            start()
        }
    }

    // ============================================================
    // Pulse Animation — for idle/listening dots
    // ============================================================

    private fun startPulseAnimation() {
        ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
            duration = 1200L
            repeatMode = ValueAnimator.RESTART
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                dotPhase = it.animatedValue as Float
                spinnerAngle = (it.animatedValue as Float) * 180f / Math.PI.toFloat()
                if (currentState == State.LISTENING || currentState == State.IDLE || currentState == State.PROCESSING) {
                    invalidate()
                }
            }
            start()
        }
    }

    // ============================================================
    // Shake Animation — for error state
    // ============================================================

    private fun startShake() {
        shakeAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 400L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = 3
            addUpdateListener {
                val progress = it.animatedValue as Float
                shakeOffset = (sin(progress * Math.PI * 8).toFloat()) * 10f * dp
                invalidate()
            }
            start()
        }
    }

    // ============================================================
    // Drawing
    // ============================================================

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        val centerX = w / 2f
        val centerY = h / 2f

        when (currentState) {
            State.IDLE -> drawIdle(canvas, centerX, centerY)
            State.LISTENING -> drawListening(canvas, centerX, centerY, w)
            State.RECOGNIZED -> drawRecognized(canvas, centerX, centerY, w)
            State.PROCESSING -> drawProcessing(canvas, centerX, centerY, w)
            State.COMPLETE -> drawComplete(canvas, centerX, centerY, w)
            State.ERROR -> drawError(canvas, centerX, centerY, w)
        }
    }

    // ---- IDLE: Dim placeholder + pulsing dot ----
    private fun drawIdle(canvas: Canvas, cx: Float, cy: Float) {
        commandPaint.color = colorIdle
        canvas.drawText("Waiting for command...", cx, cy, commandPaint)

        // Pulsing dot below
        val dotY = cy + 30f * dp
        val pulse = (sin(dotPhase) + 1f) / 2f
        dotPaint.color = Color.parseColor("#30363D")
        dotPaint.alpha = (80 + pulse * 80).toInt()
        canvas.drawCircle(cx, dotY, (4 + pulse * 2) * dp, dotPaint)
    }

    // ---- LISTENING: Animated dots + shimmer text ----
    private fun drawListening(canvas: Canvas, cx: Float, cy: Float, w: Float) {
        // Shimmer sweep on "Listening..."
        val shimmerX = shimmerOffset * w
        shimmerPaint.shader = LinearGradient(
            shimmerX - 100 * dp, 0f,
            shimmerX + 100 * dp, 0f,
            intArrayOf(
                Color.parseColor("#1a3FB950"),
                Color.parseColor("#3FB950"),
                Color.parseColor("#1a3FB950")
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )

        commandPaint.color = colorListening
        canvas.drawText("Listening...", cx, cy, commandPaint)

        // Animated dots
        for (i in 0..2) {
            val dotX = cx + (i - 1) * 24 * dp
            val phase = dotPhase + i * 0.8f
            val scale = (sin(phase) + 1f) / 2f
            dotPaint.color = colorListening
            dotPaint.alpha = (100 + scale * 155).toInt()
            canvas.drawCircle(dotX, cy + 30f * dp, (3 + scale * 4) * dp, dotPaint)
        }
    }

    // ---- RECOGNIZED: Command text with typewriter + accent colour ----
    private fun drawRecognized(canvas: Canvas, cx: Float, cy: Float, w: Float) {
        if (displayText.isNotEmpty()) {
            // Draw command in quotes with blue accent
            commandPaint.color = colorRecognized
            val quoted = "\"$displayText\""
            canvas.drawText(quoted, cx, cy - 10f * dp, commandPaint)

            // Small "Recognized" label below
            statusPaint.color = colorTextDim
            canvas.drawText("Command recognized", cx, cy + 30f * dp, statusPaint)
        }
    }

    // ---- PROCESSING: Command text + spinner ring ----
    private fun drawProcessing(canvas: Canvas, cx: Float, cy: Float, w: Float) {
        // Show the command text (dimmed)
        commandPaint.color = colorTextDim
        val quoted = if (commandText.isNotEmpty()) "\"$commandText\"" else ""
        if (quoted.isNotEmpty()) {
            canvas.drawText(quoted, cx, cy - 15f * dp, commandPaint)
        }

        // Spinner ring
        val spinnerRadius = 16f * dp
        val spinnerY = cy + 20f * dp
        spinnerPaint.color = colorProcessing
        spinnerPaint.alpha = 180

        // Draw arc that rotates
        val sweepAngle = 120f
        val startAngle = spinnerAngle
        val rect = android.graphics.RectF(
            cx - spinnerRadius, spinnerY - spinnerRadius,
            cx + spinnerRadius, spinnerY + spinnerRadius
        )
        canvas.drawArc(rect, startAngle, sweepAngle, false, spinnerPaint)

        // "Processing..." text
        statusPaint.color = colorProcessing
        canvas.drawText("Processing...", cx, spinnerY + 35f * dp, statusPaint)
    }

    // ---- COMPLETE: Command + result with success indicator ----
    private fun drawComplete(canvas: Canvas, cx: Float, cy: Float, w: Float) {
        // Command text (slightly dimmed)
        commandPaint.color = colorTextDim
        if (commandText.isNotEmpty()) {
            canvas.drawText("\"$commandText\"", cx, cy - 20f * dp, commandPaint)
        }

        // Result text (bright, green-tinted)
        resultPaint.color = colorComplete
        if (displayResult.isNotEmpty()) {
            canvas.drawText(displayResult, cx, cy + 15f * dp, resultPaint)
        }

        // Pulsing success dot
        val pulse = (sin(dotPhase * 2) + 1f) / 2f
        dotPaint.color = colorComplete
        dotPaint.alpha = (150 + pulse * 105).toInt()
        canvas.drawCircle(cx - 60 * dp, cy - 20f * dp, (4 + pulse * 2) * dp, dotPaint)
    }

    // ---- ERROR: Red text with shake ----
    private fun drawError(canvas: Canvas, cx: Float, cy: Float, w: Float) {
        commandPaint.color = colorError
        if (commandText.isNotEmpty()) {
            canvas.drawText("\"$commandText\"", cx + shakeOffset, cy - 15f * dp, commandPaint)
        }

        resultPaint.color = colorError
        resultPaint.alpha = 200
        if (resultText.isNotEmpty()) {
            canvas.drawText(displayResult, cx + shakeOffset, cy + 15f * dp, resultPaint)
        } else {
            canvas.drawText("Error occurred", cx + shakeOffset, cy + 15f * dp, resultPaint)
        }
    }

    // ============================================================
    // Cleanup
    // ============================================================

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        shimmerAnimator?.cancel()
        shakeAnimator?.cancel()
        typewriterRunnable?.let { mainHandler.removeCallbacks(it) }
    }
}
