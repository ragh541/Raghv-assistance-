package com.aiassistant.voicest

import android.content.Context
import android.media.AudioManager
import android.util.Log

/**
 * VolumeController — Utility for controlling system volume via voice commands.
 *
 * Uses Android's AudioManager to adjust the STREAM_MUSIC volume (the primary
 * media volume stream). All methods return a spoken response string for TTS.
 *
 * Supported voice commands (handled by caller):
 *   "set volume to 50%"     → setVolumePercent(50)
 *   "set volume to 50"       → setVolumePercent(50)
 *   "volume 50"              → setVolumePercent(50)
 *   "volume up"              → increaseVolume()
 *   "volume down"            → decreaseVolume()
 *   "increase volume"        → increaseVolume()
 *   "decrease volume"        → decreaseVolume()
 *   "louder"                 → increaseVolume(steps=2)
 *   "softer"                 → decreaseVolume(steps=2)
 *   "mute"                   → mute()
 *   "unmute"                 → unmute()
 *   "max volume"             → setMaxVolume()
 *   "what's the volume"      → getVolumeDescription()
 *
 * Usage:
 *   val response = VolumeController.setVolumePercent(context, 50)
 *   // response → "Volume set to 50 percent"
 *   val response = VolumeController.increaseVolume(context)
 *   // response → "Volume increased to 8 out of 15"
 */
object VolumeController {

    private const val TAG = "VolumeController"

    /**
     * Result of a volume operation.
     */
    data class VolumeResult(
        val success: Boolean,
        val spokenResponse: String,
        val volumePercent: Int = -1,
        val isMuted: Boolean = false
    )

    /**
     * Get the AudioManager instance from context.
     */
    private fun getAudioManager(context: Context): AudioManager {
        return context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    /**
     * Set the volume as a percentage (0–100).
     *
     * Converts the percentage to the AudioManager's discrete scale
     * for STREAM_MUSIC and applies it.
     *
     * @param context Activity or Service context
     * @param percent Volume percentage (0–100), clamped automatically
     * @return VolumeResult with spoken response
     */
    fun setVolumePercent(context: Context, percent: Int): VolumeResult {
        val audioManager = getAudioManager(context)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val clampedPercent = percent.coerceIn(0, 100)

        // Convert percentage to the discrete volume index
        // Using rounding: index = round(percent/100 * max)
        val targetIndex = ((clampedPercent / 100.0) * maxVolume).toInt()
            .coerceIn(0, maxVolume)

        return try {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                targetIndex,
                AudioManager.FLAG_SHOW_UI  // Show the volume slider on screen
            )
            val actualPercent = if (maxVolume > 0) (targetIndex * 100 / maxVolume) else 0
            Log.i(TAG, "★ Volume set to $clampedPercent% → index=$targetIndex/$maxVolume")
            VolumeResult(
                success = true,
                spokenResponse = "Volume set to $actualPercent percent",
                volumePercent = actualPercent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set volume to $clampedPercent%", e)
            VolumeResult(
                success = false,
                spokenResponse = "I couldn't set the volume"
            )
        }
    }

    /**
     * Increase the volume by one step (or multiple if steps specified).
     *
     * @param context Activity or Service context
     * @param steps Number of steps to increase (default 1)
     * @return VolumeResult with spoken response
     */
    fun increaseVolume(context: Context, steps: Int = 1): VolumeResult {
        val audioManager = getAudioManager(context)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

        return try {
            // If already at max, inform the user
            if (currentVolume >= maxVolume) {
                val percent = if (maxVolume > 0) (currentVolume * 100 / maxVolume) else 0
                return VolumeResult(
                    success = true,
                    spokenResponse = "Volume is already at maximum, $percent percent",
                    volumePercent = percent
                )
            }

            audioManager.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI
            )
            // If more steps, use setStreamVolume for precision
            val newVolume = (currentVolume + steps).coerceAtMost(maxVolume)
            if (steps > 1) {
                audioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    newVolume,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            val percent = if (maxVolume > 0) (newVolume * 100 / maxVolume) else 0
            Log.i(TAG, "★ Volume increased by $steps → $newVolume/$maxVolume ($percent%)")
            VolumeResult(
                success = true,
                spokenResponse = "Volume increased to $percent percent",
                volumePercent = percent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to increase volume", e)
            VolumeResult(
                success = false,
                spokenResponse = "I couldn't increase the volume"
            )
        }
    }

    /**
     * Decrease the volume by one step (or multiple if steps specified).
     *
     * @param context Activity or Service context
     * @param steps Number of steps to decrease (default 1)
     * @return VolumeResult with spoken response
     */
    fun decreaseVolume(context: Context, steps: Int = 1): VolumeResult {
        val audioManager = getAudioManager(context)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

        return try {
            // If already at 0, inform the user
            if (currentVolume <= 0) {
                return VolumeResult(
                    success = true,
                    spokenResponse = "Volume is already at zero",
                    volumePercent = 0
                )
            }

            audioManager.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
            // If more steps, use setStreamVolume for precision
            val newVolume = (currentVolume - steps).coerceAtLeast(0)
            if (steps > 1) {
                audioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    newVolume,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            val percent = if (maxVolume > 0) (newVolume * 100 / maxVolume) else 0
            Log.i(TAG, "★ Volume decreased by $steps → $newVolume/$maxVolume ($percent%)")
            VolumeResult(
                success = true,
                spokenResponse = "Volume decreased to $percent percent",
                volumePercent = percent
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrease volume", e)
            VolumeResult(
                success = false,
                spokenResponse = "I couldn't decrease the volume"
            )
        }
    }

    /**
     * Mute the volume (set to 0).
     *
     * @param context Activity or Service context
     * @return VolumeResult with spoken response
     */
    fun mute(context: Context): VolumeResult {
        val audioManager = getAudioManager(context)
        return try {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                0,
                AudioManager.FLAG_SHOW_UI
            )
            Log.i(TAG, "★ Volume muted")
            VolumeResult(
                success = true,
                spokenResponse = "Volume muted",
                volumePercent = 0,
                isMuted = true
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to mute volume", e)
            VolumeResult(
                success = false,
                spokenResponse = "I couldn't mute the volume"
            )
        }
    }

    /**
     * Unmute the volume — restores to a reasonable default (50%)
     * since we don't track the previous volume state.
     *
     * @param context Activity or Service context
     * @return VolumeResult with spoken response
     */
    fun unmute(context: Context): VolumeResult {
        val audioManager = getAudioManager(context)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

        // If volume is already above 0, nothing to unmute
        if (currentVolume > 0) {
            val percent = if (maxVolume > 0) (currentVolume * 100 / maxVolume) else 0
            return VolumeResult(
                success = true,
                spokenResponse = "Volume is already on, at $percent percent",
                volumePercent = percent,
                isMuted = false
            )
        }

        // Restore to 50% as a sensible default
        val restoreIndex = (maxVolume / 2).coerceAtLeast(1)
        return try {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                restoreIndex,
                AudioManager.FLAG_SHOW_UI
            )
            val percent = if (maxVolume > 0) (restoreIndex * 100 / maxVolume) else 0
            Log.i(TAG, "★ Volume unmuted → $restoreIndex/$maxVolume ($percent%)")
            VolumeResult(
                success = true,
                spokenResponse = "Volume unmuted, set to $percent percent",
                volumePercent = percent,
                isMuted = false
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to unmute volume", e)
            VolumeResult(
                success = false,
                spokenResponse = "I couldn't unmute the volume"
            )
        }
    }

    /**
     * Set volume to maximum.
     *
     * @param context Activity or Service context
     * @return VolumeResult with spoken response
     */
    fun setMaxVolume(context: Context): VolumeResult {
        val audioManager = getAudioManager(context)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return try {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                maxVolume,
                AudioManager.FLAG_SHOW_UI
            )
            Log.i(TAG, "★ Volume set to maximum → $maxVolume")
            VolumeResult(
                success = true,
                spokenResponse = "Volume set to maximum",
                volumePercent = 100
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set max volume", e)
            VolumeResult(
                success = false,
                spokenResponse = "I couldn't set the volume to maximum"
            )
        }
    }

    /**
     * Get the current volume as a spoken description.
     *
     * @param context Activity or Service context
     * @return VolumeResult with spoken response
     */
    fun getVolumeDescription(context: Context): VolumeResult {
        val audioManager = getAudioManager(context)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val percent = if (maxVolume > 0) (currentVolume * 100 / maxVolume) else 0

        val response = if (currentVolume == 0) {
            "Volume is muted"
        } else {
            "Volume is at $percent percent"
        }

        return VolumeResult(
            success = true,
            spokenResponse = response,
            volumePercent = percent,
            isMuted = currentVolume == 0
        )
    }

    /**
     * Parse a voice command string and extract a volume percentage.
     * Handles patterns like:
     *   "set volume to 50%"  → 50
     *   "set volume to 50"    → 50
     *   "volume 50"           → 50
     *   "volume to 80 percent" → 80
     *
     * @param command The full spoken command text
     * @return The extracted percentage (0–100), or null if not found
     */
    fun parseVolumePercent(command: String): Int? {
        // Look for a number followed by optional % or "percent"
        val patterns = listOf(
            Regex("(\\d+)\\s*%"),
            Regex("(\\d+)\\s*percent"),
            Regex("volume\\s+(?:to\\s+)?(\\d+)"),
            Regex("volume.*?(\\d+)"),
            Regex("(\\d+)")
        )

        for (pattern in patterns) {
            val match = pattern.find(command)
            if (match != null) {
                val num = match.groupValues[1].toIntOrNull()
                if (num != null && num in 0..100) {
                    return num
                }
                // If number is > 100, treat as 100
                if (num != null && num > 100) {
                    return 100
                }
            }
        }

        return null
    }
}
