package com.aiassistant.voicest

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.app.SearchManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random

/**
 * VoiceAssistantService — Jarvis-style always-listening foreground service.
 *
 * TWO-PHASE WAKE WORD SYSTEM (like Jarvis / Siri):
 *
 * Phase 1 — IDLE LISTENING (always on):
 *   The microphone continuously listens. The service ignores everything
 *   EXCEPT the wake word. When the user says "Raghv" (or variations like
 *   "hey raghv", "ok raghv"), the service transitions to Phase 2.
 *
 * Phase 2 — COMMAND MODE (activated by wake word):
 *   The service speaks a greeting via TTS (e.g. "Yes?", "How can I help?")
 *   and then listens for ONE command. No wake word needed in this phase.
 *   After executing the command, it returns to Phase 1.
 *   If no speech is detected within COMMAND_TIMEOUT (8 seconds), it
 *   returns to Phase 1 automatically.
 *
 * Example flow:
 *   User: "Raghv"           → Service: "Yes?" (TTS)
 *   User: "open youtube"    → Service: "Opening youtube" (TTS) → YouTube opens
 *   (back to Phase 1 — waiting for "Raghv" again)
 *
 * Supported commands (Phase 2):
 *   - "open <app>"           → Launch app (whatsapp, youtube, instagram, etc.)
 *   - "call <name/number>"   → Open dialer
 *   - "search <query>"       → Google search
 *   - "set alarm <time>"     → Set alarm
 *   - "set timer <duration>" → Set timer
 *   - "what time is it"      → Speak current time
 *   - "what date is it"      → Speak current date
 *   - "stop" / "go to sleep" → Return to idle (Phase 1)
 *   - "shut down"            → Stop the service entirely
 */
class VoiceAssistantService : Service(), TextToSpeech.OnInitListener {

    private val TAG = "VoiceAssistantService"
    private val CHANNEL_ID = "voice_assistant_channel"
    private val NOTIFICATION_ID = 1001

    // ---- Wake Word Configuration ----
    // The user's name is the wake word — like "Jarvis" in Iron Man
    private val wakeWords = listOf("raghv", "raghav", "raghvant", "raghu")
    private val wakeVariations = mutableListOf<String>().apply {
        for (w in wakeWords) {
            add(w)
            add("hey $w")
            add("ok $w")
            add("hi $w")
        }
    }

    // ---- Phase Management ----
    private enum class Phase {
        IDLE_LISTENING,    // Phase 1: Waiting for wake word
        COMMAND_MODE       // Phase 2: Wake word detected, listening for command
    }

    private var currentPhase = Phase.IDLE_LISTENING

    // ---- Timing ----
    private val COMMAND_TIMEOUT = 8000L   // 8 seconds to say a command after wake word
    private val RESTART_DELAY = 300L      // Delay between recognition cycles
    private val POST_COMMAND_DELAY = 800L // Delay after executing a command before returning to idle
    private val mainHandler = Handler(Looper.getMainLooper())
    private var commandTimeoutRunnable: Runnable? = null

    // ---- Core Components ----
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var isListening = false
    private var shouldRestart = true

    // ---- Custom Commands Store ----
    private lateinit var customCommandStore: CustomCommandStore

    // ---- App Shortcuts Store (keyword → app) ----
    // Checked BEFORE custom commands and built-in "open" for instant app launching
    private lateinit var appShortcutStore: AppShortcutStore

    // ---- Dedicated Offline Hotword Detector (Vosk) ----
    // Replaces SpeechRecognizer for Phase 1 (idle wake word listening).
    // 100% offline, no gaps, no internet needed — far more reliable than
    // SpeechRecognizer for always-on wake word detection.
    private var hotwordDetector: HotwordDetector? = null
    private var useHotwordDetector = true  // Set false to fall back to SpeechRecognizer

    // ---- Offline Command Recognizer (Vosk) ----
    // Used for Phase 2 (command mode) when internet is unavailable.
    // Recognizes a predefined vocabulary of command phrases offline.
    private var offlineCommandRecognizer: OfflineCommandRecognizer? = null

    // ---- Media Session Helper ----
    // Monitors active media sessions (Spotify, YouTube Music, etc.)
    // and broadcasts updates to the ContextualCardView on main + lock screen.
    private var mediaSessionHelper: MediaSessionHelper? = null

    // ---- WakeLock — keeps CPU awake when screen is off so mic keeps listening ----
    private var wakeLock: PowerManager.WakeLock? = null

    // ---- Greetings (Jarvis-style) ----
    private val wakeGreetings = listOf(
        "Yes?",
        "How can I help?",
        "I'm listening.",
        "What do you need?",
        "At your service.",
        "Ready.",
        "Yes, sir?"
    )

    // ---- Going-to-sleep acknowledgements ----
    private val sleepAck = listOf(
        "Going to sleep. Say my name when you need me.",
        "Standing by. Just say Raghv to wake me.",
        "Goodbye for now. I'll be here when you need me."
    )

    private val random = Random()

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Service created — Jarvis mode")

        // Initialize Text-to-Speech for voice responses
        tts = TextToSpeech(this, this)

        // Acquire a partial wake lock so the CPU stays awake even when the
        // screen is off — this is CRITICAL for lock-screen / background listening.
        // The mic + SpeechRecognizer need the CPU to stay active.
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "VoiceAssistant::ListeningWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()  // Held for the entire lifetime of the service
        }
        Log.i(TAG, "WakeLock acquired — CPU will stay awake for background listening")

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Handle STOP action from notification
        if (intent?.action == "STOP_SERVICE") {
            Log.i(TAG, "Stop requested by user")
            shouldRestart = false
            stopSelf()
            return START_NOT_STICKY
        }

        Log.i(TAG, "Service started — Jarvis mode active")
        startForeground(NOTIFICATION_ID, buildNotification("Say \"Raghv\" to activate"))

        // Initialize custom commands store
        customCommandStore = CustomCommandStore(this)
        customCommandStore.seedDefaultsIfEmpty()

        // Initialize app shortcuts store
        appShortcutStore = AppShortcutStore(this)
        appShortcutStore.seedDefaultsIfEmpty()

        // Initialize media session monitoring
        startMediaSessionMonitoring()

        shouldRestart = true
        currentPhase = Phase.IDLE_LISTENING
        startListeningLoop()
        return START_STICKY
    }

    // ============================================================
    // Phase 1: IDLE LISTENING — Dedicated Offline Hotword Detection
    // ============================================================
    // Uses Vosk library for 100% offline, continuous, gap-free
    // wake word detection. When the hotword "Raghav" is detected,
    // transitions to Phase 2 (command mode) which uses SpeechRecognizer.
    //
    // Fallback: If the Vosk model is not downloaded, falls back to
    // the old SpeechRecognizer-based continuous listening loop.

    private fun startListeningLoop() {
        if (isListening) return

        // Try the dedicated hotword detector first
        if (useHotwordDetector && startHotwordDetection()) {
            // Hotword detector started successfully — it will call
            // handleIdlePhase() when the wake word is detected.
            return
        }

        // Fallback: use SpeechRecognizer for idle listening too
        Log.w(TAG, "Falling back to SpeechRecognizer for wake word detection")
        startSpeechRecognizerLoop()
    }

    /**
     * Start the dedicated Vosk-based hotword detector.
     * Returns true if started successfully, false if model not available.
     */
    private fun startHotwordDetection(): Boolean {
        if (hotwordDetector != null && hotwordDetector!!.isRunning()) {
            Log.d(TAG, "Hotword detector already running")
            return true
        }

        // Check if Vosk model is available
        hotwordDetector = HotwordDetector(this)

        if (!hotwordDetector!!.isModelAvailable()) {
            Log.w(TAG, "Vosk model not downloaded — cannot use dedicated hotword detection")
            hotwordDetector = null
            return false
        }

        hotwordDetector!!.setListener(object : HotwordDetector.Listener {
            override fun onHotwordDetected(word: String) {
                // Called on Vosk's background thread — switch to main thread
                mainHandler.post {
                    if (currentPhase == Phase.IDLE_LISTENING) {
                        handleIdlePhase(word)
                    }
                }
            }

            override fun onError(message: String) {
                Log.e(TAG, "Hotword detector error: $message")
                // Fall back to SpeechRecognizer if Vosk fails
                mainHandler.post {
                    if (shouldRestart && currentPhase == Phase.IDLE_LISTENING) {
                        Log.w(TAG, "Switching to SpeechRecognizer fallback")
                        startSpeechRecognizerLoop()
                    }
                }
            }

            override fun onStarted() {
                Log.i(TAG, "★ Vosk hotword detector started — truly continuous offline listening")
                isListening = true
            }

            override fun onStopped() {
                isListening = false
                Log.i(TAG, "Hotword detector stopped")
            }
        })

        hotwordDetector!!.start()
        return true
    }

    // ============================================================
    // SpeechRecognizer Loop — used for Phase 2 (command capture)
    // AND as fallback for Phase 1 if Vosk model is not available
    // ============================================================

    private fun startSpeechRecognizerLoop() {
        if (isListening) return

        // Stop the hotword detector if it's running — we need the mic for SpeechRecognizer
        stopHotwordDetector()

        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rms: Float) {}

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    isListening = false
                }

                override fun onError(error: Int) {
                    isListening = false
                    Log.w(TAG, "Recognition error ($error) in phase: $currentPhase")

                    if (shouldRestart) {
                        // Shorter delay for NO_MATCH / TIMEOUT — these are normal
                        // when nobody is speaking
                        val delay = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> RESTART_DELAY
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 500L
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 800L
                            else -> 1000L
                        }
                        mainHandler.postDelayed({ restartListening() }, delay)
                    }
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.trim() ?: ""

                    if (text.isNotEmpty()) {
                        Log.i(TAG, "Heard: \"$text\" (Phase: $currentPhase)")

                        when (currentPhase) {
                            Phase.IDLE_LISTENING -> handleIdlePhase(text)
                            Phase.COMMAND_MODE -> handleCommandPhase(text)
                        }
                    }

                    // Auto-restart to keep listening
                    if (shouldRestart) {
                        mainHandler.postDelayed({ restartListening() }, RESTART_DELAY)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening", e)
            mainHandler.postDelayed({ restartListening() }, 2000L)
        }
    }

    private fun restartListening() {
        if (shouldRestart && !isListening) {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()

            if (currentPhase == Phase.IDLE_LISTENING) {
                // Back to idle — stop offline command recognizer if running, restart hotword detector
                stopOfflineCommandRecognizer()
                startListeningLoop()
            } else {
                // In command mode — choose between online (SpeechRecognizer) and offline (Vosk)
                if (shouldUseOfflineRecognition()) {
                    Log.i(TAG, "★ No internet — using OFFLINE Vosk command recognition")
                    startOfflineCommandRecognition()
                } else {
                    startSpeechRecognizerLoop()
                }
            }
        }
    }

    /**
     * Determine whether to use offline Vosk recognition for command mode.
     *
     * Uses Vosk when:
     * - The Vosk model is available (downloaded)
     * - AND there is no active internet connection
     *
     * Falls back to SpeechRecognizer when online (better accuracy for
     * free-form commands like Gemini queries, contact names, etc.)
     */
    private fun shouldUseOfflineRecognition(): Boolean {
        // Check if Vosk model is available
        if (!OfflineCommandRecognizer.isModelAvailable(this)) {
            Log.d(TAG, "Vosk model not available — will use SpeechRecognizer")
            return false
        }

        // Check network connectivity
        val isOnline = isNetworkAvailable()
        Log.d(TAG, "Network available: $isOnline, Vosk model: available")
        return !isOnline
    }

    /**
     * Check if the device has an active internet connection.
     */
    private fun isNetworkAvailable(): Boolean {
        return try {
            val connectivityManager = getSystemService(android.content.Context.CONNECTIVITY_SERVICE)
                as android.net.ConnectivityManager
            val network = connectivityManager.activeNetwork
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            capabilities != null && (
                capabilities.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not check network status — assuming offline", e)
            false
        }
    }

    /**
     * Start offline Vosk-based command recognition for Phase 2.
     *
     * This is used when internet is unavailable. The OfflineCommandRecognizer
     * listens for a single command utterance using a grammar-constrained Vosk
     * recognizer, then passes the result to the same handleCommandPhase()
     * that processes online SpeechRecognizer results.
     */
    private fun startOfflineCommandRecognition() {
        if (isListening) return

        // Stop the hotword detector — we need the mic for command recognition
        stopHotwordDetector()

        // Cancel any existing offline recognizer
        stopOfflineCommandRecognizer()

        offlineCommandRecognizer = OfflineCommandRecognizer(this)

        if (!offlineCommandRecognizer!!.isModelAvailable()) {
            Log.w(TAG, "Vosk model not available for offline command recognition")
            offlineCommandRecognizer = null
            // Last resort: try SpeechRecognizer anyway (may fail without internet)
            startSpeechRecognizerLoop()
            return
        }

        offlineCommandRecognizer!!.setListener(object : OfflineCommandRecognizer.Listener {
            override fun onCommandRecognized(text: String) {
                mainHandler.post {
                    isListening = false
                    if (currentPhase == Phase.COMMAND_MODE) {
                        Log.i(TAG, "★ OFFLINE: Command recognized → \"$text\"")
                        handleCommandPhase(text)
                    }
                }
            }

            override fun onTimeout() {
                mainHandler.post {
                    isListening = false
                    Log.i(TAG, "⏱ Offline command recognition timed out")
                    // Speak timeout message and return to idle
                    val msg = "I didn't hear a command. Going back to sleep."
                    speak(msg)
                    updateLockScreen(msg, "Say \"Raghv\" to activate")
                    currentPhase = Phase.IDLE_LISTENING
                    updateNotification("Say \"Raghv\" to activate")
                    startListeningLoop()
                }
            }

            override fun onError(message: String) {
                mainHandler.post {
                    isListening = false
                    Log.e(TAG, "Offline recognition error: $message")
                    // Fall back to SpeechRecognizer
                    startSpeechRecognizerLoop()
                }
            }

            override fun onStarted() {
                isListening = true
                Log.i(TAG, "Offline command recognition is listening...")
            }
        })

        offlineCommandRecognizer!!.start(timeoutMs = COMMAND_TIMEOUT)
    }

    /**
     * Stop the offline command recognizer and release its resources.
     */
    private fun stopOfflineCommandRecognizer() {
        offlineCommandRecognizer?.let {
            it.stop()
            Log.d(TAG, "Offline command recognizer stopped")
        }
        offlineCommandRecognizer = null
    }

    // ============================================================
    // Media Session Monitoring — Contextual Media Card
    // ============================================================

    /**
     * Start monitoring media sessions and broadcasting state updates
     * to the main activity and lock screen overlay.
     *
     * When a media session is active (Spotify, YouTube Music, etc.),
     * the ContextualCardView shows album art, track info, and transport
     * controls. When no media is active, the card hides.
     */
    private fun startMediaSessionMonitoring() {
        mediaSessionHelper = MediaSessionHelper(this)
        mediaSessionHelper!!.setListener(object : MediaSessionHelper.Listener {
            override fun onMediaStateChanged(state: MediaSessionHelper.MediaState) {
                        Log.d(TAG, "♪ Media state: \"${state.title}\" by \"${state.artist}\" (playing=${state.isPlaying})")
                // Broadcast to lock screen + main activity
                broadcastMediaUpdate(state)
            }

            override fun onNoMediaSession() {
                Log.d(TAG, "♪ No active media session — hiding contextual card")
                broadcastMediaUpdate(null)
            }
        })
        mediaSessionHelper!!.start()
        Log.i(TAG, "Media session monitoring started")
    }

    /**
     * Broadcast media state update to the lock screen and main activity.
     *
     * @param state The current media state, or null if no session is active.
     */
    private fun broadcastMediaUpdate(state: MediaSessionHelper.MediaState?) {
        val intent = Intent(ACTION_MEDIA_UPDATE).apply {
            setPackage(packageName)
            if (state != null) {
                putExtra("title", state.title)
                putExtra("artist", state.artist)
                putExtra("isPlaying", state.isPlaying)
                putExtra("packageName", state.packageName)
                putExtra("hasActiveSession", state.hasActiveSession)
            } else {
                putExtra("hasActiveSession", false)
            }
        }
        sendBroadcast(intent)
    }

    /**
     * Stop the hotword detector and release its audio resources.
     * Called when transitioning to command mode (SpeechRecognizer needs the mic).
     */
    private fun stopHotwordDetector() {
        hotwordDetector?.let {
            it.stop()
            Log.d(TAG, "Hotword detector stopped — mic released for SpeechRecognizer")
        }
    }

    // ============================================================
    // Phase 1: IDLE — Listen for wake word
    // ============================================================

    private fun handleIdlePhase(text: String) {
        val lower = text.lowercase(Locale.getDefault()).trim()

        // Check if any wake word variation was spoken
        val wakeWordDetected = wakeVariations.any { lower == it || lower.startsWith("$it ") }

        if (wakeWordDetected) {
            Log.i(TAG, "★ WAKE WORD DETECTED: \"$text\" → entering COMMAND_MODE")

            // Transition to command mode
            currentPhase = Phase.COMMAND_MODE
            updateNotification("Listening for command...")

            // Launch the lock screen overlay
            launchLockScreen("Yes?", "Listening for command...")
            sendCommandDisplayUpdate("listening", "", "")

            // Speak a random greeting (Jarvis-style)
            val greeting = wakeGreetings[random.nextInt(wakeGreetings.size)]
            speak(greeting)
            updateLockScreen(greeting, "Speak your command...")

            // Start command timeout — if no command in 8 seconds, go back to idle
            startCommandTimeout()

            // Brief delay to let TTS finish before listening for the command
            mainHandler.postDelayed({
                if (currentPhase == Phase.COMMAND_MODE && shouldRestart) {
                    restartListening()
                }
            }, 1500L)  // Wait 1.5s for greeting to finish

        } else {
            // Not a wake word — ignore, keep listening
            Log.d(TAG, "Not a wake word, ignoring: \"$text\"")
            updateNotification("Say \"Raghv\" to activate")
        }
    }

    // ============================================================
    // Phase 2: COMMAND MODE — Execute the spoken command
    // ============================================================

    private fun handleCommandPhase(text: String) {
        // Cancel the command timeout
        cancelCommandTimeout()

        val command = text.lowercase(Locale.getDefault()).trim()
        Log.i(TAG, "Processing command: \"$command\"")

        // Send recognized command to lock screen display
        sendCommandDisplayUpdate("recognized", text, "")

        // ── Check app shortcuts FIRST (before custom & built-in commands) ──
        // Index-based voice shortcuts: "insta" → Instagram, "pay" → PhonePe, etc.
        val appShortcut = appShortcutStore.findByKeyword(command)
        if (appShortcut != null) {
            Log.i(TAG, "★ APP SHORTCUT MATCHED: \"${appShortcut.keyword}\" → ${appShortcut.packageName}")
            val launched = openAppByPackage(appShortcut.packageName)
            response = if (launched) {
                "Opening ${appShortcut.appLabel}"
            } else {
                "I couldn't open ${appShortcut.appLabel}. The app may not be installed."
            }

            Log.i(TAG, "App shortcut result: $response")
            if (response.isNotEmpty()) {
                updateNotification("Last: $response")
                speak(response)
                updateLockScreen(response, "Back to listening...")
                sendCommandDisplayUpdate("complete", text, response)
            }

            // Return to idle phase
            currentPhase = Phase.IDLE_LISTENING
            updateNotification("Say \"Raghv\" to activate")
            restartListening()
            return
        }

        // ── Check custom commands (after app shortcuts, before built-in) ──
        val customCommand = customCommandStore.findByTrigger(command)
        if (customCommand != null) {
            Log.i(TAG, "★ CUSTOM COMMAND MATCHED: \"${customCommand.triggerPhrase}\" → ${customCommand.actionType}")
            response = executeCustomCommand(customCommand)

            Log.i(TAG, "Custom command result: $response")
            if (response.isNotEmpty()) {
                updateNotification("Last: $response")
                speak(response)
                updateLockScreen(response, "Back to listening...")
                sendCommandDisplayUpdate("complete", text, response)
            }

            // Return to idle phase
            currentPhase = Phase.IDLE_LISTENING
            updateNotification("Say \"Raghv\" to activate")
            restartListening()
            return
        }

        // ── Built-in commands ──
        var response = ""

        response = when {
            // Stop / go to sleep — return to idle listening
            command == "stop" || command == "go to sleep" ||
            command == "never mind" || command == "cancel" -> {
                cancelCommandTimeout()
                currentPhase = Phase.IDLE_LISTENING
                updateNotification("Say \"Raghv\" to activate")
                sleepAck[random.nextInt(sleepAck.size)]
            }

            // Full shutdown — stop the service
            command == "shut down" || command == "power off" -> {
                shouldRestart = false
                stopSelf()
                "Shutting down. Goodbye."
            }

            // Lock screen — "lock screen", "lock phone", "lock the phone", "lock device"
            command == "lock screen" || command == "lock phone" ||
            command == "lock the phone" || command == "lock device" -> {
                lockScreen()
            }

            // Flashlight toggle — "flashlight", "torch", "torch on", "torch off"
            command == "flashlight" || command == "torch" ||
            command == "flashlight on" || command == "torch on" -> {
                toggleFlashlight(true)
            }
            command == "flashlight off" || command == "torch off" -> {
                toggleFlashlight(false)
            }

            // Open app
            command.startsWith("open ") -> {
                val appName = command.removePrefix("open ").trim()
                openApp(appName)
                "Opening $appName"
            }

            // Redial / Call back — "redial", "call back", "redial last", "call again"
            command == "redial" || command == "call back" || command == "redial last" ||
            command == "call again" || command == "dial last" -> {
                val result = CallHelper.redial(this)
                result.spokenResponse
            }

            // Just "call" or "dial" with no name → ask who
            command == "call" || command == "dial" || command == "phone" -> {
                "Who would you like me to call? You can say a name like 'call mom' or a number like 'call 9876543210'."
            }

            // Call / Dial — "call mom", "call 9876543210", "dial john", "phone dad"
            command.startsWith("call ") || command.startsWith("dial ") || command.startsWith("phone ") -> {
                val prefix = when {
                    command.startsWith("call ") -> "call "
                    command.startsWith("dial ") -> "dial "
                    else -> "phone "
                }
                val name = command.removePrefix(prefix).trim()
                val result = CallHelper.call(this, name)
                result.spokenResponse
            }

            // Search
            command.startsWith("search ") || command.startsWith("search for ") -> {
                val query = if (command.startsWith("search for ")) {
                    command.removePrefix("search for ").trim()
                } else {
                    command.removePrefix("search ").trim()
                }
                searchWeb(query)
                "Searching for $query"
            }

            // Google search
            command.startsWith("google ") -> {
                val query = command.removePrefix("google ").trim()
                searchWeb(query)
                "Searching for $query"
            }

            // Set alarm
            command.startsWith("set alarm") -> {
                setAlarm(command)
            }

            // Set timer
            command.startsWith("set timer") -> {
                setTimer(command)
            }

            // ── Volume controls ──
            // "set volume to 50%", "volume 50", "volume to 80 percent"
            command.startsWith("set volume") || command.startsWith("volume ") -> {
                val percent = VolumeController.parseVolumePercent(command)
                if (percent != null) {
                    val result = VolumeController.setVolumePercent(this, percent)
                    result.spokenResponse
                } else {
                    "What volume level? For example, say \"set volume to 50 percent\""
                }
            }

            // "volume up", "volume down", "increase volume", "decrease volume"
            command == "volume up" || command == "increase volume" || command == "louder" -> {
                val steps = if (command == "louder") 2 else 1
                VolumeController.increaseVolume(this, steps).spokenResponse
            }
            command == "volume down" || command == "decrease volume" || command == "softer" -> {
                val steps = if (command == "softer") 2 else 1
                VolumeController.decreaseVolume(this, steps).spokenResponse
            }

            // "mute" / "unmute"
            command == "mute" || command == "mute volume" -> {
                VolumeController.mute(this).spokenResponse
            }
            command == "unmute" || command == "unmute volume" -> {
                VolumeController.unmute(this).spokenResponse
            }

            // "max volume"
            command == "max volume" || command == "full volume" -> {
                VolumeController.setMaxVolume(this).spokenResponse
            }

            // "what's the volume" / "current volume"
            command.contains("what") && command.contains("volume") || command == "current volume" -> {
                VolumeController.getVolumeDescription(this).spokenResponse
            }

            // What time
            command.contains("what time") || command == "time" -> {
                val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                "It's $time"
            }

            // What date / day
            command.contains("what date") || command.contains("what day") || command == "date" -> {
                val date = SimpleDateFormat("dd MMMM yyyy, EEEE", Locale.getDefault()).format(Date())
                "Today is $date"
            }

            // ── Media transport controls ──
            // "pause music" / "pause" / "resume" / "play" / "play music"
            command == "pause music" || command == "pause" -> {
                mediaSessionHelper?.pause()
                if (mediaSessionHelper?.hasActiveSession() == true) "Paused" else "No music is playing"
            }
            command == "play music" || command == "resume music" || command == "resume" || command == "play" -> {
                if (mediaSessionHelper?.hasActiveSession() == true) {
                    mediaSessionHelper?.play()
                    "Playing"
                } else {
                    // No active session — open default music app
                    val launchIntent = packageManager.getLaunchIntentForPackage("com.google.android.music")
                        ?: packageManager.getLaunchIntentForPackage("com.spotify.music")
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launchIntent)
                        "Opening music"
                    } else {
                        "No music app found"
                    }
                }
            }
            command == "next song" || command == "next track" || command == "skip" -> {
                mediaSessionHelper?.next()
                if (mediaSessionHelper?.hasActiveSession() == true) "Next track" else "No music is playing"
            }
            command == "previous song" || command == "previous track" || command == "previous" -> {
                mediaSessionHelper?.previous()
                if (mediaSessionHelper?.hasActiveSession() == true) "Previous track" else "No music is playing"
            }
            command == "what's playing" || command == "what song is this" || command == "what's this song" -> {
                val state = mediaSessionHelper?.getCurrentState()
                if (state != null && state.hasActiveSession) {
                    "${state.title} by ${state.artist}"
                } else {
                    "No music is currently playing"
                }
            }

            // Greeting responses (actual greetings)
            command == "hello" || command == "hi" || command == "hey" -> {
                "Hello! What can I do for you?"
            }

            // How are you
            command.contains("how are you") -> {
                "I'm fully operational and ready to help."
            }

            // Thank you
            command.contains("thank") -> {
                "You're welcome."
            }

            // Help
            command == "help" || command == "what can you do" -> {
                "I can open apps, make calls by name, redial, search the web, set alarms and timers, " +
                "control volume, and tell you the time. Try saying: call mom, call mummy, redial, or open WhatsApp."
            }

            // Send SMS — "send message to <number>: <message>"
            command.startsWith("send message") || command.startsWith("send sms") -> {
                sendSMS(command)
            }

            // Send WhatsApp message — "send whatsapp to <name>: <message>"
            command.startsWith("send whatsapp") -> {
                sendWhatsAppMessage(command)
            }

            // Gemini AI — any question that doesn't match a command
            // Falls through to Gemini for intelligent conversational responses
            else -> {
                askGemini(command)
            }
        }

        Log.i(TAG, "Command result: $response")

        // Skip speaking / lock screen update if response is empty (Gemini handles its own TTS)
        if (response.isNotEmpty()) {
            updateNotification("Last: $response")
            speak(response)
            updateLockScreen(response, "Back to listening...")
            // Send complete state with command + result to lock screen display
            sendCommandDisplayUpdate("complete", text, response)
        }

        // Return to idle phase after executing the command
        currentPhase = Phase.IDLE_LISTENING
        if (response.isNotEmpty()) {
            updateNotification("Say \"Raghv\" to activate")
        }

        // Dismiss the lock screen overlay after a short delay (let user see the result)
        // Skip for Gemini responses — askGemini handles its own dismiss
        if (response.isNotEmpty()) {
            mainHandler.postDelayed({
                dismissLockScreen()
            }, 3000L)
        }

        // Schedule next listening cycle after TTS finishes
        mainHandler.postDelayed({
            if (shouldRestart) {
                restartListening()
            }
        }, POST_COMMAND_DELAY)
    }

    // ============================================================
    // Command Timeout — if no command spoken within COMMAND_TIMEOUT
    // ============================================================

    private fun startCommandTimeout() {
        cancelCommandTimeout()
        commandTimeoutRunnable = Runnable {
            if (currentPhase == Phase.COMMAND_MODE) {
                Log.i(TAG, "Command timeout — returning to IDLE_LISTENING")
                currentPhase = Phase.IDLE_LISTENING
                updateNotification("Say \"Raghv\" to activate")
                speak("I didn't hear anything. Say my name when you need me.")
                dismissLockScreen()
            }
        }
        mainHandler.postDelayed(commandTimeoutRunnable!!, COMMAND_TIMEOUT)
    }

    private fun cancelCommandTimeout() {
        commandTimeoutRunnable?.let {
            mainHandler.removeCallbacks(it)
            commandTimeoutRunnable = null
        }
    }

    // ============================================================
    // Lock Screen Integration — launch / update / dismiss overlay
    // ============================================================

    /**
     * Launch the LockScreenActivity over the lock screen.
     * This turns the screen on and shows the assistant UI.
     */
    private fun launchLockScreen(status: String, subtitle: String) {
        try {
            val intent = LockScreenActivity.createIntent(this)
            startActivity(intent)
            // Send initial status after a brief delay (let activity start)
            mainHandler.postDelayed({
                sendLockScreenBroadcast(status, subtitle, false)
            }, 200L)
            Log.i(TAG, "LockScreenActivity launched")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch LockScreenActivity", e)
        }
    }

    /**
     * Update the lock screen overlay with new status text.
     */
    private fun updateLockScreen(status: String, subtitle: String) {
        sendLockScreenBroadcast(status, subtitle, false)
    }

    /**
     * Dismiss the lock screen overlay.
     */
    private fun dismissLockScreen() {
        sendLockScreenBroadcast("", "", true)
        Log.i(TAG, "LockScreen dismiss requested")
    }

    /**
     * Send a broadcast to the LockScreenActivity to update its UI.
     * Now includes command display state + text for CommandDisplayView.
     */
    private fun sendLockScreenBroadcast(status: String, subtitle: String, dismiss: Boolean) {
        val intent = Intent(LockScreenActivity.ACTION_LOCK_SCREEN_UPDATE).apply {
            setPackage(packageName)
            putExtra("status", status)
            putExtra("subtitle", subtitle)
            putExtra("dismiss", dismiss)
        }
        sendBroadcast(intent)
    }

    /**
     * Send a command display update to the LockScreenActivity.
     * Drives the CommandDisplayView on the lock screen overlay.
     *
     * @param state   The display state: "listening", "recognized", "processing", "complete", "error", "idle"
     * @param command The recognized command text
     * @param result  The result/response text
     */
    private fun sendCommandDisplayUpdate(state: String, command: String, result: String) {
        val intent = Intent(LockScreenActivity.ACTION_COMMAND_DISPLAY_UPDATE).apply {
            setPackage(packageName)
            putExtra("state", state)
            putExtra("command", command)
            putExtra("result", result)
        }
        sendBroadcast(intent)
    }

    // ============================================================
    // Command Actions
    // ============================================================

    private fun openApp(appName: String): Boolean {
        val packageName = getPackageName(appName)
        return openAppByPackage(packageName)
    }

    /**
     * Launch an app by its package name directly.
     * Used by index-based voice shortcuts for instant launching.
     * Falls back to Play Store if the app is not installed.
     *
     * @return true if the app was launched, false otherwise
     */
    private fun openAppByPackage(packageName: String): Boolean {
        if (packageName.isEmpty()) return false
        return try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                Log.i(TAG, "★ Launched app: $packageName")
                true
            } else {
                // App not installed — try Play Store
                val playStoreIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("market://details?id=$packageName")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(playStoreIntent)
                Log.w(TAG, "App not installed, opening Play Store: $packageName")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch app: $packageName", e)
            false
        }
    }

    private fun initiateCall(name: String) {
        // Delegated to CallHelper — kept for backward compatibility
        CallHelper.call(this, name)
    }

    private fun searchWeb(query: String) {
        try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(browserIntent)
        }
    }

    private fun setAlarm(command: String): String {
        val timeRegex = Regex("(\\d{1,2})[:\\s](\\d{2})")
        val match = timeRegex.find(command)
        return if (match != null) {
            val hour = match.groupValues[1].toInt()
            val minute = match.groupValues[2].toInt()
            val isPM = command.contains("pm")
            val isAM = command.contains("am")
            val adjustedHour = when {
                isPM && hour < 12 -> hour + 12
                isAM && hour == 12 -> 0
                else -> hour
            }
            try {
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, adjustedHour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Voice Assistant Alarm")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                "Alarm set for %02d:%02d".format(adjustedHour, minute)
            } catch (e: Exception) {
                "Could not set alarm"
            }
        } else {
            "Could not understand the alarm time"
        }
    }

    private fun setTimer(command: String): String {
        val secondsRegex = Regex("(\\d+)\\s*seconds?")
        val minutesRegex = Regex("(\\d+)\\s*minutes?")
        val totalSeconds = when {
            secondsRegex.containsMatchIn(command) ->
                secondsRegex.find(command)!!.groupValues[1].toInt()
            minutesRegex.containsMatchIn(command) ->
                minutesRegex.find(command)!!.groupValues[1].toInt() * 60
            else -> 0
        }
        return if (totalSeconds > 0) {
            try {
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, totalSeconds)
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Voice Assistant Timer")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                "Timer set for $totalSeconds seconds"
            } catch (e: Exception) {
                "Could not set timer"
            }
        } else {
            "Could not understand timer duration"
        }
    }

    // ============================================================
    // SMS & WhatsApp
    // ============================================================

    /**
     * Send an SMS message.
     * Supports: "send message to 9876543210 hello there"
     *           "send sms to 9876543210 saying hello there"
     */
    private fun sendSMS(command: String): String {
        // Extract phone number and message from the command
        // Pattern: "send message to <number> <message>" or "send sms to <number> saying <message>"
        val cleaned = command
            .replace("send message to ", "")
            .replace("send sms to ", "")
            .replace("send message ", "")
            .replace("send sms ", "")
            .replace("saying ", "")
            .trim()

        // Find the phone number (10 digits, or with +91)
        val phoneRegex = Regex("(\\+?\\d{10,13})")
        val match = phoneRegex.find(cleaned)

        return if (match != null) {
            val phoneNumber = match.value
            val message = cleaned.substring(match.range.last + 1).trim()

            if (message.isNotEmpty()) {
                try {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("smsto:$phoneNumber")
                        putExtra("sms_body", message)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    "Opening SMS to $phoneNumber with your message."
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to send SMS", e)
                    "Could not open SMS. You may need to grant SMS permission."
                }
            } else {
                "What message should I send to $phoneNumber?"
            }
        } else {
            "Please say the phone number. For example: send message to 9876543210 hello there"
        }
    }

    /**
     * Send a WhatsApp message.
     * Supports: "send whatsapp to <name> hello there"
     */
    private fun sendWhatsAppMessage(command: String): String {
        val cleaned = command
            .replace("send whatsapp to ", "")
            .replace("send whatsapp ", "")
            .trim()

        // Try to extract a name or number
        val parts = cleaned.split(" ", limit = 2)
        val recipient = parts.firstOrNull() ?: ""
        val message = parts.getOrNull(1) ?: ""

        return if (recipient.isNotEmpty()) {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    setPackage("com.whatsapp")
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                "Opening WhatsApp to send your message."
            } catch (e: Exception) {
                Log.e(TAG, "WhatsApp not available", e)
                "WhatsApp is not installed on this device."
            }
        } else {
            "Who should I send the WhatsApp message to?"
        }
    }

    // ============================================================
    // Gemini AI Integration
    // ============================================================

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /**
     * Execute a custom command mapped by the user.
     * Handles all action types: open app, open URL, dial, search, alarm, flashlight, etc.
     *
     * @param cmd The matched CustomCommand
     * @return A spoken response string for TTS
     */
    private fun executeCustomCommand(cmd: CustomCommand): String {
        return try {
            when (cmd.actionType) {
                CustomCommand.ActionType.OPEN_APP -> {
                    val intent = packageManager.getLaunchIntentForPackage(cmd.actionPayload)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                        "Opening ${cmd.displayName}"
                    } else {
                        "App not found: ${cmd.actionPayload}"
                    }
                }

                CustomCommand.ActionType.OPEN_URL -> {
                    val url = if (cmd.actionPayload.startsWith("http")) cmd.actionPayload else "https://${cmd.actionPayload}"
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    "Opening ${cmd.displayName}"
                }

                CustomCommand.ActionType.DIAL_NUMBER -> {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = android.net.Uri.parse("tel:${cmd.actionPayload}")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    "Calling ${cmd.actionPayload}"
                }

                CustomCommand.ActionType.WEB_SEARCH -> {
                    val query = java.net.URLEncoder.encode(cmd.actionPayload, "UTF-8")
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=$query")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    "Searching for ${cmd.actionPayload}"
                }

                CustomCommand.ActionType.SET_ALARM -> {
                    val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, cmd.displayName)
                        putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                        // Parse "HH:MM" format
                        val parts = cmd.actionPayload.split(":")
                        if (parts.size == 2) {
                            putExtra(android.provider.AlarmClock.EXTRA_HOUR, parts[0].toInt())
                            putExtra(android.provider.AlarmClock.EXTRA_MINUTES, parts[1].toInt())
                        }
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    "Setting alarm for ${cmd.actionPayload}"
                }

                CustomCommand.ActionType.TOGGLE_FLASHLIGHT -> {
                    // Use the camera manager to toggle torch
                    val cameraManager = getSystemService(android.content.Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
                    val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                        cameraManager.getCameraCharacteristics(id)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    }
                    if (cameraId != null) {
                        flashlightState = !flashlightState
                        cameraManager.setTorchMode(cameraId, flashlightState)
                        if (flashlightState) "Flashlight on" else "Flashlight off"
                    } else {
                        "No flashlight available"
                    }
                }

                CustomCommand.ActionType.PLAY_MUSIC -> {
                    val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                        putExtra(SearchManager.QUERY, cmd.actionPayload.ifEmpty { "" })
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(packageManager) != null) {
                        startActivity(intent)
                        "Playing music"
                    } else {
                        // Fallback: open default music app
                        val launchIntent = packageManager.getLaunchIntentForPackage("com.google.android.music")
                            ?: packageManager.getLaunchIntentForPackage("com.spotify.music")
                        if (launchIntent != null) {
                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launchIntent)
                            "Opening music"
                        } else {
                            "No music app found"
                        }
                    }
                }

                CustomCommand.ActionType.COPY_TEXT -> {
                    val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    val clip = android.content.ClipData.newPlainText(cmd.displayName, cmd.actionPayload)
                    clipboard.setPrimaryClip(clip)
                    "Copied to clipboard"
                }

                CustomCommand.ActionType.CUSTOM_RESPONSE -> {
                    cmd.actionPayload
                }

                else -> "Unknown action"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing custom command: ${cmd.triggerPhrase}", e)
            "Error executing ${cmd.displayName}"
        }
    }

    /** Flashlight state tracker for toggle */
    private var flashlightState = false

    /**
     * Lock the device screen.
     *
     * Uses DevicePolicyManager.lockNow() if the app has device admin privileges.
     * Otherwise, falls back to closing the app and going to the home screen,
     * which at least minimises the app. For true device locking, the user
     * needs to enable device admin for the app.
     */
    private fun lockScreen(): String {
        return try {
            val dpm = getSystemService(android.content.Context.DEVICE_POLICY_SERVICE)
                as android.app.admin.DevicePolicyManager

            // Check if we have device admin privileges
            val componentName = android.content.ComponentName(this, LockScreenAdminReceiver::class.java)
            val isAdminActive = dpm.isAdminActive(componentName)

            if (isAdminActive) {
                dpm.lockNow()
                Log.i(TAG, "★ Screen locked via DevicePolicyManager")
                "Locking screen"
            } else {
                // No device admin — try the accessibility approach or just go home
                Log.w(TAG, "Device admin not active — cannot lock screen programmatically")
                // Go to home screen as a fallback
                val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(homeIntent)
                "To lock the screen, please enable device admin in settings"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to lock screen", e)
            "I couldn't lock the screen"
        }
    }

    /**
     * Toggle the flashlight on or off.
     *
     * @param turnOn True to turn on, false to turn off
     */
    private fun toggleFlashlight(turnOn: Boolean): String {
        return try {
            val cameraManager = getSystemService(android.content.Context.CAMERA_SERVICE)
                as android.hardware.camera2.CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId != null) {
                flashlightState = turnOn
                cameraManager.setTorchMode(cameraId, turnOn)
                Log.i(TAG, "★ Flashlight ${if (turnOn) "ON" else "OFF"}")
                if (turnOn) "Flashlight on" else "Flashlight off"
            } else {
                "No flashlight available"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle flashlight", e)
            "I couldn't toggle the flashlight"
        }
    }

    /**
     * Send the user's query to Gemini AI for an intelligent response.
     * If the API key is not configured, falls back to a helpful message.
     */
    private fun askGemini(query: String): String {
        if (!GeminiApiHelper.isConfigured()) {
            // API key not set — return a fallback response
            val fallback = "I heard: $query. To enable intelligent responses, " +
                    "add your Gemini API key in GeminiApiHelper.kt. " +
                    "Get a free key at aistudio.google.com/apikey"
            Log.w(TAG, "Gemini not configured — using fallback")
            return fallback
        }

        // Show a "thinking" status while querying Gemini
        updateLockScreen("Thinking...", "Querying AI...")
        sendCommandDisplayUpdate("processing", query, "")
        speak("Let me think...")

        // Launch async Gemini API call
        serviceScope.launch {
            val geminiResponse = GeminiApiHelper.ask(query)

            val response = geminiResponse ?: "I couldn't reach the AI service right now. Please try again."

            Log.i(TAG, "Gemini response: $response")
            updateLockScreen(response, "AI response")
            updateNotification("AI: $response")
            sendCommandDisplayUpdate("complete", query, response)
            speak(response)

            // Dismiss lock screen after response
            mainHandler.postDelayed({
                dismissLockScreen()
            }, 3000L)
        }

        // Return empty string — the actual response will be spoken when the
        // coroutine completes. The main handleCommandPhase flow will NOT
        // speak this return value since it's empty.
        return ""
    }

    // ============================================================
    // App Package Name Mapper
    // ============================================================

    private fun getPackageName(appName: String): String {
        return when (appName.lowercase().trim()) {
            // Social
            "whatsapp" -> "com.whatsapp"
            "telegram" -> "org.telegram.messenger"
            "instagram" -> "com.instagram.android"
            "facebook" -> "com.facebook.katana"
            "twitter", "x" -> "com.twitter.android"
            "snapchat" -> "com.snapchat.android"
            "linkedin" -> "com.linkedin.android"
            "reddit" -> "com.reddit.frontpage"
            "discord" -> "com.discord"
            "threads" -> "com.instagram.bar"
            // Google apps
            "youtube" -> "com.google.android.youtube"
            "youtube music" -> "com.google.android.apps.youtube.music"
            "maps", "google maps" -> "com.google.android.apps.maps"
            "gmail" -> "com.google.android.gm"
            "chrome" -> "com.android.chrome"
            "drive" -> "com.google.android.apps.docs"
            "photos" -> "com.google.android.apps.photos"
            "translate" -> "com.google.android.apps.translate"
            "news" -> "com.google.android.apps.magazines"
            "music" -> "com.google.android.music"
            "play store", "playstore" -> "com.android.vending"
            "google" -> "com.google.android.googlequicksearchbox"
            // Streaming
            "netflix" -> "com.netflix.mediaclient"
            "hotstar", "disney hotstar" -> "in.startv.hotstar"
            "prime video", "amazon prime" -> "com.amazon.avod.thirdpartyclient"
            "spotify" -> "com.spotify.music"
            "mx player" -> "com.mxtech.videoplayer.ad"
            "vlc" -> "org.videolan.vlc"
            "jio cinema" -> "com.jio.media.stb"
            "sony liv" -> "com.sonyliv"
            // Shopping
            "amazon" -> "in.amazon.mShop.android.shopping"
            "flipkart" -> "com.flipkart.android"
            "myntra" -> "com.myntra.android"
            "meesho" -> "com.meesho.app"
            "ajio" -> "com.ril.ajio"
            "tata cliq" -> "com.tata.cliq"
            // Food delivery
            "swiggy" -> "in.swiggy.android"
            "zomato" -> "com.application.zomato"
            "zepto" -> "application.zepto"
            "blinkit" -> "com.grofers.customerapp"
            // Payments
            "paytm" -> "net.one97.paytm"
            "phonepe" -> "com.phonepe.app"
            "gpay", "google pay" -> "com.google.android.apps.nbu.paisa.user"
            "bhim" -> "in.org.npci.upiapp"
            "amazon pay" -> "com.amazon.mShop.android.shopping"
            // System
            "settings" -> "com.android.settings"
            "phone", "dialer" -> "com.google.android.dialer"
            "messages", "sms" -> "com.google.android.apps.messaging"
            "camera" -> "com.android.camera"
            "calculator" -> "com.android.calculator2"
            "calendar" -> "com.google.android.calendar"
            "clock" -> "com.google.android.deskclock"
            "files" -> "com.google.android.documentsui"
            "contacts" -> "com.google.android.contacts"
            "gallery" -> "com.android.gallery3d"
            "notes" -> "com.google.android.keep"
            "weather" -> "com.google.android.apps.weather"
            // Productivity
            "notion" -> "notion.id"
            "evernote" -> "com.evernote"
            "microsoft word" -> "com.microsoft.office.word"
            "excel" -> "com.microsoft.office.excel"
            "powerpoint" -> "com.microsoft.office.powerpoint"
            "teams" -> "com.microsoft.teams"
            "zoom" -> "us.zoom.videomeetings"
            "gmail" -> "com.google.android.gm"
            // Travel
            "uber" -> "com.ubercab"
            "ola" -> "com.olacabs.customer"
            "rapido" -> "com.rapido.passenger"
            "irctc" -> "cris.org.in.prs.ima"
            "makemytrip" -> "com.makemytrip"
            "goibibo" -> "com.goibibo"
            // Utility
            "truecaller" -> "com.truecaller"
            "sharechat" -> "in.mohalla"
            "dating" -> "com.tinder"
            else -> appName.replace(" ", "")
        }
    }

    // ============================================================
    // Text-to-Speech
    // ============================================================

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            isTtsReady = true
            Log.i(TAG, "TTS initialized — ready to speak")
        } else {
            Log.e(TAG, "TTS initialization failed")
        }
    }

    private fun speak(text: String) {
        if (isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tts_response")
        }
    }

    // ============================================================
    // Notification
    // ============================================================

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Voice Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Jarvis-style voice assistant — always listening for wake word"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, VoiceAssistantService::class.java).apply {
            action = "STOP_SERVICE"
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return androidx.core.app.NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Voice Assistant Active")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    // ============================================================
    // Service lifecycle
    // ============================================================

    override fun onDestroy() {
        super.onDestroy()
        shouldRestart = false
        isListening = false
        cancelCommandTimeout()
        dismissLockScreen()
        // Clean up hotword detector
        hotwordDetector?.destroy()
        hotwordDetector = null
        // Clean up offline command recognizer
        stopOfflineCommandRecognizer()
        // Clean up media session helper
        mediaSessionHelper?.stop()
        mediaSessionHelper = null
        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        // Release the wake lock so the CPU can sleep again
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
                Log.i(TAG, "WakeLock released")
            }
        }
        wakeLock = null
        Log.i(TAG, "Service destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private val mainHandler = Handler(Looper.getMainLooper())

        /** Broadcast action for media state updates (sent to lock screen + main activity) */
        const val ACTION_MEDIA_UPDATE = "com.aiassistant.voicest.MEDIA_UPDATE"

        fun start(context: Context) {
            val intent = Intent(context, VoiceAssistantService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, VoiceAssistantService::class.java)
            context.stopService(intent)
        }
    }
}
