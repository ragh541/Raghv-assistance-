package com.aiassistant.voicest

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.util.Log

/**
 * MediaSessionHelper — Detects active media sessions and provides
 * metadata + transport controls to the UI.
 *
 * Uses Android's MediaSessionManager (API 21+) to:
 *   1. Detect when music/audio is playing (Spotify, YouTube Music, etc.)
 *   2. Get the current track's title, artist, and album art
 *   3. Get the playback state (playing / paused)
 *   4. Send transport commands (play, pause, next, previous)
 *
 * The helper registers a MediaSessionManager.OnActiveSessionsChangedListener
 * to get notified when new media sessions appear or disappear. It then
 * registers a MediaController.Callback on the active session to receive
 * real-time updates when the track changes or playback state changes.
 *
 * USAGE:
 *   val helper = MediaSessionHelper(context)
 *   helper.setListener(object : MediaSessionHelper.Listener {
 *       override fun onMediaStateChanged(state: MediaSessionHelper.MediaState) {
 *           // Update ContextualCardView with new info
 *       }
 *   })
 *   helper.start()
 *   // ... later
 *   helper.pause()   // pause playback
 *   helper.play()    // resume playback
 *   helper.next()    // skip to next track
 *   helper.previous() // previous track
 *   helper.stop()    // unregister listeners
 *
 * NOTE: Requires android.permission.MEDIA_CONTENT_CONTROL or a notification
 * listener service to access media sessions on Android 5.0+. In practice,
 * the notification listener permission is automatically granted if the app
 * has notification access enabled (which we already request for the
 * foreground service notification).
 *
 * Alternatively, we use a NotificationListenerService component to get
 * access to media sessions without needing special permissions.
 */
class MediaSessionHelper(private val context: Context) {

    private val TAG = "MediaSessionHelper"

    private var mediaSessionManager: MediaSessionManager? = null
    private var activeController: MediaController? = null
    private var sessionListener: MediaSessionManager.OnActiveSessionsChangedListener? = null
    private var controllerCallback: MediaController.Callback? = null
    private var listener: Listener? = null

    /**
     * MediaState — data class representing the current media state.
     */
    data class MediaState(
        val title: String,
        val artist: String,
        val albumArt: Bitmap?,
        val isPlaying: Boolean,
        val packageName: String,
        val hasActiveSession: Boolean
    )

    /**
     * Empty media state — when no media is active.
     */
    val emptyState = MediaState(
        title = "", artist = "", albumArt = null,
        isPlaying = false, packageName = "", hasActiveSession = false
    )

    /**
     * Listener for media state changes.
     */
    interface Listener {
        /**
         * Called when the media state changes (track change, play/pause, etc.)
         */
        fun onMediaStateChanged(state: MediaState)

        /**
         * Called when no media session is active (card should hide).
         */
        fun onNoMediaSession() {}
    }

    /**
     * Set the listener for media state updates.
     */
    fun setListener(listener: Listener) {
        this.listener = listener
    }

    /**
     * Start monitoring media sessions.
     *
     * Registers a session change listener that fires whenever a new media
     * session appears or an existing one disappears. On each change, it
     * picks the most relevant active session and registers a callback.
     */
    fun start() {
        try {
            mediaSessionManager = context.getSystemService(Context.MEDIA_SESSION_SERVICE)
                    as MediaSessionManager

            // The component name for our notification listener (required for access)
            val component = ComponentName(context, MediaNotificationListener::class.java)

            sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
                Log.d(TAG, "Active sessions changed: ${controllers.size} sessions")
                handleSessionsChanged(controllers)
            }

            // Register the listener — this also triggers the first callback
            mediaSessionManager?.addOnActiveSessionsChangedListener(
                sessionListener!!,
                component
            )

            // Get initial sessions
            val controllers = try {
                mediaSessionManager?.getActiveSessions(component) ?: emptyList()
            } catch (e: SecurityException) {
                Log.w(TAG, "SecurityException getting active sessions — notification listener not enabled?", e)
                // Try without component — may work on some devices
                try {
                    mediaSessionManager?.getActiveSessions(null) ?: emptyList()
                } catch (e2: Exception) {
                    emptyList()
                }
            }
            handleSessionsChanged(controllers)

            Log.i(TAG, "MediaSessionHelper started")

        } catch (e: SecurityException) {
            Log.e(TAG, "No permission to access media sessions. " +
                "Enable notification access for this app.", e)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start MediaSessionHelper", e)
        }
    }

    /**
     * Handle a change in active media sessions.
     * Picks the best session (preferably one that is playing) and
     * registers a callback for real-time updates.
     */
    private fun handleSessionsChanged(controllers: List<MediaController>) {
        // Remove callback from the previous controller
        unregisterControllerCallback()

        if (controllers.isEmpty()) {
            Log.d(TAG, "No active media sessions")
            activeController = null
            listener?.onNoMediaSession()
            return
        }

        // Pick the best session:
        // 1. Prefer a session that is currently playing
        // 2. Otherwise, take the last session (most recently active)
        val playingController = controllers.firstOrNull { controller ->
            val state = controller.playbackState
            state != null && state.state == PlaybackState.STATE_PLAYING
        }

        activeController = playingController ?: controllers.lastOrNull()

        // Register callback for real-time updates
        registerControllerCallback(activeController!!)

        // Immediately report the current state
        reportMediaState(activeController!!)
    }

    /**
     * Register a MediaController.Callback on the active controller.
     */
    private fun registerControllerCallback(controller: MediaController) {
        controllerCallback = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                Log.d(TAG, "Playback state changed: ${state?.state}")
                reportMediaState(controller)
            }

            override fun onMetadataChanged(metadata: MediaMetadata?) {
                Log.d(TAG, "Metadata changed")
                reportMediaState(controller)
            }

            override fun onSessionDestroyed() {
                Log.d(TAG, "Media session destroyed")
                unregisterControllerCallback()
                activeController = null
                listener?.onNoMediaSession()
            }
        }
        controller.registerCallback(controllerCallback!!)
    }

    /**
     * Unregister the current controller callback.
     */
    private fun unregisterControllerCallback() {
        controllerCallback?.let { cb ->
            activeController?.unregisterCallback(cb)
        }
        controllerCallback = null
    }

    /**
     * Extract media state from a MediaController and report to listener.
     */
    private fun reportMediaState(controller: MediaController) {
        val metadata = controller.metadata
        val playbackState = controller.playbackState

        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown track"
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: "Unknown artist"
        val albumArt = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        val isPlaying = playbackState?.state == PlaybackState.STATE_PLAYING
        val pkg = controller.packageName

        val state = MediaState(
            title = title,
            artist = artist,
            albumArt = albumArt,
            isPlaying = isPlaying,
            packageName = pkg,
            hasActiveSession = true
        )

        Log.d(TAG, "Media state: \"$title\" by \"$artist\" (playing=$isPlaying, pkg=$pkg)")
        listener?.onMediaStateChanged(state)
    }

    // ============================================================
    // Transport Controls
    // ============================================================

    /**
     * Get the transport controls from the active controller.
     */
    private fun getTransportControls(): MediaController.TransportControls? {
        return activeController?.transportControls
    }

    /**
     * Toggle play/pause. If playing, pauses; if paused, plays.
     */
    fun togglePlayPause() {
        val state = activeController?.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) {
            pause()
        } else {
            play()
        }
    }

    /**
     * Play / resume playback.
     */
    fun play() {
        Log.i(TAG, "★ Transport: PLAY")
        getTransportControls()?.play()
    }

    /**
     * Pause playback.
     */
    fun pause() {
        Log.i(TAG, "★ Transport: PAUSE")
        getTransportControls()?.pause()
    }

    /**
     * Skip to next track.
     */
    fun next() {
        Log.i(TAG, "★ Transport: NEXT")
        getTransportControls()?.skipToNext()
    }

    /**
     * Skip to previous track.
     */
    fun previous() {
        Log.i(TAG, "★ Transport: PREVIOUS")
        getTransportControls()?.skipToPrevious()
    }

    /**
     * Stop playback.
     */
    fun stop() {
        Log.i(TAG, "★ Transport: STOP")
        getTransportControls()?.stop()
    }

    /**
     * Check if there's an active media session.
     */
    fun hasActiveSession(): Boolean = activeController != null

    /**
     * Check if media is currently playing.
     */
    fun isPlaying(): Boolean {
        return activeController?.playbackState?.state == PlaybackState.STATE_PLAYING
    }

    /**
     * Get the current media state.
     */
    fun getCurrentState(): MediaState {
        val controller = activeController ?: return emptyState
        val metadata = controller.metadata
        val playbackState = controller.playbackState

        return MediaState(
            title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
            artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            albumArt = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART),
            isPlaying = playbackState?.state == PlaybackState.STATE_PLAYING,
            packageName = controller.packageName,
            hasActiveSession = true
        )
    }

    /**
     * Stop monitoring and release all resources.
     */
    fun stop() {
        unregisterControllerCallback()
        sessionListener?.let {
            mediaSessionManager?.removeOnActiveSessionsChangedListener(it)
        }
        sessionListener = null
        activeController = null
        Log.i(TAG, "MediaSessionHelper stopped")
    }
}
