package com.aiassistant.voicest

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * LockScreenAdminReceiver — Device Admin Receiver for programmatic screen locking.
 *
 * To lock the device screen programmatically (via DevicePolicyManager.lockNow()),
 * Android requires the app to be registered as a Device Admin. This receiver
 * is the entry point for that privilege.
 *
 * HOW TO ENABLE:
 * The user needs to activate device admin for the app. This can be done
 * programmatically by launching the device admin settings:
 *
 *   val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
 *   intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
 *   startActivity(intent)
 *
 * Once enabled, the "lock screen" voice command will use DevicePolicyManager
 * to instantly lock the device — no physical button press needed.
 *
 * If device admin is NOT enabled, the "lock screen" command falls back to
 * going to the home screen and informs the user.
 */
class LockScreenAdminReceiver : DeviceAdminReceiver() {

    private val TAG = "LockScreenAdminReceiver"

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.i(TAG, "★ Device Admin enabled — screen locking is now available")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w(TAG, "Device Admin disabled — screen locking will fall back to home screen")
    }

    override fun onLockTaskModeEntering(context: Context, intent: Intent, pkg: String) {
        super.onLockTaskModeEntering(context, intent, pkg)
    }

    override fun onLockTaskModeExiting(context: Context, intent: Intent) {
        super.onLockTaskModeExiting(context, intent)
    }
}
