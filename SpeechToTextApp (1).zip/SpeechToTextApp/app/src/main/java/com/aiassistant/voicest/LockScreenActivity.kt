package com.aiassistant.voicest

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * LockScreenActivity — Shows over the lock screen when the wake word is detected.
 *
 * This activity:
 * - Displays OVER the lock screen (showWhenLocked + turnScreenOn)
 * - Wakes up the screen and turns it on
 * - Shows the waveform animation and status text
 * - Receives broadcasts from VoiceAssistantService to update UI in real-time:
 *     - ACTION_STATUS_UPDATE   → update status text
 *     - ACTION_DISMISS         → auto-dismiss the activity
 * - Can be dismissed by tapping the "Dismiss" button
 *
 * Broadcast protocol (sent by VoiceAssistantService):
 *   Intent action = "com.aiassistant.voicest.LOCK_SCREEN_UPDATE"
 *   extras:
 *     "status"   (String)  — text to show in tvLockStatus
 *     "subtitle" (String)  — text to show in tvLockSubtitle
 *     "dismiss"  (Boolean) — if true, finish() the activity
 */
class LockScreenActivity : AppCompatActivity() {

    private val TAG = "LockScreenActivity"

    private lateinit var tvStatus: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var waveform: WaveformView
    private lateinit var btnDismiss: MaterialButton
    private lateinit var commandDisplay: CommandDisplayView
    private lateinit var contextualCard: ContextualCardView
    private var mediaSessionHelper: MediaSessionHelper? = null

    /**
     * BroadcastReceiver — receives status updates from VoiceAssistantService.
     */
    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val status = intent?.getStringExtra("status")
            val subtitle = intent?.getStringExtra("subtitle")
            val shouldDismiss = intent?.getBooleanExtra("dismiss", false) ?: false

            if (status != null) {
                tvStatus.text = status
            }
            if (subtitle != null) {
                tvSubtitle.text = subtitle
            }
            if (shouldDismiss) {
                Log.i(TAG, "Dismiss broadcast received — closing lock screen")
                finish()
            }
        }
    }

    /**
     * BroadcastReceiver — receives command display updates from VoiceAssistantService.
     * Drives the CommandDisplayView on the lock screen overlay.
     */
    private val commandDisplayReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra("state") ?: return
            val command = intent.getStringExtra("command") ?: ""
            val result = intent.getStringExtra("result") ?: ""

            Log.d(TAG, "Command display update: state=$state, command=$command, result=$result")

            when (state) {
                "listening" -> {
                    commandDisplay.setState(CommandDisplayView.State.LISTENING)
                }
                "recognized" -> {
                    commandDisplay.setCommand(command)
                    commandDisplay.setState(CommandDisplayView.State.RECOGNIZED)
                }
                "processing" -> {
                    commandDisplay.setCommand(command)
                    commandDisplay.setState(CommandDisplayView.State.PROCESSING)
                }
                "complete" -> {
                    commandDisplay.setCommand(command)
                    commandDisplay.setResult(result)
                    commandDisplay.setState(CommandDisplayView.State.COMPLETE)
                }
                "error" -> {
                    commandDisplay.setCommand(command)
                    commandDisplay.setResult(result)
                    commandDisplay.setState(CommandDisplayView.State.ERROR)
                }
                "idle" -> {
                    commandDisplay.setState(CommandDisplayView.State.IDLE)
                }
            }
        }
    }

    /**
     * BroadcastReceiver — receives media state updates from VoiceAssistantService.
     * Updates the ContextualCardView with track info and playback controls.
     */
    private val mediaUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val hasActiveSession = intent?.getBooleanExtra("hasActiveSession", false) ?: false

            if (hasActiveSession) {
                val title = intent?.getStringExtra("title") ?: "Unknown track"
                val artist = intent?.getStringExtra("artist") ?: "Unknown artist"
                val isPlaying = intent?.getBooleanExtra("isPlaying", false) ?: false

                Log.d(TAG, "♪ Media update: \"$title\" by \"$artist\" (playing=$isPlaying)")
                contextualCard.updateMediaInfo(title, artist, null, isPlaying)
            } else {
                Log.d(TAG, "♪ No active media — hiding contextual card")
                contextualCard.hide()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen + turn screen on
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        // Keep screen on while this activity is visible
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_lockscreen)

        tvStatus = findViewById(R.id.tvLockStatus)
        tvSubtitle = findViewById(R.id.tvLockSubtitle)
        waveform = findViewById(R.id.lockWaveform)
        btnDismiss = findViewById(R.id.btnDismiss)
        commandDisplay = findViewById(R.id.lockCommandDisplay)
        contextualCard = findViewById(R.id.lockContextualCard)

        // Set up media control buttons on the contextual card
        contextualCard.setMediaControlListener(object : ContextualCardView.MediaControlListener {
            override fun onPlayPause() {
                mediaSessionHelper?.togglePlayPause()
            }
            override fun onNext() {
                mediaSessionHelper?.next()
            }
            override fun onPrevious() {
                mediaSessionHelper?.previous()
            }
        })

        // Start waveform animation
        waveform.startListening()

        // Dismiss button — close the activity
        btnDismiss.setOnClickListener {
            Log.i(TAG, "Dismiss button tapped")
            finish()
        }

        // Request keyguard dismissal so the user doesn't have to unlock manually
        // after the assistant has completed the command
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val keyguardManager = getSystemService(KeyguardManager::class.java)
            keyguardManager?.requestDismissKeyguard(this, object :
                KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    Log.i(TAG, "Keyguard dismissed — screen unlocked")
                }

                override fun onDismissError() {
                    Log.w(TAG, "Keyguard dismiss error")
                }

                override fun onDismissCancelled() {
                    Log.w(TAG, "Keyguard dismiss cancelled")
                }
            })
        }

        Log.i(TAG, "LockScreenActivity created — showing over lock screen")
    }

    override fun onStart() {
        super.onStart()
        // Register broadcast receivers to get updates from the service
        val statusFilter = IntentFilter(ACTION_LOCK_SCREEN_UPDATE)
        val commandFilter = IntentFilter(ACTION_COMMAND_DISPLAY_UPDATE)
        val mediaFilter = IntentFilter(ACTION_MEDIA_UPDATE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(updateReceiver, statusFilter, Context.RECEIVER_NOT_EXPORTED)
            registerReceiver(commandDisplayReceiver, commandFilter, Context.RECEIVER_NOT_EXPORTED)
            registerReceiver(mediaUpdateReceiver, mediaFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(updateReceiver, statusFilter)
            registerReceiver(commandDisplayReceiver, commandFilter)
            registerReceiver(mediaUpdateReceiver, mediaFilter)
        }
    }

    override fun onStop() {
        super.onStop()
        waveform.stopListening()
        try {
            unregisterReceiver(updateReceiver)
            unregisterReceiver(commandDisplayReceiver)
            unregisterReceiver(mediaUpdateReceiver)
        } catch (e: Exception) {
            Log.w(TAG, "Receiver already unregistered", e)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "LockScreenActivity destroyed")
    }

    companion object {
        const val ACTION_LOCK_SCREEN_UPDATE = "com.aiassistant.voicest.LOCK_SCREEN_UPDATE"
        const val ACTION_COMMAND_DISPLAY_UPDATE = "com.aiassistant.voicest.COMMAND_DISPLAY_UPDATE"
        const val ACTION_MEDIA_UPDATE = "com.aiassistant.voicest.MEDIA_UPDATE"

        /**
         * Convenience method to create the launch intent.
         */
        fun createIntent(context: Context): Intent {
            return Intent(context, LockScreenActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
            }
        }
    }
}
