package com.aiassistant.voicest

import com.google.gson.annotations.SerializedName

/**
 * AppShortcut — Maps a custom voice keyword to a specific installed app.
 *
 * Index-based voice shortcuts let the user say a short keyword and have
 * the assistant immediately launch the corresponding app — no "open" prefix
 * needed. For example:
 *
 *   "instagram"   → launches com.instagram.android
 *   "pay"         → launches com.phonepe.app
 *   "mail"        → launches com.google.android.gm
 *   "messages"    → launches com.google.android.apps.messaging
 *
 * Shortcuts are checked BEFORE the "open <app>" built-in command, so
 * they act as fast-launch overrides. Shortcuts are also checked before
 * custom commands, so they take top priority for app launching.
 *
 * @param id Unique identifier (timestamp-based)
 * @param keyword The spoken keyword (e.g. "insta", "pay", "mail")
 * @param packageName The target app's package name (e.g. "com.instagram.android")
 * @param appLabel Human-readable app name (e.g. "Instagram")
 * @param enabled Whether this shortcut is active
 */
data class AppShortcut(
    @SerializedName("id")
    val id: Long,

    @SerializedName("keyword")
    val keyword: String,

    @SerializedName("packageName")
    val packageName: String,

    @SerializedName("appLabel")
    val appLabel: String,

    @SerializedName("enabled")
    var enabled: Boolean = true
) {
    companion object {
        fun generateId(): Long = System.currentTimeMillis()
    }
}
