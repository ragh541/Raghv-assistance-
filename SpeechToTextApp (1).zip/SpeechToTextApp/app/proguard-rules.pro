# ProGuard rules for Voice Assistant
# Keep Vosk native library classes
-keep class org.vosk.** { *; }
-keep class com.alphacephei.** { *; }

# Keep Retrofit/Gson model classes
-keep class com.aiassistant.voicest.GeminiApiHelper$* { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class retrofit2.** { *; }

# Keep data classes
-keep class com.aiassistant.voicest.CustomCommand { *; }
