# 🎙️ Voice Assistant — APK Build Guide

## Kya theek kiya gaya (v18)

Build fail hone ke 3 asli kaaran the — teeno fix ho gaye:

| # | Problem | Fix |
|---|---|---|
| 1 | **Root `build.gradle` missing tha** → Gradle ko plugin versions nahi milte, error: `Plugin [id: 'com.android.application'] was not found` | `build.gradle` add kiya (AGP 8.2.2 + Kotlin 1.9.22) |
| 2 | **Launcher icon missing tha** (`res/mipmap/` folder hi nahi tha) → AAPT error: `resource mipmap/ic_launcher not found` | Saare densities ke PNG icons + adaptive icon banaye |
| 3 | **Layouts mein unescaped quotes** (`android:text="Say "Raghv" to wake..."`) → XML parse error | `&quot;` se replace kiya, saare XML ab well-formed |

Saath hi `@color/card_bg` / `@color/bg_dark` jaise missing colors bhi fix kiye.

---

## Tarika 1 — Android Studio (sabse aasan agar PC hai)

**Zaroorat:** 8GB RAM, 8GB free disk, internet

1. Android Studio install karo — https://developer.android.com/studio
2. **File > Open** → `SpeechToTextApp` folder select karo
3. Gradle sync khud chalega (2–5 min, pehli baar dependencies download hongi)
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. APK yahan milega:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```
6. Us APK ko phone mein bhejo (USB / Drive / WhatsApp) aur install karo

**Release APK (share karne ke liye):**
**Build > Generate Signed Bundle / APK > APK > Create new keystore** → details bharo → `release` choose karo → Finish

---

## Tarika 2 — GitHub Actions (Android Studio ki zaroorat NAHI)

Ye tareeka best hai agar PC kamzor hai ya Android Studio install nahi karna. APK GitHub ke free server par banega.

1. https://github.com par free account banao
2. **New repository** banao (naam: `voice-assistant`, Private ya Public — dono chalega)
3. Us repo mein **"uploading an existing file"** link se poora `SpeechToTextApp` folder ka content upload karo
   - **Zaroori:** `.github` folder bhi upload hona chahiye (hidden folder hai — file manager mein "show hidden files" on karo)
   - Aasan tareeka: GitHub Desktop app se folder add karke push kar do
4. Repo ke **Actions** tab par jao
5. Left sidebar mein **"Build APK"** select karo → **"Run workflow"** button dabao
6. ~5 minute wait karo
7. Run complete hone par us run ke page ke neeche **Artifacts** section se **`SpeechToTextApp-debug-apk`** download karo
8. Zip extract karo → andar `app-debug.apk` milega → phone mein install karo

Workflow file already project mein hai: `.github/workflows/build-apk.yml`

---

## Tarika 3 — Kisi aur se banwao

Project zip kisi dost ko de do jo Android Studio use karta hai. Unhe bas **File > Open** karke **Build > Build APK(s)** karna hai. 5 minute ka kaam hai.

---

## Phone mein install karne ke baad — first setup

1. **Microphone** — Allow (zaroori)
2. **Contacts** — Allow (jab "call mummy" bolo)
3. **Phone** — Allow (direct call ke liye)
4. **Camera** — Allow (flashlight ke liye)
5. **Battery optimization** — Settings > Battery > App > **Unrestricted**
6. **Auto-start** — Settings > Apps > Auto-start (Xiaomi/Oppo/Vivo par zaroori)
7. **Notification access** — Settings > Notifications > Voice Assistant (media card ke liye)
8. **Device Admin** — Settings > Security > Device admin apps (sirf "lock screen" command ke liye)
9. **Gemini API key** — `GeminiApiHelper.kt` mein `YOUR_API_KEY_HERE` ki jagah apni key (optional)
10. **Vosk model** — pehli baar app kholne par ~40MB model download hoga (ek hi baar)

---

## Troubleshooting

**"Gradle sync failed" / "Could not resolve..."**
→ Internet check karo. **File > Invalidate Caches > Invalidate and Restart**

**"SDK location not found"**
→ Android Studio khud `local.properties` bana deta hai. Manually: root folder mein `local.properties` file banao aur likho:
```
sdk.dir=C\:\\Users\\<TumharaNaam>\\AppData\\Local\\Android\\Sdk
```
(Mac/Linux: `sdk.dir=/Users/<naam>/Library/Android/sdk`)

**"Unsupported class file major version" / JDK error**
→ **File > Settings > Build, Execution, Deployment > Build Tools > Gradle** → Gradle JDK = **17** select karo

**"minSdkVersion" ya "compileSdk" error**
→ SDK Manager kholo (**Tools > SDK Manager**) → **Android 14 (API 34)** install karo, plus **Build-Tools 34.0.0**

**Gradle bahut slow / hang**
→ `gradle.properties` mein `org.gradle.jvmargs=-Xmx2048m` ko `-Xmx4096m` kar do (agar 8GB+ RAM hai)

**Build ke baad app crash hoti hai**
→ Android Studio ke **Logcat** tab se error copy karke bhejo — main fix kar dunga

---

## Project structure

```
SpeechToTextApp/
├── build.gradle              ← Root plugin versions (NAYA — ye missing tha)
├── settings.gradle
├── gradle.properties
├── gradlew / gradlew.bat
├── gradle/wrapper/
├── .github/workflows/build-apk.yml   ← GitHub se APK banane ke liye
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/aiassistant/voicest/   (25 Kotlin files)
│       └── res/
│           ├── layout/        (6 layouts)
│           ├── values/        (colors, themes, strings)
│           ├── mipmap-*/      ← Launcher icons (NAYE)
│           ├── drawable/      ← Adaptive icon parts (NAYE)
│           └── xml/device_admin.xml
└── BUILD_GUIDE.md
```
